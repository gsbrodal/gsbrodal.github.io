r'''
    ARROW

    Given an odd integer n, your task is to print a right arrow using the 
    the five characters . / \ = and >.  The output should be n lines each with 
    n characters, as illustrated below: The middle line should contain 
    n - 1 copies of '=' followed by '>'. The remaining lines should contain 
    n - 1 copies of '.', plus the top half should contain a single '\' and the 
    bottom half lines should contain a single '/' placed to form a line with 
    the head '>' of the arrow.

    Input:  A single line with an odd integer n, where 3 <= n <= 99.

    Output: n lines each with n characters (containing . / \ = and >) forming
            a right arrow.

    Example:

      Input:  11

      Output: .....\.....
              ......\....
              .......\...
              ........\..
              .........\.
              ==========>
              ........./.
              ......../..
              ......./...
              ....../....
              ...../.....
'''


# insert code
pass
#> solution
n = int(input())
#< solution
#> validate input
assert 3 <= n <= 99 
assert n % 2 == 1
#< validate input
#> solution
for i in reversed(range(n // 2)):
    print('.' * (n - i - 2) + '\\' + '.' * (i + 1))
print('=' * (n - 1) + '>')
for i in range(n // 2):
    print('.' * (n - i - 2) + '/' + '.' * (i + 1))
#< solution
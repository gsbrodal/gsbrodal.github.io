'''
    EQUAL LENGTH

    Input:  A single line containing between one and 25 words, each word 
            consisting of between one and 20 capital letters.

    Output: Each word printed on a new line, in the same order as the input,
            with each word padded with '.' to the left to make all lines have
            the length of the longest word.
    
    Example:

      Input:  THIS IS A TEST OF YOUR PROGRAM

      Output: ...THIS
              .....IS
              ......A
              ...TEST
              .....OF
              ...YOUR
              PROGRAM
'''


# insert code
pass
#> solution
words = input().split()
#< solution
#> validate input
assert 1 <= len(words) <= 25
assert all(1 <= len(word) <= 20 and word.isupper() for word in words)
#< validate input
#> solution
width = max(map(len, words))
for word in words:
    print(word.rjust(width, '.'))
#< solution
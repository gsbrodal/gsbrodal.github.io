'''
    SUBSTRING

    Write a function substring(word, i, j) that takes a string word and two
    integers i and j as input and returns the substring of word from the i'th 
    character to the j'th character, both inclusive and counting from one. 
    
    Input:  First line is a string word of 1 to 200 uppercase letters.
            The second lines contains two integers i and j, separated by space,
            and 1 <= i <= j <= len(word).

    Output: The result of calling substring(word, i, j), i.e., the substring of
            word from the i'th to the j'th character, both inclusive.

    Example:

      Input:  DIPSACACEOUS
              2 5

      Output: IPSA

    Note: The below code already reads the input and calls the function   
          substring. You only need to implement the function substring.
'''


def substring(word, i, j):
    # insert code
    pass
#> solution
    return word[i - 1:j]
#< solution


word = input()
i, j = map(int, input().split())
#> validate input
assert 1 <= i <= j <= len(word) <= 200
assert all(c.isalpha() and c.isupper() for c in word)
#< validate input
print(substring(word, i, j))
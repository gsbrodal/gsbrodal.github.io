'''
    EVENNESS

    Given an increasing list L of n distinct floats, n >= 2, we define the
    evenness of the list of floats by the following equation:

      (L[1] - L[0])**2 + (L[2] - L[1])**2 + ... + (L[n - 1] - L[n - 2])**2
      --------------------------------------------------------------------
                          (n - 1) * average_gap**2
        
    where average_gap = (max(L) - min(L)) / (n - 1).

    Your task is to implement the function evenness(L) that computes the
    evenness of a list L.
                    
    Input:  A single line with n space-separated distinct floats in increasing 
            order, where 2 <= n <= 100.

    Output: A single float with 5 decimals, representing the evenness of the 
            input list.

    Example:

      Input:  10.0 20.0 25.0 40.0 50.0

      Output: 1.12500

    Note: The below code already reads the input list and calls the function 
          evenness on the input list. You only need to implement the function 
          evenness.
'''


def evenness(L):
    # insert code
    pass
#> solution
    n = len(L)
    avg = (L[-1] - L[0]) / (n - 1)
    return sum((y - x) ** 2 for x, y in zip(L, L[1:])) / avg ** 2 / (n - 1)
#< solution


L = list(map(float, input().split()))
#> validate input
assert 2 <= len(L) <= 100
assert L == sorted(set(L))
#< validate input
print(f'{evenness(L):.5f}')
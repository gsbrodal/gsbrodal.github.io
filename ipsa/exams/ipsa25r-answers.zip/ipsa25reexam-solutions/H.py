'''
    SYMMETRIC

    Your are given n lines with n capital letters. Your task is to permute the
    lines such that the n lines top-down equals the n columns left-to-right,
    i.e., that the lines form a symmetric square around the diagonal.

    E.g. if the input contains the four lines:

        0 YSMR
        1 TTYK
        2 KDRQ
        3 TISD

    The following permutation of the lines makes the output a symmetric square.

          1302    
        1 TTYK
        3 TISD
        0 YSMR
        2 KDRQ

    It is guaranteed that there is a unique solution for each test input.

    Input:  The first line contains an integer n, 1 <= n <= 9, the number of 
            lines. Then follows n lines, each containing n uppercase letters.

    Output: The n input lines permuted into a symmetric square.

    Example:
    
      Input:  4
              YSMR
              TTYK
              KDRQ
              TISD
              
      Output: TTYK
              TISD
              YSMR
              KDRQ
'''


# insert code
pass
#> solution
from itertools import permutations  

n = int(input())
lines = list(input() for _ in range(n))
#< solution
#> validate input
assert 1 <= n <= 9
assert all(len(line) == n for line in lines)
assert all(line.isupper() for line in lines)
#< validate input
#> solution
solutions = []
for permutation in permutations(lines):
    transposed = tuple(''.join(column) for column in zip(*permutation))
    if permutation == transposed:
        solutions.append(permutation)
#< solution
#> validate input
assert len(solutions) == 1
#< validate input
#> solution
print(*solutions.pop(), sep='\n')
#< solution
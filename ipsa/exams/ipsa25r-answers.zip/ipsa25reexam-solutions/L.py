'''
    NEARLY PALINDROMIC

    A string is palindromic if it reads the same forwards and backwards, e.g.,
    'NAPAN'. In this problem you are given a string text and an integer k,
    and your task is to find longest palindromic strings that can be substrings 
    of text after deleting at most k characters from text.

    Example:
                           |-------| 
        text       : TESTISNOTAPALINDROMICSTRING
        k          : 4
        delete     :        **   **
        palindrome :       N  APA  N

        In the above text, there are three different palindromic strings that
        can be substrings of text after deleting at most four characters: 
        'NAPAN', 'TSIST', and 'TSTST'.

    Input:  The first line contains a string text with between one and 1000 
            upper case characters. The second line contains an integer k, where
            0 <= k <= 10.  
            
    Output: A single line with all longest distinct palindromic substrings 
            separated by spaces and in lexicographic order, that can be obtained 
            as a substring of text after deleting at most k characters from 
            text.            

    Example:

      Input:  TESTISNOTAPALINDROMICSUBSTRING
              4

      Output: NAPAN TSIST TSTST
'''


# insert code
pass
#> solution
from functools import cache

def max_lengths(L):
    width = max(map(len, L), default=0)
    return sorted(set(s for s in L if len(s) == width))


@cache
def solve(text, k):
    if len(text) <= 1:
        return [text]
    if text[0] == text[-1]:
        return [text[0] + s + text[-1] for s in solve(text[1:-1], k)]
    if k > 0:
        return max_lengths(solve(text[1:], k - 1) + solve(text[:-1], k - 1))
    return []


text = input()
n = len(text)
k = int(input())
#< solution
#> validate input
assert 0 <= k <= 10
assert text.isupper()
assert 1 <= len(text) <= 1000
#< validate input
#> solution
solutions = []
for i in range(n):
    for j in range(i, n):
        solutions = max_lengths(solutions + solve(text[i:j + 1], k))
print(*solutions)
#< solution
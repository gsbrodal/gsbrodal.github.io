'''
    DEFAULT LIST

    Your task is to create a class List, that stores a list of values, and
    supports the following operations, similar to a standard Python list, but
    does not raise exceptions on illegal indexing. 

    For the first three test cases the class List should support the following
    operations, where we assume L is an instance of the class List.

      - List()           # creates an empty List object with no values
      - L.append(value)  # appends the value to the right of the list
      - L.pop()          # removes and returns the rightmost value in the list
                         # if L is empty, returns the default value None
      - L[index]         # returns the value at the given index
                         # positive indexes are from the left 0,...,length-1
                         # negative indexes are from the right -1,...,-length
                         # returns the default value None, 
                         # if index is out of range

    Note to support L[index] you need to implement the __getitem__ method.

    For the last two test cases the list must also support the following.
    
      - List(iterable)
      - List(default=value)
      - List(iterable, default=value)
                         # When creating a list one can give optional arguments:
                         # iterable is an optional positional argument, 
                         # and default an optional keyword argument
                         # iterable is used to initially populate the list 
                         # default changes the default returned value to value
      - L should be iterable
                         # e.g., the following should print all values in L
                         #   for x in L: 
                         #       print(x)

    Input:  Multiple lines of Python code using the class List.
            The last lines contains '#eof'.

    Output: The output of evaluating the input code.

    Example: 

      Input:  L = List()
              L.append(3)
              L.append(6)
              L.append(7)
              for i in range(-5, 5):
                  print(f'L[{i}] = {L[i]}')
              for _ in range(5):
                  print(f'{L.pop() = }')
              #eof

      Output: L[-5] = None
              L[-4] = None
              L[-3] = 3
              L[-2] = 6
              L[-1] = 7
              L[0] = 3
              L[1] = 6
              L[2] = 7
              L[3] = None
              L[4] = None
              L.pop() = 7
              L.pop() = 6
              L.pop() = 3
              L.pop() = None
              L.pop() = None
        
    Note: The below code already reads and executes the input.
'''


class List:
    # insert code
    pass
#> solution
    def __init__(self, iterable=(), default=None):
        self.values = list(iterable)
        self.default = default

    def append(self, item):
        self.values.append(item)

    def pop(self):
        return self.values.pop() if self.values else self.default

    def __getitem__(self, index):
        if index < 0:
            index = len(self.values) + index
        return self.values[index] if 0 <= index < len(self.values) else self.default
    
    def __iter__(self):
        yield from self.values
#< solution


import sys
code = ''
for line in sys.stdin:
    code += line
    if line.startswith('#eof'):
        break
#> validate input
assert line.rstrip() == '#eof'
#< validate input
exec(code)

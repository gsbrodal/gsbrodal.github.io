'''
    EQUAL SUM LISTS

    Given a positive integer n, your task is to print all distinct lists of 
    positive integers that sum to n, where the integers in each list are in  
    non-decreasing order. The lists should be printed in lexicographic order.

    Input:  A single line with a positive integer n, where 1 <= n <= 25.

    Output: One line with each Python list of positive integers summing to n,
            where the integers in a list are in non-decreasing order, and the
            lists are listed in lexicographic order.

    Example:

      Input:  7

      Output: [1, 1, 1, 1, 1, 1, 1]
              [1, 1, 1, 1, 1, 2]
              [1, 1, 1, 1, 3]
              [1, 1, 1, 2, 2]
              [1, 1, 1, 4]
              [1, 1, 2, 3]
              [1, 1, 5]
              [1, 2, 2, 2]
              [1, 2, 4]
              [1, 3, 3]
              [1, 6]
              [2, 2, 3]
              [2, 5]
              [3, 4]
              [7]           
'''


# insert code
pass
#> solution
def lists(n, k=1):
    if n == 0:
        return [[]]
    return [[i, *tail] for i in range(k, n + 1) for tail in lists(n - i, i)] 


n = int(input())
#< solution
#> validate input
assert 1 <= n <= 25
#< validate input
#> solution
print(*lists(n), sep='\n')
#< solution
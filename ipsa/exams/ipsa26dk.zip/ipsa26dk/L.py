'''
    MINIMAL PALLINDROME PARTITION

    [DANSK PROBLEMFORMULERING]

    Et palindrom er en streng der skrives ens forfra og bagfra, såsom "ABBA"
    og "ABACABADABACABA".
    En palindromisk partition af en streng konstrueres ved at dele strengen i
    sammenhængende delstrenge, der hver er palindromer. F.eks. kan strengen
    "DABADAADAADAA" deles ind i strengene: D, ABA, DAAD og AADAA, altså fire
    palindromiske delstrenge.
    En minimal palindromisk partition er en palindromisk partition der deler
    strengen i et minimalt antal delstrenge. Strengen ovenfor kan deles i to
    palindromiske delstrenge: DABAD og AADAADAA, og denne er minimal.

    Din opgave er at udregne alle de minimale palindromiske partitioner af en
    streng.

    Input:  En streng bestående af højest 1000 store bogstaver (A-Z).

    Output: Alle minimale palindromiske partitioner, en partition per linje.
            I hver partition skal delstrengene være mellemrumssepareret.
            I tilfælde af, at der er flere minimale partitioner, skal de
            printes i alfabetisk rækkefølge, når partitionen (med mellemrum)
            betragtes som en streng.
            Det er garanteret at der højest er 100 minimale palindriomiske
            partitioner.

    Eksempel:

      Input:    DABADAADAAD

      Output:   D ABA DAADAAD
                DABAD AA DAAD
                DABAD AADAA D

    Bemærk: I nogle af testene vil der kun være en minimal palindromisk
            partition. Du kan derfor få nogle point ved at løse opgaven
            men kun printer en enkel partition.


    [ENGLISH PROBLEM STATEMENT]

    A palindrome is a string that can be written the same forwards and
    backwards like "ABBA" and "ABACABADABACABA".
    A palindrome partition of a string consists of seperating the string into
    consecutive palindromic substrings.
    I.e. the string "DABADAADAADAA" can be partitioned into the strings: D,
    ABA, DAAD, AADAA. I.e. four palindromic substrings.
    A minimal palindromic partition is a palindromic partition that seperates
    the string into a minimal number of palindromic substrings. The string
    from before can be seperated into two palindromic substrings: DABAD,
    AADAADAA, and this is minimal.

    Your task is to compute all minimal palindrome partitions of a string.

    Input:  A string of at most 1000 uppercase letters (A-Z).

    Output: All the minimal palindrome partitions, one on each line, where
            the partition is space seperated.
            In the case where there are multiple partitions, order them
            alphabetically, when considered as a single string.
            The inputs guarentee, that there are at most 100 minimal palindrome
            partitions.

    Example:

      Input:    DABADAADAAD

      Output:   D ABA DAADAAD
                DABAD AA DAAD
                DABAD AADAA D


    Note:   Some of the test cases will only have one minimal palindromic
            partition. Thus, you can get some points by printing a single
            partition.

'''

# insert code
pass

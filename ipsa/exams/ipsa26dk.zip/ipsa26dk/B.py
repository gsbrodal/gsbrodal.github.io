'''
    BIG RED BALL

    [DANSK PROBLEMFORMULERING]

    Den lokale legetøjsbutik laver legetøj i mange forskellige størrelser,
    farver og former.

    De har to vigtige regler:
        - Hvis et stykke legetøj har size stor (BIG)
                    skal det have shape rund (ROUND).
        - Hvis et stykke legetøj har farve rød (RED)
                    skal det have shape spids (POINTY).

    Lav en funktion valid_toy, der tager en størrelse (size), en farve (color)
    og en form (shape) og afgør om den overholder ovenstående regler.
    Hvis den overholder reglerne, skal funktionen returnere True, ellers skal
    den returnere False.

    Input:  Den første linje indeholder et heltal n, hvor 1 <= n <= 200.
            De næste n linjer indeholder 3 strenge af store bogstaver delt af
            mellemrum. Hver streng er højest 15 karakterer lang og svarer til
            en størrelse, farve og form.

    Output: n linjer med enten True eller False svarende til om hvorvidt hver
            linje er et lovligt stykke lejetøj.

    Eksempel:

      Input:    5
                BIG GREEN SQUARE
                MEDIUM RED POINTY
                BIG RED ROUND
                SMALL GREEN ROUND
                HUGE BLUE BLOBBY

      Output:   False
                True
                False
                True
                True


    Bemærk: Nedenstående kode tager allerede højde for input og kald
            til funktionen valid_toy. Du skal udelukkende implementere
            funktionen valid_toy.


    [ENGLISH PROBLEM STATEMENT]

    The local toy factory makes many different toys in different shapes,
    colors and sizes.

    They have two important rules:
        - If a toy has size BIG, it must have shape ROUND.
        - If a toy has color RED, it must have shape POINTY.

    Make a function valid_toy, that takes a size, color, and shape, and
    determines if it adheres to the above rules or not.
    If it is valid according to the above rules, return True, otherwise return
    False.

    Input:  The first line of the input contains an integer n where
            1 <= n <= 200.
            The next n lines contain three upper case strings separated by
            spaces. Each string is at most 15 characters and correspond to a
            size, color and shape.

    Output: n lines of either True or False corresponding to whether
            each line is a legal toy.

    Example:

      Input:    5
                BIG GREEN SQUARE
                MEDIUM RED POINTY
                BIG RED ROUND
                SMALL GREEN ROUND
                HUGE BLUE BLOBBY

      Output:   False
                True
                False
                True
                True


    Note: The below code already reads the input and calls the function
          valid_toy. You only need to implement the function valid_toy.
'''


def valid_toy(size, color, shape):
    # insert code
    pass


n = int(input())
for _ in range(n):
    color, size, shape = input().split()
    print(valid_toy(color, size, shape))

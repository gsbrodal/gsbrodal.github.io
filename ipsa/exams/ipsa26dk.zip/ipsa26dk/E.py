'''
    PHOTO FINISH

    [DANSK PROBLEMFORMULERING]

    Ved et løb vil man gerne rekonstruere målbilledet. Du er givet en
    række deltagere i løbet og hvor langt de løb da billedet blev taget.
    Hvis tre personer deltog i løbet, Anna løb 25 meter, Bob vandt med 50 meter
    og Charlie løb 40 meter, skal målbilledet se således ud:
        --------+-------------------------------------------------+
        Anna....|........................A........................|
        --------+-------------------------------------------------+
        Bob.....|.................................................B
        --------+-------------------------------------------------+
        Charlie.|.......................................C.........|
        --------+-------------------------------------------------+
    Den første lodrette linje er startlinjen og den sidste er målstregen.
    Før startlinjen skal alle deltagere have deres navn og der skal være
    præcis et "." efter det længste navn. Hver løbers position skal
    markeres med løberens forbogstav.
    Du er garanteret, at den der løb længst, vandt løbet og derfor skal
    målstregen tegnes der. I eksemplet ovenfor er løbet derfor 50 meter langt,
    så der er 49 "-"-symboler før målstregen, hvor Bobs initial er skrevet.
    Hvis en løber løb 0 meter, skal deres bogstav skrives på startlinjen.

    Input:  Første linje har navnene på deltagerne. Der er højest 10 deltagere
            og hver deltagers navn er maksimalt 15 karakterer langt.
            Anden linje har længderne på hvor langt deltagerne løb.
            De løb hver højest 60 meter og vinderen løb mindst 1 meter.

    Output: Billede af løbet, da den første krydsede målstregen.
            Print løberne i den rækkefølge, de bliver skrevet i inputtet.

    Eksempel:

      Input:    Anna Bob Charlie
                25 50 40

      Output:   --------+-------------------------------------------------+
                Anna....|........................A........................|
                --------+-------------------------------------------------+
                Bob.....|.................................................B
                --------+-------------------------------------------------+
                Charlie.|.......................................C.........|
                --------+-------------------------------------------------+


    [ENGLISH PROBLEM STATEMENT]

    We want to recreate the photo at the end of a race. You are given a
    list of contestants in a race and how far they ran when the photo was
    taken.
    If there were three contestants in the race, with Anna running 25 meters,
    Bob won with 50 meters, and Charlie running 40 meters, we would like the
    following photo:
        --------+-------------------------------------------------+
        Anna....|........................A........................|
        --------+-------------------------------------------------+
        Bob.....|.................................................B
        --------+-------------------------------------------------+
        Charlie.|.......................................C.........|
        --------+-------------------------------------------------+
    The first vertical line is the start line and the second is the finish
    line. All the contestants names are written before the start line, such
    that there is exactly one "." after the longest name. Every runner is
    marked on the track by their initial.
    The runner with the longest distance is the winner and thus the finish line
    is drawn where they are. In the example above, the race is 50 meters long,
    so there are 49 "-"-symbols followed by the finish line. If a runner ran 0
    meters they are drawn on top of the start line.

    Input:  The first line contains the names of the contestants. There are at
            most 10 contestants and their names have at most 15 characters
            each.
            The second line has the lengths each contestant ran. Each
            contestant ran at most 60 meters, and the winner ran at least 1
            meter.

    Output: The photo of the race as the first contestant crossed the finish
            line.
            Print the contestants in the order they appear in the input.

    Example:

      Input:    Anna Bob Charlie
                25 50 40

      Output:   --------+-------------------------------------------------+
                Anna....|........................A........................|
                --------+-------------------------------------------------+
                Bob.....|.................................................B
                --------+-------------------------------------------------+
                Charlie.|.......................................C.........|
                --------+-------------------------------------------------+
'''

# insert code
pass

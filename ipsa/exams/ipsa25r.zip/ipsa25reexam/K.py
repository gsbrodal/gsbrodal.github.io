'''
    MAZE EXPLORER

    Your task is to implement a function maze_size(maze) that computes the size 
    of an unknown maze, consisting of a grid of free and occupied cells. 
    You only have four methods to explore the maze: maze.left(), maze.right(), 
    maze.up(), and maze.down() which allow you to move in the four directions 
    from your current position. Each method returns True if the neighboring cell 
    is free and moves you to the neighboring cell. Otherwise, False is returned 
    and you do not move. You start at a free cell, and the maze is guaranteed to 
    contain at most 500 connected free cells.
    
    Assume you are placed in the below maze (# = occupied, . = free, * = your
    starting position).

        #####
        #.*.#
        #####

    You are given access to the maze through an object 'maze' of a class Maze,
    supporting the methods left(), right(), up(), and down(). You can use these
    methods to move throughout the maze, and only these. E.g., the above maze 
    can be explored as follows:

        maze.up()     # returns False
        maze.right()  # returns True, moves to the rightmost free cell
        maze.up()     # returns False
        maze.right()  # returns False
        maze.down()   # returns False
        maze.left()   # returns True, moves back to the start cell
        maze.down()   # returns False
        maze.left()   # returns True, moves to the leftmost free cell
        maze.up()     # returns False
        maze.down()   # returns False
        maze.left()   # returns False
        maze.right()  # returns True, moves back to the start cell

    Input:  Python code that defines a class Maze with methods left, right, up, 
            and down. Last line contains '#eof'.

    Output: The result of calling maze_size with an instance of Maze() as the 
            only argument, i.e., a single line with an integer equal to the 
            number of free cells reachable in the maze.

    Example:

        Assume the input code implements a class Maze navigation the below maze,
        where the * is your starting position:

            #######
            #.*...#
            #.....#
            #.....#
            #######

        Input:  class Maze:
                    def right(self): ...
                    def left(self): ...
                    def up(self): ...
                    def down(self): ...

        Output: 15

    Note: The below code already reads the Maze class definition, and calls the
        function maze_size with an instance of Maze(). You only need to 
        implement the function maze_size.
'''


def maze_size(maze):
    # insert code
    pass


import sys
code = ''
for line in sys.stdin:
    code += line
    if code.startswith('#eof'):
        break
exec(code)
size = maze_size(Maze())
print(size)
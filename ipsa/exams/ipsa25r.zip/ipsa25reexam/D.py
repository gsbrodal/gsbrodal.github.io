'''
    NEARLY PRIME

    We say a positive integer is nearly prime if it has at most 3 divisors. 
    E.g., 25 is nearly prime since its divisors are 1, 5, and 25.

    Input:  A single line with an integer n, where 1 <= n <= 1000.

    Output: A single line with all nearly prime integers between 1 to n, 
            inclusive both, in increasing order separated by a space.

    Example:

      Input:  25

      Output: 1 2 3 4 5 7 9 11 13 17 19 23 25
'''


# insert code
pass

'''
    MAKE DISTINCT

    Your task is given a list of integers, to replace repeating occurrences of
    integers with the smallest possible larger integers, to make all integers
    distinct. The resulting list should be printed sorted in increasing order.

    Example: Consider the input sequence

      10 6 10 4 2 2 6 2 2
        
    The sequence contains 4 occurrences of 2, 2 occurrences of 6, and 2
    occurrences of 10, i.e., 3 occurrences of 2, 1 occurrence of 6, and 1
    occurrence of 10 need to be replaced by larger integers. The 2's can be
    replaced by 3, 5, and 7 (since the list already contains 4 and 6), the 6 can
    be replaced by 8 (since 7 already has been inserted), and one occurrence of
    10 can be replaced by 11. If we sort the final list, we get:

      2 3 4 5 6 7 8 10 11          

    Input:  A single line of n space-separated integers, where 1 <= n <= 1000  
            and all integers between 1 and 1_000_000_000.

    Output: A single line of n space-separated distinct integers, sorted in 
            increasing order, where recurring integers in the input are replaced
            with the smallest possible larger integers.

    Example:

      Input:  10 6 10 4 2 2 6 2 2

      Output: 2 3 4 5 6 7 8 10 11
'''


# insert code
pass

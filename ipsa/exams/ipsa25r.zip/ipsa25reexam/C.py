'''
    EQUAL LENGTH

    Input:  A single line containing between one and 25 words, each word 
            consisting of between one and 20 capital letters.

    Output: Each word printed on a new line, in the same order as the input,
            with each word padded with '.' to the left to make all lines have
            the length of the longest word.
    
    Example:

      Input:  THIS IS A TEST OF YOUR PROGRAM

      Output: ...THIS
              .....IS
              ......A
              ...TEST
              .....OF
              ...YOUR
              PROGRAM
'''


# insert code
pass

'''
    MARKS

    Write a function marks(L) that takes a list of pairs (symbol, count)
    and for each pair prints a line with count copies of symbol, e.g.,

        marks([('A', 10), ('B', 5), ('C', 15)])

    should print the three lines

        AAAAAAAAAA
        BBBBB
        CCCCCCCCCCCCCCC

    Input:  A single line containing a Python list of pairs (symbol, count).
            The length contains between 1 and 100 pairs, each count is an 
            integer between 1 and 100, and symbol is a string of length 1.  
            All symbols are distinct.

    Output: One line for each pair (symbol, count) in the input list,
            containing count copies of symbol (and no other character).

    Example:
    
      Input:  [('A', 10), ('B', 5), ('C', 15)]

      Output: AAAAAAAAAA
              BBBBB
              CCCCCCCCCCCCCCC

    Note: The below code already reads the input and calls the marks function.
'''


def marks(L):
    # insert code
    pass
#> validate input
    assert isinstance(L, list)
    assert 1 <= len(L) <= 100
    for element in L:
        assert isinstance(element, tuple)
        symbol, count = element
        assert isinstance(count, int)
        assert isinstance(symbol, str)
        assert 1 <= count <= 100
        assert len(symbol) == 1
    assert len(L) == len(set(symbol for symbol, count in L))
#< validate input
#> solution
    for symbol, count in L:
        print(symbol * count)
#< solution


marks(eval(input()))

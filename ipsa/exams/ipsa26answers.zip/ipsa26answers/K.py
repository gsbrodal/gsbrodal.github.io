'''
    RESERVOIR

#> DK
    [DANSK PROBLEMFORMULERING]

    Din opgave er at beregne hvor meget vand der kan være i et reservoir.
    Dog har reservoiret en underlig form. Det er klemt inde mellem to bjerge,
    så du kan betragte det som en 2D konstruktion. Du får oplyst dets bredde i
    meter og højden af betonet, som reservoiret er lavet af, for hver meter det
    strækker sig. For at vand kan være i reservoiret, skal det have beton både
    til højre og venstre for sig.

    For eksempel, hvis reservoiret er 8 bred og højderne er 5 1 2 3 8 4 2 7,
    vil betonet se således ud:

            #
            #  #
            #  #
        #   #  #
        #   ## #
        #  ### #
        # ######
        ########
        51238426

    Hælder man vand i det indtil det begynder at spilde ud, vil der være vand
    i alle celler markeret med "o":

            #
            #oo#
            #oo#
        #ooo#oo#
        #ooo##o#
        #oo###o#
        #o######
        ########

    Alt i alt vil der være plads til 17 m^2 vand.

    Input:  Første linje har et heltal n, hvor n <= 10_000.
            Anden linje har n heltal delt af mellemrum, svarende til højderne
            af reservoiret. Hver højde er højest 1_000_000.

    Output: Et enkelt heltal svarende til mængden af vand der kan være i
            reservoiret.

    Eksempel:

      Input:    8
                5 1 2 3 8 4 2 7

      Output:   17


    [ENGLISH PROBLEM STATEMENT]

#< DK
    Your task is to calculate the amount of water that can fit in a reservoir.
    The reservoir, however, has a very peculiar shape. It is fixed between two
    mountains, so we can consider it to be a 2D construction. You are given its
    width in meters and the elevation of the concrete in meters. For water to
    fit in the reservoir, it must have concrete to the left and right of it.

    For instance, if you have a reservoir that is 8 wide and the elevations are
    5 1 2 3 8 4 2 7, the concrete part of the reservoir looks like this:

            #
            #  #
            #  #
        #   #  #
        #   ## #
        #  ### #
        # ######
        ########
        51238426

    Pouring water, until we start spilling, we get water in the cells marked
    with an "o":

            #
            #oo#
            #oo#
        #ooo#oo#
        #ooo##o#
        #oo###o#
        #o######
        ########

    In total, we have space for 17 m^2 of water.

    Input:  The first line contains an integer n, with n <= 10_000.
            The second line contains n integers separated by spaces. These
            are the heights of the reservoir.
            Each are no larger than 1_000_000.

    Output: A single integer, equal to the total amount of water possible to
            fit in the reservoir.

    Example:

      Input:    8
                5 1 2 3 8 4 2 7

      Output:   17
'''

# insert code
pass
#> solution
n = int(input())
heights = list(map(int, input().split()))
#< solution
#> validate input
assert 1 <= n <= 1_000_000
assert all(height <= 1_000_000 for height in heights)
#< validate input
#> solution
i = max(range(n), key=lambda i: heights[i])
water = 0
max_left = heights[0]
for height in heights[1:i]:
    water += max(0, max_left - height)
    max_left = max(max_left, height)
max_right = heights[n - 1]
for height in heights[n - 2:i:-1]:
    water += max(0, max_right - height)
    max_right = max(max_right, height)
print(water)
#< solution

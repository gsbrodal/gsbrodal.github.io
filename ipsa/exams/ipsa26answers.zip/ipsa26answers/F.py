'''
    DUCKS ON DUCKS

#> DK
    [DANSK PROBLEMFORMULERING]

    Ænder elsker at stable sig oven på hinanden. De kan stable sig i en
    pyramide form, så en and står på skuldrende af to andre ænder som f.eks:
    (Hvor "D" repræsenterer en and)
            D
           D D D
          D D D D
    Nogle ænder har krav på hvor langt oppe i andetårnet de vil stå.
    Din opgave er at afgøre hvor mange ænder der skal til for at alle ænder
    får deres ønske opfyldt.

    Input:  Den første linje indeholder et heltal n som er antallet af ænder
            der har stillet krav. 1 <= n <= 5000.
            Den anden linje indeholder n heltal, det ønskede niveau for
            hver and. Et ønske på "0" vil svare til at stå på jorden. Hvert
            ønsket niveau mellem 0 og 5000.

    Output: Antallet af ænder der skal til for at lave et stabilt tårn, så alle
            ænderne for deres ønske opfyldt.

    Eksempel:

      Input:    10
                1 0 3 1 2 1 2 2 1 1

      Output:   15

    Forklaring af eksempel:
        Ænderne kan arrangeres således:

              D
           D D D
          D D D D D
         D D D D D D
        Det er her nødvendigt at tilføje 5 ekstra ænder til det nederste lag.

    Bemærk: Nedenstående kode læser n og ønskerne fra ænderne og gemmer dem
            i listen "heights"

    [ENGLISH PROBLEM STATEMENT]

#< DK
    A favorite activity among ducks is to stack on top of each other.
    Ducks can stand on top of each other in a pyramid shape, so that a
    duck can stand on the shoulders of two other ducks; like so:
    (where "D" represents a duck)
            D
           D D D
          D D D D
    Some of the ducks have requirements on how far up they want to be in the
    duck tower. You are tasked to compute the minimum number of ducks needed to
    fulfill every ducks wishes.

    Input:  The first line contains an integer n, the number of ducks with
            required heights. 1 <= n <= 5000.
            The second line contains n integers, the surveyed levels the ducks
            wish to be on. A wish of "0" would correspond to standing on the
            ground. Every wish is between 0 and 5000.

    Output: The number of ducks needed to make a stable tower, fulfilling
            every ducks wish.

    Example:

      Input:    10
                1 0 3 1 2 1 2 2 1 1

      Output:   15

    Explanation of example:
        Because the ducks could be arranged into a tower like this:

              D
           D D D
          D D D D D
         D D D D D D
        It was here necessary to add 5 extra ducks on the bottom layer.

    Note:   The below code reads n and the ducks wishes and saves them in
            the list "heights"
'''

n = int(input())
heights = list(map(int, input().split()))
# insert code
#> validate input
assert 1 <= n <= 5000
assert all(0 <= height <= 5000 for height in heights)
#< validate input
#> solution
from collections import Counter
c = Counter(heights)
top = max(c)
total = 0
prev = 0
for level in range(top, -1, -1):
    prev = max(prev + 1, c[level])
    total += prev
print(total)
#< solution

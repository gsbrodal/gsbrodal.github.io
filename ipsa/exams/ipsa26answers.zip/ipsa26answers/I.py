'''
    DELAYED

#> DK
    [DANSK PROBLEMFORMULERING]
    Lav en dekoratør delayed, der forsinker outputtet af funktionen med et
    funktionskald. Altså, første gang funktionen bliver kaldt, returnerer den
    None. Anden gang den bliver kaldt, returnerer den det, der burde være
    returneret ved første kald. Tredje kald returnerer outputtet af andet kald
    osv.

    Den dekorerede funktion kan tage et vilkårligt antal positionelle og
    nøgleordsargumenter. Alt funktionalitet vedrørende funktionen skal stadig
    fungere. Altså, hvis funktionen f.eks. printer noget, skal den stadig gøre
    det, når den er kaldt. Det er udelukkende retur værdien, der skal
    forsinkes.

    Du kan antage, at højest en funktion vil være dekoreret ad gangen.

    Input:  Flere linjer Python kode der bruger dekoratøren delayed.
            Den sidste linje indeholder strengen #eof.

    Output: Resultatet af at køre Python koden.

    Eksempel:

      Input:    @delayed
                def plus(x):
                    return x + 3
                print(plus(0))
                print(plus(1))
                print(plus(2))
                print(plus(2))
                print(plus(4))
                #eof


      Output:   None
                3
                4
                5
                5


    [ENGLISH PROBLEM STATEMENT]

#< DK
    Create a decorator delayed, that delays the output of the function by
    one function call. I.e., the first time the function is called, it must
    return None. Second time, it returns what it would have returned the
    first time, it was called. Third time it returns what it would have
    returned the second time and so on.

    The decorated function must be able to take any number of positional and
    keyword arguments. All other functionality of the function should still be
    performed, i.e., if the function prints something, it should still do this
    when called. Only the return value should be delayed.

    You can assume that at most one function will be decorated at a time.

    Input:  Multiple lines of Python code using the decorator delayed.
            The last line contains the string #eof.

    Output: The result of executing the Python code.

    Example:

      Input:    @delayed
                def plus(x):
                    return x + 3
                print(plus(0))
                print(plus(1))
                print(plus(2))
                print(plus(2))
                print(plus(4))
                #eof


      Output:   None
                3
                4
                5
                5

    Note: The below code already takes care of reading the input and evaluating
          it. Your task is only to create the decorator delayed.
'''


def delayed(f):
    # insert code
    pass
#> solution
    last_result = None
    def function(*args, **kwargs):
        nonlocal last_result
        to_return = last_result
        last_result = f(*args, **kwargs)
        return to_return
    return function
#< solution


import sys
code = ''
for line in sys.stdin:
    if line.startswith('#eof'):
        break
    code += line
#> validate input
assert line.startswith('#eof')
#< validate input
exec(code)

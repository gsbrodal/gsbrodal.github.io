'''
    RIPPLES

#> DK
    [DANSK PROBLEMFORMULERING]

    En sten bliver kastet ned i en rektangulær dam. Det er din opgave at tegne
    hvordan bølgerne bevæger sig gennem dammen. Da dammen er rektangulær, er
    bølgerne diamantformede (se nedenfor).

    Du får givet størrelsen af dammen (m bred og n høj), koordinaterne hvor
    stenen bliver smidt (x, y) og afstanden mellem bølger (d).

    Du skal printe et mxn gitter af "."-symboler med "#"-symboler
    repræsenterende bølgerne. F.eks. hvis dammen er 18x10 og stenen bliver
    smidt på (5,7) med en afstand på 4 mellem bølgerne, vil printet se således
    ud (koordinater er skrevet for tydelighed):

      0 #...#.#...#...#...
        ...#...#...#...#..
        ..#.....#...#...#.
        .#...#...#...#...#
        #...#.#...#...#...
        ...#...#...#...#..
        ..#.....#...#...#.
      7 .#...#...#...#...#
        ..#.....#...#...#.
      9 ...#...#...#...#..
        0    5           17

    Input:  En linje med 5 heltal delt af mellemrum: m n x y d
            med følgende restriktioner:
                0 <= x < m <= 70
                0 <= y < n <= 70
                2 <= d <= 10

    Output: Printet af dammen med bølger

    Eksempel:

      Input:    12 11 4 6 4

      Output:   ..#...#...#.
                .#.....#...#
                #...#...#...
                ...#.#...#..
                ..#...#...#.
                .#.....#...#
                #...#...#...
                .#.....#...#
                ..#...#...#.
                ...#.#...#..
                #...#...#...

    Bemærk: Nedenstående kode læser værdierne fra inputtet.

    [ENGLISH PROBLEM STATEMENT]

#< DK
    A stone is dropped in a rectangular pond. It is your task to draw the
    ripples formed in the pond. As the pond is rectangular, the ripples will be
    diamond shaped (see below).

    You are given the size of the pond (m wide and n heigh), the coordinate of
    where the stone is dropped (x, y) and the distance between ripples (d).

    You must print an mxn grid of "."-characters with "#"-characters
    representing the ripples. For instance, if the pond is 18x10 and a stone is
    dropped at (5,7) with distance 4 between ripples, the print will look like
    this:

      0 #...#.#...#...#...
        ...#...#...#...#..
        ..#.....#...#...#.
        .#...#...#...#...#
        #...#.#...#...#...
        ...#...#...#...#..
        ..#.....#...#...#.
      7 .#...#...#...#...#
        ..#.....#...#...#.
      9 ...#...#...#...#..
        0    5           17

    Input:  A line with 5 integers separated by spaces: m n x y d
            with the restrictions:
                0 <= x < m <= 70
                0 <= y < n <= 70
                2 <= d <= 10

    Output: The print of the pond with ripples

    Example:

      Input:    12 11 4 6 4

      Output:   ..#...#...#.
                .#.....#...#
                #...#...#...
                ...#.#...#..
                ..#...#...#.
                .#.....#...#
                #...#...#...
                .#.....#...#
                ..#...#...#.
                ...#.#...#..
                #...#...#...

    Note:   The below code reads the values from the input.
'''

m, n, x, y, d = map(int, input().split())

# insert code
#> validate input
assert 0 <= x < m <= 80
assert 0 <= y < n <= 80
assert 2 <= d <= 10
#< validate input
#> solution
for j in range(n):
    for i in range(m):
        print('#' if (abs(i - x) + abs(j - y)) % d == 0 else '.', end='')
    print()
#< solution

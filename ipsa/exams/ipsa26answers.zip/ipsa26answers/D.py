'''
    CHESS EVALUATION

#> DK
    [DANSK PROBLEMFORMULERING]

    Afgør scoren af en skakposition.

    Brættet er et 8x8 gitter hvor et tomt felt markeres med et "." og et felt
    med en brik markeres med det tilsvarende bogstav (se nedenfor). Brikken er
    hvid hvis bogstavet er med stort og sort hvis bogstavet er med småt. Scoren
    af positionen er summen af alle de hvide brikker minus summen af alle de
    sorte brikker.

    De forskellige brikker med point er:
        Konge       (K) - 2 point
        Dronning    (Q) - 9 point
        Tårn        (R) - 5 point
        Løber       (B) - 3 point
        Springer    (N) - 3 point
        Bonde       (P) - 1 point

    Du skal lave en funktion evaluate_position, der tager en skakposition som
    en streng og returnerer scoren af positionen. Inputtet til funktionen er de
    8 linjer der beskriver brættet, separeret af '\n' karakterer.

    Eksempel:
        Betragt følgende position:
            ........
            ........
            ...pbp..
            ....p..k
            PP..R...
            ..P.....
            r.......
            ..K.....
        Hvid har en konge, et tårn og tre bønder. Sort har en konge, et tårn,
        en løber og tre bønder.

        Hvid har 2 + 5 + 3 * 1 = 10 point
        Sort har 2 + 5 + 3 + 3 * 1 = 13 point
        Så scoren er 10 - 13 = -3

    Input:  8 linjer, hver med 8 karakterer svarende til brættet under et
            skakspil.

    Output: Et enkelt heltal, scoren af skakpositionen.

    Eksempel:

      Input:    ........
                ........
                ...pbp..
                ....p..k
                PP..R...
                ..P.....
                r.......
                ..K.....

      Output:   -3

    Bemærk: Du skal ikke lave skak specifikke overvejelser i din evaluering
    såsom om man er i skak eller kan slå brikker. Vi betragter kun materialet
    på brættet. Positionen er nødvendigvis ikke en position, der kan fremkomme
    ved normal spil.
    Derudover tager nedenstående kode allerede højde for input og kald
    til funktionen evaluate_position. Du skal udelukkende implementere
    funktionen evaluate_position.

    [ENGLISH PROBLEM STATEMENT]

#< DK
    From a position of chess, determine the score of the position.

    The board is an 8x8 grid where an empty square is marked with a "." and
    a square with a piece is marked by the corresponding letter (see below).
    It is a white piece if it is upper case and black if it is lower case. The
    score of the position is the total points of the white pieces minus the
    total points of the black pieces.

    The different pieces with points are:
        King    (K) - 2 points
        Queen   (Q) - 9 points
        Rook    (R) - 5 points
        Bishop  (B) - 3 points
        Knight  (N) - 3 points
        Pawn    (P) - 1 point

    You must write a function evaluate_position, that given a board as a string
    computes the point evaluation of a position. The input to the function is
    the 8 lines of the input seperated by '\n' characters.

    Example:
        In the following position:
            ........
            ........
            ...pbp..
            ....p..k
            PP..R...
            ..P.....
            r.......
            ..K.....
        White has a king, a rook and three pawns. Black has a king, a rook, a
        bishop and three pawns.

        White has 2 + 5 + 3 * 1 = 10 points
        Black has 2 + 5 + 3 + 3 * 1 = 13 points
        So the evaluation is 10 - 13 = -3

    Input:  8 lines, each with 8 characters corresponding to the board of a
            chess game.

    Output: A single integer, being the score of the position.

    Example:

      Input:    ........
                ........
                ...pbp..
                ....p..k
                PP..R...
                ..P.....
                r.......
                ..K.....

      Output:   -3

    Note: You do not need to do any chess specific evaluations, like consider
    checks, captures or the like. We only care about the material on the board.
    The position is not necessarily achievable through normal play.
    Furthermore, the below code already reads the input and calls the function
    evaluate_position. You only need to implement the function
    evaluate_position.
'''


def evaluate_position(position):
    # insert code
    pass
#> validate input
    assert set(position) <= set('.pkbnrqPKBNRQ\n')
    lines = position.split('\n')
    assert len(lines) == 8
    assert all(len(line) == 8 for line in lines)
#< validate input
#> solution
    piece_value = {
        "p": -1,
        "k": -2,
        "b": -3,
        "n": -3,
        "r": -5,
        "q": -9,
        "P": 1,
        "K": 2,
        "B": 3,
        "N": 3,
        "R": 5,
        "Q": 9
    }
    return sum([piece_value.get(char, 0) for char in position])
#< solution


print(evaluate_position("\n".join([input() for _ in range(8)])))

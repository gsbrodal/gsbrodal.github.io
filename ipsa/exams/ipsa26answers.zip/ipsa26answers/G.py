'''
    CREDIT CARD

#> DK
    [DANSK PROBLEMFORMULERING]

    Din opgave er at implementere en klasse CreditCard, der holder styr på
    en konto og tillader følgende operationer, hvor c er en instans af
    CreditCard klassen:

        CreditCard()                            - Laver et kreditkort med en
                                                 saldo på 0.
        CreditCard(amount)                      - Laver et kreditkort med en
                                                 saldo på amount.
        c.get_balance()                         - Returnerer den nuværende
                                                 saldo på kreditkortet.
        c.add_to_balance(amount)                - Tilføjer amount til saldoen.
        c.purchase_item(name, price)            - Køber en ting der hedder name
                                                 og trækker price fra saldoen.
        c.print_last_purchases(number_of_items) - Printer de sidste
                                                 number_of_items købte items.

    I ovenforstående skal amount og price begge være større end eller lig 0.
    Et korts saldo må ikke gå i negativ. Hvis man forsøger at købet noget, der
    ville føre saldoen i negativ, skal der i stedet raises en
    InsufficientFundsError.
    Funktionen print_last_purchases printer navnet på de sidste number_of_items
    købte items. Navnene printes sepereret af mellem på én linje, hvor det item
    der er købt først printes først. Hvis print_last_purchases bliver kaldt med
    et tal større end antallet af købte items, skal man printe alle købte items
    i stedet for.

    Input:  Flere linjer af Python kode der bruger CreditCard klassen.
            Den sidste linje af inputtet er #eof.

    Output: Resultatet af at køre Python koden.

    Eksempel:

      Input:    c = CreditCard(500)
                c.add_to_balance(100)
                print(c.get_balance())
                c.purchase_item("Shoe", 500)
                print(c.get_balance())
                c.add_to_balance(200)
                c.purchase_item("Jacket", 150)
                print(c.get_balance())
                c.print_last_purchases(3)
                c.purchase_item("Bag", 300)

      Output:   600
                100
                150
                Shoe Jacket
                InsufficientFundsError

    Bemærk: Du skal udelukkende implementere de manglende metoder i CreditCard
    klassen. Nedenstående kode implementerer InsufficientFundsError og tager
    højde for at input koden bliver læst og kørt.


    [ENGLISH PROBLEM STATEMENT]

#< DK
    Your task is to create a class CreditCard that stores the balance of
    an account and supports the following operations, where c denotes an
    instance of the CreditCard class:

        CreditCard()                            - Creates a credit card with
                                                 a starting balance of 0.
        CreditCard(amount)                      - Creates a credit card with
                                                 a starting balance of amount.
        c.get_balance()                         - Returns the current balance
                                                 of the credit card.
        c.add_to_balance(amount)                - Adds amount to the current
                                                 balance.
        c.purchase_item(name, price)            - Buys an item called name and
                                                 subtracts the price from the
                                                 balance.
        c.print_last_purchases(number_of_items) - Prints the last
                                                 number_of_items purchased
                                                 items

    In the above methods amount and price must be greater than or equal 0.
    A cards balance may not be negative. If one tries to buy something, that
    would bring the balance to negative, instead an InsufficientFundsError
    should be raised.
    The function print_last_puchases prints the names of the last
    number_of_items bought items. The names must be seperated by space on a
    single line, where the first bought item is printed first. If
    print_last_purchases is called with a larger number than the number of
    purchased items, all bought items must be printed instead.

    Input:  Multiple lines of Python code using the CreditCard class.
            The final input line is #eof.

    Output: The result of executing the Python code.

    Example:

      Input:    c = CreditCard(500)
                c.add_to_balance(100)
                print(c.get_balance())
                c.purchase_item("Shoe", 500)
                print(c.get_balance())
                c.add_to_balance(200)
                c.purchase_item("Jacket", 150)
                print(c.get_balance())
                c.print_last_purchases(1)
                c.print_last_purchases(3)
                c.purchase_item("Bag", 300)

      Output:   600
                100
                150
                Jacket
                Shoe Jacket
                InsufficientFundsError

    Note: You should only implement the missing methods in the class
    CreditCard. The code below already implements InsufficientFundsError,
    reads the input, and executes the code.
'''


class InsufficientFundsError(Exception):
    pass


class CreditCard:
    # insert code
    pass
#> solution
    def __init__(self, amount=0):
        self.balance = amount
        self.purchases = []

    def get_balance(self):
        return self.balance

    def add_to_balance(self, amount):
        self.balance += amount

    def purchase_item(self, name, price):
        if price > self.balance:
            raise InsufficientFundsError
        self.balance -= price
        self.purchases.append(name)

    def print_last_purchases(self, number_of_items):
        print(*self.purchases[-number_of_items:])
#< solution


import sys
code = ''
for line in sys.stdin:
    code += line
    if code.startswith('#eof'):
        break
#> validate input
assert line.rstrip() == '#eof'
#< validate input
try:
    exec(code)
except InsufficientFundsError:
    print("InsufficientFundsError")

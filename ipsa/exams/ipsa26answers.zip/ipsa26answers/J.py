'''
    POINT LOCATION

#> DK
    [DANSK PROBLEMFORMULERING]

    Din opgave er at implementere en funktion locate_point(grid), som finder
    et hemmeligt punkt i et 2D gitter. Du har to metoder til at udforske
    gitteret: grid.get_dims() og grid.test_point(point).
    grid.get_dims() returnerer to heltal, værende bredden og højden af
    gitteret. grid.test_point(point) tager som input et par af heltal
    (representerende koordinaterne til et punkt i gitteret) og returnerer en
    af fire strenge afhængigt af relationen mellem det hemmelige punkt og input
    punktet:
        "EXACT"   -     Input punktet er lig det hemmelige punkt.
        "SMALLER" -     Input punktet er ikke lig det hemmelige punkt, men
                        begge koordinater til inputpunktet er mindre eller lig
                        det tilsvarende koordinat til det hemmelige punkt.
        "LARGER"  -     Input punktet er ikke lig det hemmelige punkt, men
                        begge koordinater til inputpunktet er større eller lig
                        det tilsvarende koordinat til det hemmelige punkt.
        "MIXED"   -     Ingen af ovenforstående.

    Her er et eksempel på svarende man ville få ved at teste punkterne i et
    5x5 gitter hvor det hemmelige punkt er (3,1) (hvor "E" betyder EXACT, "S"
    betyder SMALLER, "L" betyder LARGER og "M" betyder MIXED):
                4|MMMLL
                3|MMMLL
            y   2|MMMLL
                1|SSSEL
                0|SSSSM
                -+-----
                 |01234
                    x
    
    For eksempel, hvis gitteret havde størrelse 5x5 og det hemmelige punkt var
    (3,1), kunne gitteret blive udforsket således:
        grid.get_dims()         # returnerer (5,5)
        grid.test_point((1,1))  # returnerer "SMALLER"
        grid.test_point((3,3))  # returnerer "LARGER"
        grid.test_point((2,2))  # returnerer "MIXED"
        grid.test_point((1,3))  # returnerer "MIXED"
        grid.test_point((3,1))  # returnerer "EXACT"


    Input:  Python kode der definerer en klasse Grid med metoder get_dims og
            test_point. Den sidste linje er #eof.
            Højden og bredden af gitteret er begge højest 1_000_000_000.

    Output: Resultatet af at kalde locate_point med en instans af Grid som
            det eneste argument. Altså en enkel linje med et par af heltal
            lig det hemmelige punkt.

    Eksempel:
        Antag at input koden implementerer klassen Grid med et 5x5 gitter
        hvor det hemmelige punkt er (3,1).

      Input:    class Grid:
                    def get_dims(self): ...
                    def test_point(self, point): ...

      Output:   (3, 1)

    Bemærk: Nedenfor stående kode håndterer allerede inputtet og læser Grid
        klassedefinitionen samt kalder locate_point med et instans af Grid.
        Du skal blot implementere funktionen locate_point.

    [ENGLISH PROBLEM STATEMENT]

#< DK
    Your task is to implement a function locate_point(grid), that finds a
    target point in a 2D grid. You have two methods to explore the grid:
    grid.get_dims() and grid.test_point(point).
    grid.get_dims() returns two integers, being the width and height of the
    grid.
    grid.test_point(point) takes a tuple of two integers (representing a point
    in the grid) as input and returns one of four strings depending on the
    relation between the input point and the secret point:
        "EXACT"   -     The input point is equal to the secret point.
        "SMALLER" -     The input point is not equal to the secret point, but
                        both the coordinates of the input point are less than
                        or equal to the corresponding coordinates of the secret
                        point.
        "LARGER"  -     The input point is not equal to the secret point, but
                        both the coordinates of the input point are greater
                        than or equal to the corresponding coordinates of the
                        secret point.
        "MIXED"   -     None of the above options.

    Here is an example of the answers you would get by testing the points of a
    5x5 grid where the secret point is (3,1) (where "E" is EXACT, "S" is
    SMALLER, "L" is LARGER and "M" is MIXED):

                4|MMMLL
                3|MMMLL
            y   2|MMMLL
                1|SSSEL
                0|SSSSM
                -+-----
                 |01234
                    x

    For instance, if the grid is a 5x5 grid and the secret point is (3,1) the
    grid could be explored as follows:

        grid.get_dims()         # returns (3,3)
        grid.get_dims()         # returns (5,5)
        grid.test_point((1,1))  # returns "SMALLER"
        grid.test_point((3,3))  # returns "LARGER"
        grid.test_point((2,2))  # returns "MIXED"
        grid.test_point((1,3))  # returns "MIXED"
        grid.test_point((3,1))  # returns "EXACT"


    Input:  Python code that defines a class Grid with methods get_dims and
            test_point. Last line contains #eof.
            The height and width of the Grid are at most 1_000_000_000.

    Output: The result of calling locate_point with an instance of Grid() as
            the only argument. i.e., a single line with a pair of integers
            equal to the secret point.

    Example:
        Assume the input code implements a class Grid with a 5x5 grid with the
        secret point being (3,1)

      Input:    class Grid:
                    def get_dims(self): ...
                    def test_point(self, point): ...

      Output:   (3, 1)

    Note: The below code already reads the Grid class definition, and calls the
        function locate_point with an instance of Grid. You only need to
        implement the function locate_point.
'''


def locate_point(grid):
    # insert code
    pass
#> solution
    n, m = grid.get_dims()
#< solution
#> validate input
    assert 1 <= n <= 1_000_000_000
    assert 1 <= m <= 1_000_000_000
#< validate input
#> solution
    low = 0
    high = n
    while low + 1 < high:
        mid = (low + high) // 2
        value = grid.test_point((mid, 0))
        if value in ('SMALLER', 'EXACT'):
            low = mid
        else:
            high = mid
    x = low

    low = 0
    high = m
    while low + 1 < high:
        mid = (low + high) // 2
        value = grid.test_point((x, mid))
        if value != 'LARGER':
            low = mid
        else:
            high = mid
    y = low

    return (x, y)
#< solution


import sys
code = ''
for line in sys.stdin:
    code += line
    if code.startswith('#eof'):
        break
#> validate input
assert line.rstrip() == '#eof'
#< validate input
exec(code)
point = locate_point(Grid())
print(point)

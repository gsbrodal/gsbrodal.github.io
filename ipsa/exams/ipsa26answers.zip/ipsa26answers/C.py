'''
    PRODUCTION LINE

#> DK
    [DANSK PROBLEMFORMULERING]

    En fabrik producerer en række produkter og hvert produkt tager
    altid lige lang tid at producere.
    Hvis for eksempel fabrikken producerer borde og stole, og det tager
    2 dage at producere et bord og 3 dage at producere en stol vil fabrikken
    intet producere på dag 1, de vil producere et bord på dag 2, en stol på
    dag 3, et bord på dag 4, intet på dag 5 og både en stol og et bord på
    dag 6, osv.

    Du skal finde ud af, hvad fabrikken producerer hver dag ud fra
    produktionsoplysningerne.

    Input:  Første linje har to heltal n og R, hvor 1 <= n <= 10 og
            1 <= R <= 100.
            Anden linje indeholder n strenge, delt med mellemrum, som er
            navnene på de produkter fabrikken producerer. Hver streng er
            højest 15 karakterer lange.
            Tredje linje har n heltal, som er hvor lang tid det tager at
            producere de n produkter.

    Output: En linje for hvert dag, fabrikken producerer noget. På hver linje
            skal skrives dagens nummer efterfulgt af et kolon og derefter
            hvilke produkter der produceres på den pågældende dag. I tilfælde
            af flere produkter på samme dag, skal de skrives i alfabetisk
            rækkefølge.

    Eksempel:

      Input:    2 8
                table chair
                2 3

      Output:   2: table
                3: chair
                4: table
                6: chair table
                8: table

    [ENGLISH PROBLEM STATEMENT]

#< DK
    A factory produces a range of products, and each product takes a fixed
    number of days to produce.
    For example, if a factory produces tables and chairs and a table takes
    2 days to produce while a chair takes 3 days to produce, then nothing will
    be produced on day 1, but on day 2 they produce a table, day 3 a chair,
    day 4 a table, day 5 nothing and day 6 both a table and a chair, and so on.

    You must compute what is produced on each of the days given the
    production information.
    Input:  First line contains two integers n and R. n <= 10 and R <= 100.
            The second line contains n strings separated by spaces. Each
            string is the name of a product produced by the factory. Each
            string has at most 15 characters.
            The third line contains n integers, corresponding to the
            construction time of the n products.

    Output: One line for each day the factory produces something. Each line
            contains the day number followed by a colon, and then the output
            of the factory of that day. In the case of multiple products on the
            same day, you must write them in alphabetical order, separated by
            spaces.

    Example:

      Input:    2 8
                table chair
                2 3

      Output:   2: table
                3: chair
                4: table
                6: chair table
                8: table
'''

# insert code
pass
#> solution
n, R = map(int, input().split())
items = input().split()
production_times = list(map(int, input().split()))
#< solution
#> validate input
assert n <= 10
assert R <= 100
assert n == len(items) == len(production_times)
assert all(len(item) <= 15 for item in items)
#< validate input
#> solution
for day in range(1, R + 1):
    print_list = []
    for i in range(n):
        if day % production_times[i] == 0:
            print_list.append(items[i])
    if print_list:
        print(str(day) + ":" + " " + " ".join(sorted(print_list)))
#< solution

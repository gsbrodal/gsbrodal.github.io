'''
    SORT STRING

#> DK
    [DANSK PROBLEMFORMULERING]

    Lav en funktion sort_string der tager en streng af store bogstaver,
    sorterer den alfabetisk og returnerer den.

    Input:  En streng bestående af af kun store bogstaver (fra A til Z)
            med højest 200 bogstaver.

    Output: En streng med de samme bogstaver som inputtet i alfabetisk
            rækkefølge.

    Eksempel:

      Input:    ALPHABEAT

      Output:   AAABEHLPT

    Bemærk: Nedenstående kode tager allerede højde for input og kald
            til funktionen sort_string. Du skal udelukkende implementere
            funktionen sort_string.

            
    [ENGLISH PROBLEM STATEMENT]

#< DK
    Write a function sort_string that takes a string of upper-case letters
    and returns the same string where the letters are sorted alphabetically.

    Input:  A string containing only capital letters (from A to Z) with at most
            200 letters.

    Output: A string with the same letters as the input but sorted
            alphabetically.

    Example:

      Input:  ALPHABEAT

      Output: AAABEHLPT

    Note: The below code already reads the input and calls the function
          sort_string. You only need to implement the function sort_string.

'''


def sort_string(word):
    # insert code
    pass
#> solution
    return "".join(sorted(word))
#< solution


word = input()
#> validate input
assert len(word) <= 200
#< validate input
print(sort_string(word))

'''
    PHOTO FINISH

    We want to recreate the photo at the end of a race. You are given a
    list of contestants in a race and how far they ran when the photo was
    taken.
    If there were three contestants in the race, with Anna running 25 meters,
    Bob won with 50 meters, and Charlie running 40 meters, we would like the
    following photo:
        --------+-------------------------------------------------+
        Anna....|........................A........................|
        --------+-------------------------------------------------+
        Bob.....|.................................................B
        --------+-------------------------------------------------+
        Charlie.|.......................................C.........|
        --------+-------------------------------------------------+
    The first vertical line is the start line and the second is the finish
    line. All the contestants names are written before the start line, such
    that there is exactly one "." after the longest name. Every runner is
    marked on the track by their initial.
    The runner with the longest distance is the winner and thus the finish line
    is drawn where they are. In the example above, the race is 50 meters long,
    so there are 49 "-"-symbols followed by the finish line. If a runner ran 0
    meters they are drawn on top of the start line.

    Input:  The first line contains the names of the contestants. There are at
            most 10 contestants and their names have at most 15 characters
            each.
            The second line has the lengths each contestant ran. Each
            contestant ran at most 60 meters, and the winner ran at least 1
            meter.

    Output: The photo of the race as the first contestant crossed the finish
            line.
            Print the contestants in the order they appear in the input.

    Example:

      Input:    Anna Bob Charlie
                25 50 40

      Output:   --------+-------------------------------------------------+
                Anna....|........................A........................|
                --------+-------------------------------------------------+
                Bob.....|.................................................B
                --------+-------------------------------------------------+
                Charlie.|.......................................C.........|
                --------+-------------------------------------------------+
'''

# insert code
pass

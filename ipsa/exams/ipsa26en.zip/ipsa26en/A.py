'''
    SORT STRING

    Write a function sort_string that takes a string of upper-case letters
    and returns the same string where the letters are sorted alphabetically.

    Input:  A string containing only capital letters (from A to Z) with at most
            200 letters.

    Output: A string with the same letters as the input but sorted
            alphabetically.

    Example:

      Input:  ALPHABEAT

      Output: AAABEHLPT

    Note: The below code already reads the input and calls the function
          sort_string. You only need to implement the function sort_string.

'''


def sort_string(word):
    # insert code
    pass


word = input()
print(sort_string(word))

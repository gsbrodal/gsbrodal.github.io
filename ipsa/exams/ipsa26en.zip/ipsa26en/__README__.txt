
INTRODUCTION TO PROGRAMMING WITH SCIENTIFIC APPLICATIONS
========================================================

  * Exam June 20, 2026.

  * Aids: Own computer, internet access not allowed (except for downloading the
    exam and submitting your exam answers on wiseflow.au.dk, and running the
    WISEflow device monitor.)

  * WISEflow Device Monitor must be activated throughout the exam.

  * It is not allowed to communicate with others during the exam.

  * It is not allowed to use an AI assistant like, e.g., ChatGPT and GitHub
    Copilot. Locally installed AI assistants on your computer are also not
    allowed.

  * When reusing code, e.g., from course slides, you must put a comment in your
    code with a reference to the source.
  
  * The exam questions are downloaded and your answers submitted to
    wiseflow.au.dk as a single zip file.

      Files provided at the exam:

      A.py, B.py...: Exam questions. The question statements are contained in 
                     the doc-strings in the header of the files. Your exam
                     submission consists of uploading these files with inserted
                     code.

      tests        : A folder with examples of test input for all questions 
                     and the corresponding correct output.

      run_tests.py : A program to run all the provided test inputs.

  * Weight of the questions (questions are not weighted equally):

     Problem  Point  Name

        A        6    SORT STRING
        B        6    BIG RED BALL
        C        6    PRODUCTION LINE
        D        6    CHESS EVALUATION
        E        6    PHOTO FINISH
        F       10    DUCKS ON DUCKS
        G       10    CREDIT CARD
        H       10    RIPPLES
        I       10    DELAYED
        J       10    POINT LOCATION
        K       10    RESERVOIR
        L       10    MINIMAL PALLINDROME PARTITION

    Total 100 points

  * The final submission must be a single zip file with your solutions

       A.py, B.py, ... and the file run_tests.log.

    It is recommended to submit the complete exam folder including tests,
    non-answered questions etc.
    
    Information on how to create a zip file under macOS and Windows can 
    be found here:

       https://support.apple.com/en-gb/guide/mac-help/mchlp2528/mac
       https://support.microsoft.com/en-us/help/14200/windows-compress-uncompress-zip-files

    Before submitting your solutions it is strongly recommended you run the
    script run_tests.py a final time on all your solutions. The result of
    running the test script is logged throughout the exam in the file
    run_tests.log. As a control during the grading after the exam, the content
    of run_tests.log is compared with subsequent testing to ensure consistent
    evaluation with the score you experienced obtained during the exam.
 
  * The questions should be answered using Python 3.14. You are only allowed to 
    use the standard modules installed with Python (cf. 
    https://docs.python.org/3/library/, e.g., random, math, collections, etc.).

  * Submissions CANNOT be done as a Jupyter Notebook.

  * The question statements contain some input constraints, e.g., that 
    1 <= n <= 10. It is guaranteed that all test inputs for the question satisfy
    these constraints. This is not something that you need to check (using,
    e.g., assertions). The hidden test cases used for testing after the exam
    will also satisfy these constraints.

  * The script run_tests.py can be invoked in various ways, which is described
    in the header of the file.

  * The script run_tests.py terminates your programs after 5 seconds. 5 seconds
    should be sufficient to get the majority of the test inputs accepted. For
    some of the questions some inputs might require that your code is
    sufficiently fast to get the last test inputs accepted. During the
    evaluation after the exam, slightly more time will be allowed.
    
  * You do not get points if you hard code the test inputs and outputs in
    your solution. For each test input available during the exam you should 
    expect that the hidden test cases contain an input of the same "type",
    such that for each test input accepted during the exam, one should also 
    pass the corresponding hidden test case after the exam.

  * For the grading, code structure and readability have limited influence on
    the final grade. Focus will be on the functionality, i.e., how many test
    cases are accepted. But likely, more structured code has a higher chance to
    work correctly on more inputs.
    
  * You are not expected to provide comments and docstrings in your solutions,
    except for the required comments with the references to your sources when
    you reuse/modify existing code.

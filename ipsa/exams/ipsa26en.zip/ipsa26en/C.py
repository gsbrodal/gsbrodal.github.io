'''
    PRODUCTION LINE

    A factory produces a range of products, and each product takes a fixed
    number of days to produce.
    For example, if a factory produces tables and chairs and a table takes
    2 days to produce while a chair takes 3 days to produce, then nothing will
    be produced on day 1, but on day 2 they produce a table, day 3 a chair,
    day 4 a table, day 5 nothing and day 6 both a table and a chair, and so on.

    You must compute what is produced on each of the days given the
    production information.
    Input:  First line contains two integers n and R. n <= 10 and R <= 100.
            The second line contains n strings separated by spaces. Each
            string is the name of a product produced by the factory. Each
            string has at most 15 characters.
            The third line contains n integers, corresponding to the
            construction time of the n products.

    Output: One line for each day the factory produces something. Each line
            contains the day number followed by a colon, and then the output
            of the factory of that day. In the case of multiple products on the
            same day, you must write them in alphabetical order, separated by
            spaces.

    Example:

      Input:    2 8
                table chair
                2 3

      Output:   2: table
                3: chair
                4: table
                6: chair table
                8: table
'''

# insert code
pass

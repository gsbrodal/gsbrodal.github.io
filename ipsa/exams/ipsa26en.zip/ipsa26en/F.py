'''
    DUCKS ON DUCKS

    A favorite activity among ducks is to stack on top of each other.
    Ducks can stand on top of each other in a pyramid shape, so that a
    duck can stand on the sholders of two other ducks; like so:
    (where "D" represents a duck)
            D
           D D D
          D D D D
    Some of the ducks have requirements on how far up they want to be in the
    duck tower. You are tasked to compute the minimum number of ducks needed to
    fullfill every ducks wishes.

    Input:  The first line contains an integer n, the number of ducks with
            required heights. 1 <= n <= 5000.
            The second line contains n integers, the surveyed levels the ducks
            wish to be on. A wish of "0" would correspond to standing on the
            ground. Every wish is between 0 and 5000.

    Output: The number of ducks needed to make a stable tower, fulfilling
            every ducks wish.

    Example:

      Input:    10
                1 0 3 1 2 1 2 2 1 1

      Output:   15

    Explanation of example:
        Because the ducks could be arranged into a tower like this:

              D
           D D D
          D D D D D
         D D D D D D
        It was here neccesary to add 5 extra ducks on the bottom layer.

    Note:   The below code reads n and the ducks wishes and saves them in
            the list "heights"
'''


n = int(input())
heights = list(map(int, input().split()))
# insert code

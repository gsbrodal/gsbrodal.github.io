'''
    MINIMAL PALLINDROME PARTITION

    A palindrome is a string that can be written the same forwards and
    backwards like "ABBA" and "ABACABADABACABA".
    A palindrome partition of a string consists of seperating the string into
    consecutive palindromic substrings.
    I.e. the string "DABADAADAADAA" can be partitioned into the strings: D,
    ABA, DAAD, AADAA. I.e. four palindromic substrings.
    A minimal palindromic partition is a palindromic partition that seperates
    the string into a minimal number of palindromic substrings. The string
    from before can be seperated into two palindromic substrings: DABAD,
    AADAADAA, and this is minimal.

    Your task is to compute all minimal palindrome partitions of a string.

    Input:  A string of at most 1000 uppercase letters (A-Z).

    Output: All the minimal palindrome partitions, one on each line, where
            the partition is space seperated.
            In the case where there are multiple partitions, order them
            alphabetically, when considered as a single string.
            The inputs guarentee, that there are at most 100 minimal palindrome
            partitions.

    Example:

      Input:    DABADAADAAD

      Output:   D ABA DAADAAD
                DABAD AA DAAD
                DABAD AADAA D


    Note:   Some of the test cases will only have one minimal palindromic
            partition. Thus, you can get some points by printing a single
            partition.

'''

# insert code
pass

'''
    CREDIT CARD

    Your task is to create a class CreditCard that stores the balance of
    an account and supports the following operations, where c denotes an
    instance of the CreditCard class:

        CreditCard()                            - Creates a credit card with
                                                 a starting balance of 0.
        CreditCard(amount)                      - Creates a credit card with
                                                 a starting balance of amount.
        c.get_balance()                         - Returns the current balance
                                                 of the credit card.
        c.add_to_balance(amount)                - Adds amount to the current
                                                 balance.
        c.purchase_item(name, price)            - Buys an item called name and
                                                 subtracts the price from the
                                                 balance.
        c.print_last_purchases(number_of_items) - Prints the last
                                                 number_of_items purchased
                                                 items

    In the above methods amount and price must be greater than or equal 0.
    A cards balance may not be negative. If one tries to buy something, that
    would bring the balance to negative, instead an InsufficientFundsError
    should be raised.
    The function print_last_puchases prints the names of the last
    number_of_items bought items. The names must be seperated by space on a
    single line, where the first bought item is printed first. If
    print_last_purchases is called with a larger number than the number of
    purchased items, all bought items must be printed instead.

    Input:  Multiple lines of Python code using the CreditCard class.
            The final input line is #eof.

    Output: The result of executing the Python code.

    Example:

      Input:    c = CreditCard(500)
                c.add_to_balance(100)
                print(c.get_balance())
                c.purchase_item("Shoe", 500)
                print(c.get_balance())
                c.add_to_balance(200)
                c.purchase_item("Jacket", 150)
                print(c.get_balance())
                c.print_last_purchases(1)
                c.print_last_purchases(3)
                c.purchase_item("Bag", 300)

      Output:   600
                100
                150
                Jacket
                Shoe Jacket
                InsufficientFundsError

    Note: You should only implement the missing methods in the class
    CreditCard. The code below already implements InsufficientFundsError,
    reads the input, and executes the code.
'''


class InsufficientFundsError(Exception):
    pass


class CreditCard:
    # insert code
    pass



import sys
code = ''
for line in sys.stdin:
    code += line
    if code.startswith('#eof'):
        break
try:
    exec(code)
except InsufficientFundsError:
    print("InsufficientFundsError")

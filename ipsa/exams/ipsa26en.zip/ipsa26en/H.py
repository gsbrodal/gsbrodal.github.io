'''
    RIPPLES

    A stone is dropped in a rectangular pond. It is your task to draw the
    ripples formed in the pond. As the pond is rectangular, the ripples will be
    diamond shaped (see below).

    You are given the size of the pond (m wide and n heigh), the coordinate of
    where the stone is dropped (x, y) and the distance between ripples (d).

    You must print an mxn grid of "."-characters with "#"-characters
    representing the ripples. For instance, if the pond is 18x10 and a stone is
    dropped at (5,7) with distance 4 between ripples, the print will look like
    this:

      0 #...#.#...#...#...
        ...#...#...#...#..
        ..#.....#...#...#.
        .#...#...#...#...#
        #...#.#...#...#...
        ...#...#...#...#..
        ..#.....#...#...#.
      7 .#...#...#...#...#
        ..#.....#...#...#.
      9 ...#...#...#...#..
        0    5           17

    Input:  A line with 5 integers separated by spaces: m n x y d
            with the restrictions:
                0 <= x < m <= 70
                0 <= y < n <= 70
                2 <= d <= 10

    Output: The print of the pond with ripples

    Example:

      Input:    12 11 4 6 4

      Output:   ..#...#...#.
                .#.....#...#
                #...#...#...
                ...#.#...#..
                ..#...#...#.
                .#.....#...#
                #...#...#...
                .#.....#...#
                ..#...#...#.
                ...#.#...#..
                #...#...#...

    Note:   The below code reads the values from the input.
'''

m, n, x, y, d = map(int, input().split())

# insert code

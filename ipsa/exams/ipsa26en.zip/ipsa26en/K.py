'''
    RESERVOIR

    Your task is to calculate the amount of water that can fit in a reservoir.
    The reservoir, however, has a very peculiar shape. It is fixed between two
    mountains, so we can consider it to be a 2D construction. You are given its
    width in meters and the elevation of the concrete in meters. For water to
    fit in the reservoir, it must have concrete to the left and right of it.

    For instance, if you have a reservoir that is 8 wide and the elevations are
    5 1 2 3 8 4 2 7, the concrete part of the reservoir looks like this:

            #
            #  #
            #  #
        #   #  #
        #   ## #
        #  ### #
        # ######
        ########
        51238426

    Pouring water, until we start spilling, we get water in the cells marked
    with an "o":

            #
            #oo#
            #oo#
        #ooo#oo#
        #ooo##o#
        #oo###o#
        #o######
        ########

    In total, we have space for 17 m^2 of water.

    Input:  The first line contains an integer n, with n <= 10_000.
            The second line contains n integers seperated by spaces. These
            are the heights of the reservoir.
            Each are no larger than 1_000_000.

    Output: A single integer, equal to the total amount of water possible to
            fit in the reservoir.

    Example:

      Input:    8
                5 1 2 3 8 4 2 7

      Output:   17
'''

# insert code
pass

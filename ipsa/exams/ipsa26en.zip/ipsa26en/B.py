'''
    BIG RED BALL

    The local toy factory makes many different toys in different shapes,
    colors and sizes.

    They have two important rules:
        - If a toy has size BIG, it must have shape ROUND.
        - If a toy has color RED, it must have shape POINTY.

    Make a function valid_toy, that takes a size, color, and shape, and
    determines if it adheres to the above rules or not.
    If it is valid according to the above rules, return True, otherwise return
    False.

    Input:  The first line of the input contains an integer n where
            1 <= n <= 200.
            The next n lines contain three upper case strings separated by
            spaces. Each string is at most 15 characters and correspond to a
            size, color and shape.

    Output: n lines of either True or False corresponding to whether
            each line is a legal toy.

    Example:

      Input:    5
                BIG GREEN SQUARE
                MEDIUM RED POINTY
                BIG RED ROUND
                SMALL GREEN ROUND
                HUGE BLUE BLOBBY

      Output:   False
                True
                False
                True
                True


    Note: The below code already reads the input and calls the function
          valid_toy. You only need to implement the function valid_toy.
'''


def valid_toy(size, color, shape):
    # insert code
    pass


n = int(input())
for _ in range(n):
    color, size, shape = input().split()
    print(valid_toy(color, size, shape))

'''
    POINT LOCATION

    Your task is to implement a function locate_point(grid), that finds a
    target point in a 2D grid. You have two methods to explore the grid:
    grid.get_dims() and grid.test_point(point).
    grid.get_dims() returns two integers, being the width and height of the
    grid.
    grid.test_point(point) takes a tuple of two integers (representing a point
    in the grid) as input and returns one of four strings depending on the
    relation between the input point and the secret point:
        "EXACT"   -     The input point is equal to the secret point.
        "SMALLER" -     The input point is not equal to the secret point, but
                        both the coordinates of the input point are less than
                        or equal to the corresponding coordinates of the secret
                        point.
        "LARGER"  -     The input point is not equal to the secret point, but
                        both the coordinates of the input point are greater
                        than or equal to the corresponding coordinates of the
                        secret point.
        "MIXED"   -     None of the above options.

    Here is an example of the answers you would get by testing the points of a
    5x5 grid where the secret point is (3,1) (where "E" is EXACT, "S" is
    SMALLER, "L" is LARGER and "M" is MIXED):

                4|MMMLL
                3|MMMLL
            y   2|MMMLL
                1|SSSEL
                0|SSSSM
                -+-----
                 |01234
                    x

    For instance, if the grid is a 5x5 grid and the secret point is (3,1) the
    grid could be explored as follows:

        grid.get_dims()         # returns (3,3)
        grid.get_dims()         # returns (5,5)
        grid.test_point((1,1))  # returns "SMALLER"
        grid.test_point((3,3))  # returns "LARGER"
        grid.test_point((2,2))  # returns "MIXED"
        grid.test_point((1,3))  # returns "MIXED"
        grid.test_point((3,1))  # returns "EXACT"


    Input:  Python code that defines a class Grid with methods get_dims and
            test_point. Last line contains #eof.
            The height and width of the Grid are at most 1_000_000_000.

    Output: The result of calling locate_point with an instance of Grid() as
            the only argument. i.e., a single line with a pair of integers
            equal to the secret point.

    Example:
        Assume the input code implements a class Grid with a 5x5 grid with the
        secret point being (3,1)

      Input:    class Grid:
                    def get_dims(self): ...
                    def test_point(self, point): ...

      Output:   (3, 1)

    Note: The below code already reads the Grid class definition, and calls the
        function locate_point with an instance of Grid. You only need to
        implement the function locate_point.
'''


def locate_point(grid):
    # insert code
    pass


import sys
code = ''
for line in sys.stdin:
    code += line
    if code.startswith('#eof'):
        break
exec(code)
point = locate_point(Grid())
print(point)

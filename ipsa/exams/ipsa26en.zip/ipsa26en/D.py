'''
    CHESS EVALUATION

    From a position of chess, determine the score of the position.

    The board is an 8x8 grid where an empty square is marked with a "." and
    a square with a piece is marked by the corresponding letter (see below).
    It is a white piece if it is upper case and black if it is lower case. The
    score of the position is the total points of the white pieces minus the
    total points of the black pieces.

    The different pieces with points are:
        King    (K) - 2 points
        Queen   (Q) - 9 points
        Rook    (R) - 5 points
        Bishop  (B) - 3 points
        Knight  (N) - 3 points
        Pawn    (P) - 1 point

    You must write a function evaluate_position, that given a board as a string
    computes the point evaluation of a position. The input to the function is
    the 8 lines of the input seperated by '\n' characters.

    Example:
        In the following position:
            ........
            ........
            ...pbp..
            ....p..k
            PP..R...
            ..P.....
            r.......
            ..K.....
        White has a king, a rook and three pawns. Black has a king, a rook, a
        bishop and three pawns.

        White has 2 + 5 + 3 * 1 = 10 points
        Black has 2 + 5 + 3 + 3 * 1 = 13 points
        So the evaluation is 10 - 13 = -3

    Input:  8 lines, each with 8 characters corresponding to the board of a
            chess game.

    Output: A single integer, being the score of the position.

    Example:

      Input:    ........
                ........
                ...pbp..
                ....p..k
                PP..R...
                ..P.....
                r.......
                ..K.....

      Output:   -3

    Note: You do not need to do any chess specific evaluations, like consider
    checks, captures or the like. We only care about the material on the board.
    The position is not necessarily achievable through normal play.
    Furthermore, the below code already reads the input and calls the function
    evaluate_position. You only need to implement the function
    evaluate_position.
'''


def evaluate_position(position):
    # insert code
    pass


print(evaluate_position("\n".join([input() for _ in range(8)])))

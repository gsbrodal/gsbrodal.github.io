'''
    DENSE SAMPLE

    Given a list of positive weights, the task is to find a subsequence (sample)
    of the weights such that 1) the subsequence has minimum sum, 2) among every
    three consecutive weights in the lists, at least one of them is in the 
    sample. It is guaranteed that there is a unique minimum weight solution.

    Input:  A single Python list L of integers (weights), where 
            3 <= len(L) <= 100 and all elements are between 1 and 1000.

    Output: A single line with a Python list of strictly increasing indexes 
            into L defining a sample, where the weights in the sample have
            minimum sum, and among every three consecutive indexes into L, 
            at least one is in the sample.

    Example:

      Input:  [7, 5, 7, 5, 7, 6, 7]

      Output: [1, 4]

      Explanation: In the input list L, L[1] + L[4] = 5 + 7 = 12 achieves the 
      minimum possible weight sum, if for all three consecutive indexes at least 
      one index is in the sample.
    
    Note: The below code already reads the input list L.
'''


L = eval(input())
#> validate input
assert 3 <= len(L) <= 100
assert all(isinstance(x, int) and 1 <= x <= 1000 for x in L)
#< validate input

# insert code
pass
#> solution

from functools import cache

@cache
def solve(i):
    '''Return (minimum cost, list of all solutions for L[:i]).'''

    if i == 0:
        return 0, [[]]
    C = []
    for j in range(max(0, i - 3), i):
        if j < 3:
            C.append((L[j], [j]))
        else:
            cost, solutions = solve(j)
            C.extend((cost + L[j], solution + [j]) for solution in solutions)
    min_cost = min(cost for cost, solution in C)
    return min_cost, [solution for cost, solution in C if cost == min_cost]

cost, solutions = solve(len(L))
solution = solutions[0]
#< solution
#> validate input
assert len(solutions) == 1
#< validate input
#> solution
print(solution)
#< solution

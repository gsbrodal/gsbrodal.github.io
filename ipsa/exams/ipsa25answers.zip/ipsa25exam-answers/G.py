'''
    ABC PERMUTATIONS

    Given three integers a, b, and c, print in alphabetical order all possible 
    strings containing a, b and c occurrences of 'A', 'B' and 'C', respectively.

    Input:  A single line with three integers a, b, and c separated by spaces,
            where a >= 0, b >= 0, c >= 0 and 1 <= a + b + c <= 10.
            
    Output: All possible strings, one string per line, containing a occurrences 
            of 'A', b occurrences of 'B', and c occurrences of 'C'. The strings 
            should be printed in alphabetical order, without any repetitions.
  
    Example:

      Input:  2 1 1

      Output: AABC
              AACB
              ABAC
              ABCA
              ACAB
              ACBA
              BAAC
              BACA
              BCAA
              CAAB
              CABA
              CBAA
'''


#> solution
def ABC_permutations(a, b, c, prefix=''):
    if a == b == c == 0:
        print(prefix)
    if a: ABC_permutations(a - 1, b, c, prefix + 'A')
    if b: ABC_permutations(a, b - 1, c, prefix + 'B')
    if c: ABC_permutations(a, b, c - 1, prefix + 'C')


#< solution
a, b, c = map(int, input().split())

# insert code
pass
#> validate input
assert 0 <= min(a, b, c)
assert 1 <= a + b + c <= 10
#< validate input
#> solution
ABC_permutations(a, b, c)
#< solution

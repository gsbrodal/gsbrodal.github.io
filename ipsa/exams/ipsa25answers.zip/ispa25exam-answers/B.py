'''
    SORT LINES

    Input:  The first line contains an integer n, 1 <= n <= 10. Each of the 
            following n line contains a string consisting of between 1 and 25 
            capital letters.

    Output: The n lines sorted in alphabetic order.

    Example:

      Input:  3         
              PETER
              ANDERS
              CASPER

      Output: ANDERS
              CASPER
              PETER
'''


# insert code
pass
#> solution
n = int(input())
lines = [input() for _ in range(n)]
#< solution
#> validate input
assert 1 <= n <= 10
assert all(1 <= len(line) <= 25 for line in lines)
assert all(char.isupper() for line in lines for char in line)
#< validate input
#> solution
for line in sorted(lines):
    print(line)
#< solution

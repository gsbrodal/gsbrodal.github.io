'''
    STRING REVERSAL

    Print a string reversed

    Input:

        A single line with a non-empty string S with at most 100 letters from A-Z

    Output:

        A single line with S in reversed

    Example:

      Input:  ABCDEFG

      Output: GFEDCBA
'''


pass  # insert your code here

'''
    FORBIDDEN

    Your task is to read a string S and a string F of forbidden characters,
    and to print S with all characters from F replaced by '*'.

    Input:

        The first line contains a string S with at most 100 characters.
        The second line contains a non-empty string F,
        where all characters are distinct.
      
    Output:

        Print the line S with all occurrences of characters in F replaced by '*'.

    Example:

      Input:  Things don't always work out the first time, but keep trying
              tone

      Output: Thi*gs d**'* always w*rk *u* *h* firs* *im*, bu* k**p *ryi*g
'''


pass  # write your code here

import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(-1, 1, 50)
plt.plot(x, np.sqrt(1 - x ** 2), 'r.-')
plt.plot(x, -np.sqrt(1 - x ** 2), 'b.-')
plt.show()

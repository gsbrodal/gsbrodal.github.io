import matplotlib.pyplot as plt
import math

n = 25

x = [2 * math.pi * i / (n - 1) for i in range(n)]
y = [math.sin(v) for v in x]

plt.plot(x, y, '.')
plt.show()

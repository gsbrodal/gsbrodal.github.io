import matplotlib.pyplot as plt
import numpy as np

n = 25

x = np.linspace(0, 2*np.pi, n)
y = np.sin(x)

plt.plot(x, y, '.')
plt.show()

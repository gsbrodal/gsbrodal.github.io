import numpy as np
import cv2  # Computer Vision, opencv.org
import matplotlib.pyplot as plt
 
color = cv2.imread('university.jpg')            # color image
gray = cv2.cvtColor(color, cv2.COLOR_BGR2GRAY)  # convert to gray

print(f'{type(gray)=} {gray.shape=} {gray.dtype=} {np.min(gray)=} {np.max(gray)=}')

#u, s, v = np.linalg.svd(gray)  # Calculating the SVD
u, s, v = np.linalg.svd(gray, full_matrices=False)
 
print(f'{u.shape=}, {s.shape=}, {v.shape=}')

for i, r in enumerate([1, 5, 10, 15, 20, 50, 100, 150], start=1):
    rank_r = u[:, :r] @ np.diag(s[:r]) @ v[:r, :]
    plt.subplot(3, 3, i)
    plt.imshow(rank_r, cmap='gray', vmin=0, vmax=255)
    plt.title(f'{r} components')
    plt.axis('off')
plt.subplot(3, 3, 9)
plt.imshow(gray, cmap='gray')
plt.title(f'Original image {gray.shape[0]} x {gray.shape[1]}')

plt.show()

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.image import imread

color = imread('university.jpg')  # use matplotlib to read image
color = color / 255  # convert integers 0..255 to floats 0..1

plt.subplot(4, 2, 8)
plt.imshow(color)
plt.axis('off')
plt.title(f'Original')

print(f'{type(color)=} {color.shape=} {color.dtype=} {np.min(color)=} {np.max(color)=}')

height, width, colors = color.shape

u, s, v = np.linalg.svd(color.reshape((height, width * colors))) #, full_matrices=False)
 
print(f'{u.shape=}, {s.shape=}, {v.shape=}')

for i, r in enumerate([1, 2, 5, 10, 25, 50, 125], start=1):
    rank_r = u[:, :r] @ np.diag(s[:r]) @ v[:r, :]
    plt.subplot(4, 2, i)
    plt.imshow(rank_r.reshape((height, width, colors)))
    plt.title(f'{r} components')
    plt.axis('off')
plt.show()

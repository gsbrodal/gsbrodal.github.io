import matplotlib.pyplot as plt
import numpy as np

a = np.linspace(0, 2*np.pi, 100)
x = np.sin(a)
y = np.cos(a)
plt.plot(x, y, 'r.-')
plt.plot(x[0], y[0], 'bo')
plt.show()

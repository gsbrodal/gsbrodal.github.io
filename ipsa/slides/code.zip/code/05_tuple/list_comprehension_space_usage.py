input('press enter')
points = [(x, x + 1) for x in range(10_000_000)]
input('press enter')
selected = [(x, y) for (x, y) in points if y == x + 1]
input('press enter')
selected = [point for point in points if point[1] == point[0] + 1]
input('press enter')

input('press enter')
points = [(x, x + 1) for x in range(10_000_000)]
input('press enter')
selected = []
for point in points:
    x, y = point  # unpack tuple
    if y == x + 1:
        selected.append(point)  # append original tuple
input('press enter')
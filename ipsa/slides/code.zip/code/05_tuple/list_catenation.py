import matplotlib.pyplot as plt
from timeit import timeit

ns = range(2, 11)
P, S = [], []
for n in ns:
    setup = 'A = list(range(10))'
    plus = ' + '.join(['A'] * n)
    star = '[' + ', '.join(['*A'] * n) + ']'
    print(f'{n=}, {plus=}, {star=}, {setup=}')
    P.append(timeit(plus, setup=setup))
    S.append(timeit(star, setup=setup))
    
plt.plot(ns, P, '.-', label='A + ... + A')
plt.plot(ns, S, '.-', label='[*A, ..., *A]')
plt.legend()
plt.ylabel('time (sec $10^{-6}$)')
plt.xlabel('number of As')
plt.show()

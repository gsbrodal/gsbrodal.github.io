/**
 * A Java docstring to be processed using 'javadoc'
 */
// comment until end-of-line
public class Primitive {
    public static void main( String[] args ) {
	int x;  // type of variable must be declared before used
	x = 1;  // remember ';' after each statement
      int y=2;  // indentation does not matter
          int a=3, b=4;  // multiple declarations and initialization 
	System.out.println(x + y + a + b);
	  int[] v={1, 2, 42, 3};  // array of four int
     System.out.println(v[2]);  // prints 42
/* a multi-line comment
   that continues until here */
           v = new int[3]; // new array of size 3, with zeros
	System.out.println(v[2]);
	if (x == y) {  // if syntax '(' and ')' mandatory
	    a = 1;
	    b = 2; 
	} else { // use '{' and '}' to create block of statements
	    a = 4; b = 3; // two statements on one line
	}
    }
}

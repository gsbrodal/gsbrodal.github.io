def f(x, y=None):
    if y == None:
        y = x
    if type(x) is int:
        return x * y
    else:
        return x + y

print(f(7), f(3, 4), f('abc', 'def'))

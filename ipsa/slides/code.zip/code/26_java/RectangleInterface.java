interface Shape {
    public int area(); // method declaration
}
class Rectangle implements Shape {
    private int width, height;
    // constructor, class name, no return type
    public Rectangle(int width, int height) {
	this.width = width; this.height = height;
    }
    public int area() {
	return width * height;
    }
}
public class RectangleInterface {
    public static void main( String[] args ) {
	Shape r = new Rectangle(6, 7);
	System.out.println(r.area());
    }
}

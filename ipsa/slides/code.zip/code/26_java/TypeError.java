public class TypeError {
    public static void main( String[] args ) {
	int x = 3;
	String y = "abc";
        System.out.println(x / y);
    }
}

public class Functions {
    private static int f(int x) {
	return x * x;
    }
    private static int f(int x, int y) {
	return x * y;
    }
    private static String f(String a, String b) {
	return a + b; // string concatenation
    }

    public static void main( String[] args ) {
	System.out.println(f(7));
	System.out.println(f(3, 4));
	System.out.println(f("abc", "def"));
    }
}

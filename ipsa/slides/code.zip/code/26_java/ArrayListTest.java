import java.util.*;

public class ArrayListTest {
    public static void main( String[] args ) {
	ArrayList<String> a = new ArrayList<String>();
	List<String> b = new ArrayList<String>();
	ArrayList<String> c = new ArrayList<>();
	List<String> d = new ArrayList<>();
	var e = new ArrayList<String>();
	var v = Math.floor(1.5);

	System.out.println(v);

	a.add("A");
	b.add("B");
	c.addAll(a);
	c.addAll(b);
	d.addAll(c);
	e.addAll(d);
	
	for (String x : e) {
	    System.out.println(x);
	}
    }
}

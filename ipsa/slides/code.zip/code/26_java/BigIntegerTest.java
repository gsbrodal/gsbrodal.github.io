// import java.math.*;
import java.math.BigInteger;

public class BigIntegerTest {
    public static void main( String[] args ) {
        BigInteger x = new BigInteger("2");
        while (true) {
            x = x.multiply(x);
            System.out.println(x);
        }
    }
}

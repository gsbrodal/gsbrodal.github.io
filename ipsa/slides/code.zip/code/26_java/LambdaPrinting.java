import java.util.*; // ArrayList

public class LambdaPrinting {
    public static void main(String[] args) {
		var elements = new ArrayList<Integer>();

		for (int i=1; i <= 3; i++)
	    	elements.add(i);

       	elements.forEach(e -> System.out.println(e));

		List<Integer> es = elements.stream().map(e -> e + 42).collect(Collectors.toList());
		for (var e : es)
			System.out.println(e);
	};
}

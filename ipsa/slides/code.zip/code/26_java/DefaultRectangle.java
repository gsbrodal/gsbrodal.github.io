interface Shape {
    public int circumference(); 
    public int area(); // method declaration
    default public double fatness() {
         // convert int from area() to double before /
	return (double)area() / circumference();
    }
}

class Rectangle implements Shape {
    private int width, height;
    // constructor, class name, no return type
    public Rectangle(int width, int height) {
	this.width = width; this.height = height;
    }
    public int area() {
	return width * height;
    }
    public int circumference() {
	return 2 * (width + height);
    }
}

public class DefaultRectangle {
    public static void main( String[] args ) {
	Shape r = new Rectangle(6, 7);
	System.out.println(r.fatness());
    }
}

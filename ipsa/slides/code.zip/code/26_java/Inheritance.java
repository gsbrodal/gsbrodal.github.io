class BasicRectangle {
    // protected allows subclass to access attributes
    protected int width, height;
    public BasicRectangle(int width, int height) {
	this.width = width; this.height = height;
    }
}

class Rectangle extends BasicRectangle {
    public Rectangle(int width, int height) {
	// call constructor of super class
	super(width, height);
    }
    public int area() {
	return width * height;
    }
}

public class Inheritance {
    public static void main( String[] args ) {
	Rectangle r = new Rectangle(6, 7);
	System.out.println(r.area());
    }
}

class Rectangle {
    private int width, height;

    // constructor, class name, no return type
    public Rectangle(int width, int height) {
	this.width = width; this.height = height;
    }

    public Rectangle(int side) {
	width = side; height = side;
    }

    public int area() {
	return width * height;
    }
}

public class AClass {
    public static void main( String[] args ) {
//	Rectangle r = new Rectangle(6, 7);
	Rectangle r = new Rectangle(8);
	System.out.println(r.area());
    }
}

interface A {
    default public void sayA() { System.out.println("say A"); }
    default public void sayHi() { System.out.println("A say's Hi"); }
}
interface B {
    default public void sayB() { System.out.println("say B"); }
    default public void sayHi() { System.out.println("B say's Hi"); }
}
class C implements A, B {
    @Override // (optional) requests compiler to 
              // check if sayHi exists in supertype
    public void sayHi() {
	System.out.println("C say's Hi");
	(new A(){}).sayHi();  // instantiate an anonymous class
    }
    public void test() {
	sayA();
	sayB();
	sayHi();
    }
}
public class MultipleInheritance {
    public static void main( String[] args ) {
	new C().test();
    }
}

x = 3
y = "abc"
print("program running...")
print(x / y)

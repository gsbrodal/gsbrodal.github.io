class Pair<element> {
    private element x, y;
    
    public Pair(element x, element y) {
	this.x = x; this.y = y;
    }

    element first() { return x; }
    element second() { return y; }
}

public class GenericPair {
    public static void main( String[] args ) {
        var p = new Pair<Integer>(6, 7);
	System.out.println(p.first() * p.second());
    }
}

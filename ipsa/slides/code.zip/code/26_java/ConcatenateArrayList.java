import java.util.*;

public class ConcatenateArrayList {
    public static void main( String[] args ) {
	ArrayList<String> a = new ArrayList<String>();
	ArrayList<String> b = new ArrayList<String>();
	ArrayList<String> c = new ArrayList<String>();

	a.add("A1");
	a.add("A2");
	b.add("B1");
	
	c.addAll(a);
	c.addAll(b);

	for (String e : c) {
	    System.out.println(e);
	}
    }
}

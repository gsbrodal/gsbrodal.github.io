L = [3, 5, 7]
try:
    L[4]
except IndexError:
    print("IndexError")
except Exception:
    print("Fall back exception handler")
    

import os.path

filename = input("Filename: ")
if os.path.isfile(filename):
    print("file exists")
else:
    print("file does not exist")

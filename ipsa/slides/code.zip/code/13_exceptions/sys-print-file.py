import sys

def complicated_function(file):
    print('Hello world', file=file)

while True:
    file_name = input('Output file (empty for STDOUT): ')

    if file_name == '':
        file = sys.stdout
        break
    else:
        try:
            file = open(file_name, 'w')
            break
        except Exception:
            pass
            
complicated_function(file)

if file != sys.stdout:
    file.close()

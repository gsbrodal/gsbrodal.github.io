class SolutionFound(Exception):
    pass

def apx_tree_search(x, tree):
    def search(x, t, indent=0):
        print(indent * '   ' + f'search({x}, {t})')
        if isinstance(t, tuple):
            for child in t:
                search(x, child, indent=indent + 1)
        elif abs(x - t) < 1:  # approximate match
            raise SolutionFound(t)

    try:
        search(x, tree)
    except SolutionFound as e:
        result, = e.args  # e.args is a tuple
        print("search for", x, "found", result)
    else:
        print("search for", x, "unsuccessful")

tree = ((3.2, 2.1), 5.6, (7.8, (9.3, 6.5)))
apx_tree_search(4.3, tree)
print()
apx_tree_search(5.9, tree)

f = open('reading-file3.py')
line = f.readline()
while line != "":
    print('> ', line, end='')
    line = f.readline()
f.close()

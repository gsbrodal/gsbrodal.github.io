f = open('reading-file3.py')
line = f.readline()
while line != "":
    print("> ", line[:-1])
    line = f.readline()
f.close()

x = 7

if x == 1:
    print('x is one')
elif x == 2:
    print('x is two')
elif x == 3 or x == 4 or x == 5:
    print('x is three, four or five')
else:
    print(x, 'is not in the range 1-5')

    
match x:  # match expression:
    case 1:
        print('x is one')
    case 2:
        print('x is two')
    case 3 | 4 | 5:  # match any of the cases
        print('x is three, four or five')
    case value:  # else, value = variable name
        print(value, 'is not in the range 1-5')


def f(x):
    match x:
        case 42:
            return 'the integer 42'
        case 1 | 2 | 3 | 4 | 5:
            return 'integer in range(1, 6)'
        case (1, 2):
            return 'sequence containing the elements 1 and 2'
        case [x, 2]:
            return 'sequence of length 2, last=2, first=' + str(x)
        case (x, (y, z)):  # Nested structure
            return f'a triplet ({x}, ({y}, {z}))'
        case (x, y) if x + y == 7:  # guard
            return 'sequence with two values with sum 7'
        case [0, 1, *x]:  # x is list of remaining elements in sequence
            return 'sequence starting with 0 and 1, and tail ' + str(x)
        case {'a': 7, 'b': x}:
            return 'dictionary "a" -> 7, "b" -> ' + str(x)
        case (('a' | 'b'), ('c' | 'd')):
            return 'tuple length 2, first "a" or "b", last "c" or "d"'
        case (('x' | 'y') as fst, ('x' | 'y') as snd):
            return '(fst, snd), where fst=' + str(fst) + ', snd=' + str(snd)
        case float(value):  # test on builtin type
            return 'a float ' + str(value)
        case Color.RED:  # class or object attribute
            return 'the color red'
        case Point(x=7, y=value):  # Point object with attributes x and y
            return 'a Point object with x=7, and y=' + str(value)
        case Point(x, y):  # requires __match_args__ in class Point
            return 'a point Point(' + str(x) + ', ' + str(y) + ')'
        case e:  # warning - using the wildcard _ does not bind to a variable
            return 'cannot match ' + repr(e)


class Color:
    RED   = 'ff0000'
    GREEN = '00ff00'
    BLUE  = '0000ff'


class Point:
    __match_args__ = ('x', 'y')
    def __init__(self, x, y):
        self.x = x
        self.y = y
    def __repr__(self):
        return f'Point({self.x}, {self.y})'

for x in [42, 1, [1, 2], [7, 2], range(3, 5), (3, (5, 7)),
          (0, 1, 2, 3, 4, 5), {'a':7, 'b':42, 'c':1},
          ('b', 'c'), ('y', 'x'), 3.14, 'ff0000',
          Point(7, 42), Point(3, 5),  'abc', ]:
    print('f(' + repr(x) + ') = ' + repr(f(x)))

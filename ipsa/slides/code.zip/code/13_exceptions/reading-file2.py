f = open('reading-file2.py')
lines = f.readlines()
# lines = list of strings
f.close()
for line in lines:
    print('> ', line, end='')


class SolutionFound(Exception):
    pass


def recursive_tree_search(x, t):
    """Search tuple t recursive for element t. 
    Raises a SolutionFound exception if successful"""
    if isinstance(t, tuple):
        for child in t:
            recursive_tree_search(x, child)
    elif x == t:
        raise SolutionFound

def tree_search(x, t):
    try:
        recursive_tree_search(x, t)
    except SolutionFound:
        print("found", x)
    else:
        print("search for", x, "unsuccessful")


tree_search(8,((3,2),5,(7,(4,6))))
tree_search(3,((3,2),5,(7,(4,6))))

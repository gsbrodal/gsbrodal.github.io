class SolutionFound(Exception):
    pass


def recursive_tree_search(x, tree):
    '''Search tuple tree recursively for element x. 

    Raises a SolutionFound exception if successful'''

    if isinstance(tree, tuple):
        for child in tree:
            recursive_tree_search(x, child)
    elif x == tree:
        raise SolutionFound  # founx in tree

def tree_search(x, tree):
    try:
        recursive_tree_search(x, tree)
    except SolutionFound:
        print('found', x)
    else:
        print('search for', x, 'unsuccessful')


tree_search(8,((3,2),5,(7,(4,6))))
tree_search(7,((3,2),5,(7,(4,6))))

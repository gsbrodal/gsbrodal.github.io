import sys

sys.stdout.write("Input an integer: ")
x = int(sys.stdin.readline())
sys.stdout.write("%s square is %s" % (x, x**2))

from time import time
import sys

n = 10_000_000
data = 'numbers.txt'

def test_input():
    for i in range(n):
        line = input()

def test_stdin_readline():
    for i in range(n):
        line = sys.stdin.readline()

def test_readline():
    readline = sys.stdin.readline
    for i in range(n):
        line = readline()

def test_stdin_readlines():
    lines = sys.stdin.readlines()

def test_stdin_read():
    text = sys.stdin.read()

def test_stdin_read_split():
    text = sys.stdin.read().split('\n')

def test_for():
    for line in sys.stdin:
        pass

def create_test_input():
    with open(data, 'x') as file:
        for i in range(n):
            print(i, file=file)

create_test_input()
for _ in range(5):
    for name, value in list(vars().items()):
        if name.startswith('test_'):
            with open(data) as file:
                original_stdin = sys.stdin
                sys.stdin = file
                start = time()
                value()
                end = time()
                sys.stdin = original_stdin
            print(f'{name} {end - start:.2} sec')
import os
os.remove(data)

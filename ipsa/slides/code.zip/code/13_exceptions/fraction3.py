while True:
    try:
        numerator = int(input("Numerator = "))
        denominator = int(input("Denominator = "))
    except ValueError:
        print("input not a valid integer")
        continue
    try:
        result = numerator / denominator
    except ZeroDivisionError:
        print("cannot divide by zero")
        continue
    print("%s / %s = %s" % (numerator, denominator, result))

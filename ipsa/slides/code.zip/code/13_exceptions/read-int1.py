while True:
    try:
        x = int(input("An integer: "))
        break
    except ValueError:
        continue

print("The value is:", x)

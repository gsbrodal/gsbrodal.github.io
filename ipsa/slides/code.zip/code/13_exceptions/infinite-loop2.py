print("starting infinite loop")
try:
    x = 0
    while True:
        x = x + 1
except KeyboardInterrupt:
    pass
print("done with infinite loop (x = %s)" % x)

input("type enter to exit")

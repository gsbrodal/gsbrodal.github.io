L = [3, 5, 7]
try:
    L[4]
except Exception:
    print("Fall back exception handler")
except IndexError:
    print("IndexError")
    

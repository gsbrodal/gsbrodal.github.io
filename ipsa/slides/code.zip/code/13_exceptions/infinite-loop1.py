print('starting infinite loop')
x = 0
while True:
    x = x + 1
print(f'done ({x = })')

input('type enter to exit')

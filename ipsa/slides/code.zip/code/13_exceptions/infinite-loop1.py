print("starting infinite loop")
x = 0
while True:
    x = x + 1
print("done with infinite loop (x = %s)" % x)

input("type enter to exit")

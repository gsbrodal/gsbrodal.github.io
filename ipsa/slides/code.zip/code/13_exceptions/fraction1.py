while True:
    numerator = int(input("Numerator = "))
    denominator = int(input("Denominator = "))
    result = numerator / denominator
    print("%s / %s = %s" % (numerator, denominator, result))
        

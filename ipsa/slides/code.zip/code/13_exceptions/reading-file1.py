f = open('reading-file1.py')
for line in f:
    print("> ", line, end='') 
f.close()

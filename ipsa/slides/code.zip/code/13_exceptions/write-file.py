f = open('output-file.txt', 'w')

f.write('Text 1\n')
f.writelines(['Text 2\n', 'Text 3 '])

f.close()

g = open('output-file.txt', 'a')

print('Text 4', file=g)
g.writelines(['Text 5 ', 'Text 6'])

g.close()

with open('reading-file4.py') as f:
    for line in f:
        print("> ", line[:-1]) 

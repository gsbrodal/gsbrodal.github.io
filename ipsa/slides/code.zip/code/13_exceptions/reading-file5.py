with open('reading-file5.py') as f:
    for line in f:
        print('> ', line, end='')

try:
    f = open('reading-file4.py')
except FileNotFoundError:
    print("Could not open file")
else:
    try:
        for line in f:
            print('> ', line, end='')
    finally:
        f.close()

try:
    f = open('reading-file4.py')
except FileNotFoundError:
    print("Could not open file")
else:
    try:
        for line in f:
            print("> ", line[:-1]) 
    finally:
        f.close()

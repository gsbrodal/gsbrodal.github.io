answers = {}  # answers[(n, k)] = binomial(n, k)

def binomial(n, k):
#    print("n=%s k=%s" % (n, k))
    if (n, k) not in answers:
        if k == 0 or k == n:
            answer = 1
        else: 
            answer = binomial(n - 1, k) + binomial(n - 1, k - 1)

        answers[(n, k)] = answer

    return answers[(n, k)]

# print(binomial(25, 13))

# for x in sorted(answers): print(x, answers[x])

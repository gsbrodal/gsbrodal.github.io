def knapsack(volume, value, capacity):
    solutions = [(0, [])] * (capacity + 1)
    for obj in range(len(volume)):
        for c in reversed(range(volume[obj], capacity + 1)):
            prev_v, prev_solution = solutions[c - volume[obj]]
            v = value[obj] + prev_v
            if solutions[c][0] < v:
                solutions[c] = v, prev_solution + [obj]
                
    return solutions[capacity]

volumes = [3, 3, 2, 5]
values = [6, 7, 8, 9]

print(knapsack(volumes, values, 5))

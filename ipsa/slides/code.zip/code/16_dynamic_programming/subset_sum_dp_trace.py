def trace(f):
    indent = 0
    
    def wrapper(*args, **kw):
        nonlocal indent

        spaces = '|  ' * indent 
        arg_str = ', '.join([str(v) for v in args] +
                            [f'{k}=' + repr(v) for k, v in kw.items()])
        print(spaces + f'{f.__name__}({arg_str})')
        indent += 1
        result = f(*args, **kw)
        indent -= 1
        print(spaces + f'> {result}')
        return result

    return wrapper

def memoize(f):
    answers = {}  # answers[args] = f(*args) 
    
    def wrapper(*args):
        if args not in answers:
            answers[args] = f(*args)
        return answers[args]

    wrapper.__name__ = f.__name__ + '_memoize'

    return wrapper

def subset_sum(x, L):
    @trace
    @memoize
    def solve(value, k):
        if k == 0:
            return value == 0
        return solve(value, k-1) or solve(value - L[k-1], k-1)

    return solve(x, len(L))

def subset_sum_solution(x, L):
    @trace
    @memoize
    def solve(value, k):
        if k == 0:
            if value == 0:
                return []
            else:
                return None
        solution = solve(value, k-1)
        if solution != None:
            return solution
        solution = solve(value - L[k-1], k-1)
        if solution != None:
            return solution + [L[k-1]]
        return None

    return solve(x, len(L))

#print(subset_sum(1438765, [(2**i % 27) for i in range(40)]))
#print(subset_sum_solution(1048575, [2**i for i in range(20)]))
#print(subset_sum(500, [2, 3, 8, 11, -1,125,254,26,23,899,23,425,2656]))
#print(subset_sum(11, [2, 3, 8, 11, -1]))
print(subset_sum(6, [2, 3, 8, 11, -1]))
#print(subset_sum_solution(11, [2, 3, 8, 11, -1]))
#print(subset_sum_solution(6, [2, 3, 8, 11, -1]))

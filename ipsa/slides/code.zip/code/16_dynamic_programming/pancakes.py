"""Google Code Jam - Qualification Round 2017
Problem A: Oversized Pancake Flipper""" 


T = int(input())
for t in range(1,T+1):
    P, K = input().split()
    K = int(K)
    n = len(P)
    pancakes = [1 if p == '+' else 0 for p in P]
    flips = 0
    for i in range(n - K + 1):
        if not pancakes[i]:
            flips += 1
            for j in range(K):
                pancakes[i + j] = 1 - pancakes[i + j]
    if all(pancakes[n - K + 1:]):
        result = flips
    else:
        result = "IMPOSSIBLE"

    print("Case #%s: %s" % (t, result))

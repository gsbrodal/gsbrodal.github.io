from functools import cache

@cache
def binomial(n, k):
    if k==0 or k==n:
        return 1
    else: 
        return binomial(n-1, k) + binomial(n-1, k-1)


print(binomial(7, 5))

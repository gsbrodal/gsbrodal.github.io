def partial(fn, *args):
    def new_f(*a):
        print(f'new_f: fn={fn.__name__}, args={args}, a={a})')
        answer = fn(*args, *a)
        print(f'answer={answer}')
        return answer

    return new_f

def f(x, y, z):
    print(f'f({x},{y},{z})')
    return x + 2 * y + 3 * z

g = partial(f, 7)
h = partial(f, 2, 1 )
k = partial(g, 1, 2)

print(f'{g(2, 1)=}\n')  # 7 + 2 * 2 + 3 * 1 = 14
print(f'{h(3)=}\n')     # 2 + 2 * 1 + 3 * 3 = 13
print(f'{k()=}\n')      # 7 + 2 * 1 + 3 * 2 = 15


def what_says(name):
    def say(message):
        print(name, "says:", message)

    return say

alice = what_says("Alice")
peter = what_says("Peter")

alice("Where is Peter?")
peter("I am here")

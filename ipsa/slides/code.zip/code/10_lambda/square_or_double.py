def square(x):
	return x * x

def double(x):
	return 2 * x

while True:
    answer = input("square or double ? ")
    if answer == "square":
        f = square
        break
    if answer == "double":
        f = double
        break

answer = input("numbers: ")

L_in = [int(x) for x in answer.split()]
L_out = [f(x) for x in L_in]

print(L_out)

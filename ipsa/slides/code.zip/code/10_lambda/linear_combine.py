def combine(f, g):
    def evaluate(*args, **kwargs):
        print(args,kwargs)
        return f(g(*args, **kwargs))

    print(locals())
    return evaluate

def linear_function(a, b):
    return lambda x: a * x + b

f = linear_function(2, 3)
g = linear_function(4, 5)

h = combine(f, g)

print(h(1))

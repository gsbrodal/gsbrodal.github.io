def triplet_distance(tree1, tree2):
    def compute(tree):
        if not isinstance(tree, tuple): 
            return [tree], []
        (ll, lt), (rl, rt) = [compute(c) for c in tree]
        t = [(x,(y,z)) for a,b in [(ll,rl), (rl,ll)] for y in b for z in b if y < z for x in a]
        return ll + rl, lt + rt + t

    (L1, T1), (L2, T2) = compute(tree1), compute(tree2)
    return len(set(T1) - set(T2))

def partial(f, *args, **kwargs):
    return lambda *a, **kw : f(*args, *a, **kwargs, **kw)

def f(x, y, z):
    return x + 2 * y + 3 * z

g = partial(f, 7)
h = partial(f, 2, 1 )
k = partial(g, 1, 2)

print(g(2, 1))  # 7 + 2 * 2 + 3 * 1 = 14
print(h(3))     # 2 + 2 * 1 + 3 * 3 = 13
print(k())      # 7 + 2 * 1 + 3 * 2 = 15


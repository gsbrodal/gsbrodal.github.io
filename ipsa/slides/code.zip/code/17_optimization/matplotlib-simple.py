import matplotlib.pyplot as plt

plt.figure()

plt.plot([1, 2, 3], [5, 2, 7], 'bo:')

plt.show()

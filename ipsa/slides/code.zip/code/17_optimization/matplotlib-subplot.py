import matplotlib.pyplot as plt
from math import pi, sin

x_min, x_max, n = 0, 2 * pi, 100

x = [x_min + (x_max - x_min) * i / n for i in range(n + 1)]
y = [sin(v) for v in x]

ax1 = plt.subplot(2, 3, 1)  # 2 rows, 3 columns
ax1.label_outer()
plt.xlim(-pi, 3 * pi)
plt.plot(x, y, 'r-')
plt.title('Plot A')

ax2 = plt.subplot(2, 3, 2)
plt.xlim(-2 * pi, 4 * pi)
ax2.label_outer()
plt.plot(x, y, 'g,')
plt.title('Plot B')
    
ax3 = plt.subplot(2, 3, 3, frameon=False)
ax3.set_xticks([])
ax3.set_yticks([])
plt.plot(x, y, 'b--')
plt.title('No frame')

ax4 = plt.subplot(2, 3, 4, sharex=ax1)
plt.ylim(-2, 2)
plt.plot(x, y, 'm:')
plt.title('Plot C')

ax5 = plt.subplot(2, 3, 5, sharex=ax2, sharey=ax4)
ax5.set_xticks(range(-5, 15, 5))
ax5.label_outer()
plt.plot(x, y, 'k-.')
plt.title('Plot D')

ax6 = plt.subplot(2, 3, 6, projection='polar')
ax6.set_yticks([-1, 0, 1])
ax6.tick_params(axis='y', labelcolor='red')
plt.plot(x, y, 'r')
plt.title('Polar projection\n')

plt.suptitle('2 x 3 subplots', fontsize=16)

plt.show()

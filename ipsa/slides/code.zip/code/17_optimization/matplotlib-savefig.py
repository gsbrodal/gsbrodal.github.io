from math import pi, sin, cos
import matplotlib.pyplot as plt

n = 1000
points = [(cos(2 * pi * i / n), 
           sin(4 * pi * i / n)) for i in range(n)]
x, y = zip(*points)
plt.plot(x, y, 'k-', linewidth=5)

plt.savefig('butterfly.png')  # save plot as PNG

plt.savefig('butterfly-grey.png',
    dpi=100,                  # dots per inch
    bbox_inches='tight',      # crop to bounding box
    pad_inches=0.1,           # space around figure
    facecolor='lightgrey',    # background color
    format='png')             # optional if file extension

plt.savefig('butterfly.pdf')  # save plot as PDF

plt.show()                    # interactive viewer

% MATLAB program to find the minimum enclosing circle of a point set
% fminsearch uses the Nelder-Mead algorithm
% https://se.mathworks.com/help/optim/ug/fminsearch-algorithm.html

global x y

x = [1.0, 3.0, 2.5, 4.0, 5.0, 6.0, 5.0];
y = [3.0, 1.0, 3.0, 6.0, 7.0, 7.0, 2.0];

c = fminsearch(@(x) max_distance(x), [0,0]);

plot(x, y, "o");
viscircles(c, max_distance(c));

function dist = max_distance(p)
    global x y
    
    dist = 0.0;
    for i=1:length(x)
        dist = max(dist, pdist([p; x(i), y(i)], 'euclidean' ));
    end
end

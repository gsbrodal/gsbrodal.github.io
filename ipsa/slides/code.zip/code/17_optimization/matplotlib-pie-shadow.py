import matplotlib.pyplot as plt
import matplotlib.patheffects as path_effects

plt.title('My Pie')
patches, texts, autotexts = plt.pie([2, 3, 2, 7],        # relative wedge sizes
        labels=['A','B','C','D'], 
        colors=['r', 'b', 'y', 'm'],
        startangle=5,        # angle above horizontal
        counterclock=True,   # default True
        rotatelabels=False,  # default False
#        shadow=True,         # default False
        textprops=dict(
            color='black',
            style='italic'
        ),
        wedgeprops=dict(
            width=0.8,
            linewidth=1,
            edgecolor='black'
            ),
        explode=(0, 0.1, 0.3, 0),  # radius fraction
        autopct='%1.1f %%',  # percent formatting
        )

for patch in patches:
    patch.set_path_effects([path_effects.SimpleLineShadow(),
        path_effects.Normal()])
    
plt.show()  

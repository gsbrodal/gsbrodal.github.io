import matplotlib.pyplot as plt
from matplotlib.patches import Shadow

patches, texts, autotexts = plt.pie(
    [1, 2, 2],
    explode=(0.1, 0.1, 0.1),
    autopct='%1.0f %%'
)

for pie in patches:
    pie_shadow = Shadow(
        pie, 0.03, -0.03,  # patch, x-offset, y-offset
        alpha=0.3,         # shadow transparency
        edgecolor=None,    # shadow edge color
        facecolor=pie._facecolor,  # shadow fill color
    )
    plt.gca().add_patch(pie_shadow)

plt.show()  

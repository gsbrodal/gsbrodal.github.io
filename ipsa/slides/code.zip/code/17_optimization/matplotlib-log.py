import matplotlib.pyplot as plt

x = [i / 10 for i in range(1, 101)]

y1 = [i ** 2 for i in x]
y2 = [i ** 3 for i in x]
y3 = [3 ** i for i in x]

for i in range(1, 7):
    ax = plt.subplot(3, 2, i)
    plt.plot(x, y3, label='$3^x$')
    plt.plot(x, y2, label='$x^3$')
    plt.plot(x, y1, label='$x^2$')
    if i == 1:
        plt.ylim(0, 2000)       
        plt.xscale('linear')
        plt.yscale('linear')
        plt.legend()
        plt.title('linear')
    if i == 2:
        plt.yscale('log')
        plt.title('ax.yscale')
    if i == 3:
        ax.set_xscale('log')
        ax.set_yscale('log')
        plt.title('ax.set_xscale & ax.set_yscale')
    if i == 4:
        plt.loglog()
        plt.title('plt.loglog')
    if i == 5:
        plt.ylim(0, 2000)
        plt.semilogx()
        plt.title('plt.semilogx')
    if i == 6:
        plt.semilogy()
        plt.title('semilogy')

plt.show()

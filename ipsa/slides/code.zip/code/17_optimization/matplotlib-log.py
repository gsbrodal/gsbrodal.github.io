import matplotlib.pyplot as plt

x = [i / 10 for i in range(1, 101)]

y1 = [i ** 2 for i in x]
y2 = [i ** 3 for i in x]
y3 = [3 ** i for i in x]

for i in range(1, 7):
    ax = plt.subplot(3, 2, i)
    plt.plot(x, y3, label='$3^x$')
    plt.plot(x, y2, label='$x^3$')
    plt.plot(x, y1, label='$x^2$')
    match i:
      case 1:
        plt.ylim(0, 2000)       
        plt.xscale('linear')
        plt.yscale('linear')
        plt.legend()
        plt.title('linear')
      case 2:
        plt.yscale('log')
        plt.title('plt.yscale')
      case 3:
        ax.set_xscale('log')
        ax.set_yscale('log')
        plt.title('ax.set_xscale & ax.set_yscale')
      case 4:
        plt.loglog()
        plt.title('plt.loglog')
      case 5:
        plt.ylim(0, 2000)
        plt.semilogx()
        plt.title('plt.semilogx')
      case 6:
        plt.semilogy()
        plt.title('plt.semilogy')

plt.show()

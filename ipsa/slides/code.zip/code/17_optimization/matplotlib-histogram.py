import matplotlib.pyplot as plt
from random import random

values1 = [random()**2 for _ in range(1000)]
values2 = [random()**3 for _ in range(100)]

bins = [0.0, 0.25, 0.5, 0.75, 1.0]

for i, ht in enumerate(['bar', 'barstacked', 'step', 'stepfilled'], start=1):
    plt.subplot(2, 2, i)  # start new plot
    plt.hist([values1, values2], bins, histtype=ht, rwidth=0.7, label=['$x^2$', '$x^3$'], density=True)  
    plt.title(ht)
    plt.xticks(bins)
    plt.legend()

plt.suptitle('Histogram')
plt.show()

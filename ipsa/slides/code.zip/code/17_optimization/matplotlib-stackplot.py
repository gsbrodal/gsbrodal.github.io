import matplotlib.pyplot as plt

x = [1, 2, 3, 4]
y1 = [1, 2, 3, 4]
y2 = [2, 3, 1, 4]
y3 = [2, 4, 1, 3]

plt.style.use('dark_background')
for i, base in enumerate(['zero', 'sym', 'wiggle',
                          'weighted_wiggle'], start=1):
    
    plt.subplot(4, 1, i)
    plt.stackplot(x, y1, y2, y3,
                  colors=['r', 'g', 'b'],
                  labels=["Red", "Green", "Blue"],
                  baseline=base)
    plt.grid(axis='both',
             linewidth=0.5, linestyle='-', alpha=0.5)
    plt.legend(title=base, loc='upper left')
    plt.xticks(x)

plt.suptitle('Stackplot')

plt.show()

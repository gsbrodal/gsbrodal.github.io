from math import pi, cos, sin
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

n, tail_length = 200, 75
points = []

def point(i):
    t = 2 * pi * i / n 
    return (cos(3 * t), sin(2 * t))

fig = plt.figure()
ax = plt.gca()
ax.set_facecolor('black')
plt.xlim(-1.1, 1.1)
plt.ylim(-1.1, 1.1)
plt.xticks([])
plt.yticks([])
plt.title('Moving point')

x, y = point(0)
plt.plot(x, y, 'w.')  # start point
plt.text(x - 0.025, y, 'start', color='w', ha='right', va='center')
tail, = plt.plot([], [], 'w-', alpha=0.5)  # tail
head, = plt.plot([], [], 'ro')  # current point

def move(frame):
    points.append(point(frame))
    del points[:-tail_length]

    tail.set_data(*zip(*points))
    head.set_data(*points[-1:])

animation = FuncAnimation(fig,
    func=move,
    frames=range(n),
    interval=25,
    repeat_delay=0,
    repeat=True)

plt.show()

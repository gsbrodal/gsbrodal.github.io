import matplotlib.pyplot as plt

x = [1, 2, 3]
y = [7, 5, 10]

plt.bar(x, y,
        color='lightblue',  # bar background color
        edgecolor='gray',   # bar boundary color
        linewidth=1,        # bar boundary width
        width=0.7,          # width of bar
        yerr=0.25,          # Error bar: y length
        xerr=0.5,           #   x length
        capsize=3,          #   capsize in points
        ecolor='darkblue',  #   error bar color
        tick_label=x,       # ticks on x-axis
        log=True)           # y-axis log scale

plt.bar(x, [v**2 for v in x],
        color='pink',
        linewidth=1,
        edgecolor='gray')

plt.show()

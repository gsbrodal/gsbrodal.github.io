import matplotlib.pyplot as plt
from math import pi, sin, cos
import datetime

def plot_clock(hour, minute, second):
    plt.axis('off')                # hide x and y axes
    plt.gca().set_aspect('equal')  # don’t squeeze circle
    for i in range(60):            # show second marks
        angle = 2 * pi * i / 60
        x, y = cos(angle), sin(angle)
        start = 0.98 if i % 5 else .94  # every 5'th mark should be longer
        plt.plot([start * x, x], [start * y, y], c='black')  # mark
    for angle, length, style in [
        (second / 60, .90, dict(c='red',   lw=2, solid_capstyle='round')),
        (minute / 60, .85, dict(c='black', lw=3, solid_capstyle='round')),
        (hour   / 12, .50, dict(c='black', lw=8, solid_capstyle='round'))
    ]:
        angle = 2 * pi * (0.25 - angle)
        x, y = length * cos(angle), length * sin(angle)
        plt.plot([0, x], [0, y], **style)  # clock arm
    plt.plot(0, 0, 'o', ms=10, c='black')  # center dot

while True:
    now = datetime.datetime.now()
    plot_clock(now.hour, now.minute, now.second)
    plt.pause(1)  # show figure and pause
    plt.clf()     # clear figure

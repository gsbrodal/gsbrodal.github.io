import csv
import sys

data = [[1, 1.0, '1.0'], ['abc', '"', '\t"', ',']]

quoting_options = [(csv.QUOTE_MINIMAL, "QUOTE_MINIMAL"),
                   (csv.QUOTE_ALL, "QUOTE_ALL"),
                   (csv.QUOTE_NONNUMERIC, "QUOTE_NONNUMERIC"),
                   (csv.QUOTE_NONE, "QUOTE_NONE")]

for quoting, name in quoting_options:
    print(name)
    csv_out = csv.writer(sys.stdout, quoting=quoting, escapechar='\\')
    for row in data:
        csv_out.writerow(row)        

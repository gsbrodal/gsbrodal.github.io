import xml.etree.ElementTree as ET

FILE = 'cities.xml'

tree = ET.parse(FILE)
root = tree.getroot()

for country in root:
    for city in country:
        print(city.attrib['name'],
              'in',
              country.attrib['name'],
              'has a population of',
              city.attrib['pop'])

print(root.tag, root[0][1].attrib)

print([city.attrib['name'] for city in root.iter('city')])

import re

text = 'this is a string - a list of characters'

def search_

pattern = 'h..'  # match h and two arbitrary following symbols
pattern = 'i\w*'  # match 'i' and all following lower case leters
pattern = 'i[^i]*i'  # match everything between two 'i's except 'i'

m = re.search(pattern, text)

if m == None:
    print("No match")
else:
    print(m.group())

for m in re.finditer(pattern, text):
    print("text[%s, %s] = %s" % (m.start(), m.end(), m.group()))


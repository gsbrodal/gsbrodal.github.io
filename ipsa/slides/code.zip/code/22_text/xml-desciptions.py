import xml.etree.ElementTree as ET

FILE = 'city-descriptions.xml'

tree = ET.parse(FILE)
root = tree.getroot()

for city in root.iter('city'):
    print(city.get('name'), "-", city.text)

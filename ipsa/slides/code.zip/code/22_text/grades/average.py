import csv

with open('grades.csv') as file:
    data = csv.reader(file, delimiter=';')
    header = next(data)
#    print(header)
    count = {}
    total = {}
    for row in data:
        course = row[header.index('Course')]
        grade = int(row[header.index('Grade')])
        count[course] = count.get(course, 0) + 1
        total[course] = total.get(course, 0) + grade
print('Average grades:')
width = max(map(len, count))
for course in count:
    print(f'{course:>{width}s} : {total[course] / count[course]:.2f}')

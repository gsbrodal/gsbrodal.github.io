import time
import itertools
import matplotlib.pyplot as plt

def evaluate():
    data = []
    for i in itertools.count():
        n = 2 ** i
        A = n * 'a'
        pattern = A + 'b' + A
        text = A + pattern

        start = time.time()
        position = text.find(pattern)
        end = time.time()
        query_time = end - start

        print('n =', n, 'time =', query_time)
        if query_time < 0.02:
            continue  # skip, likely noise
        data.append((n, query_time))
        if query_time > 30 or n >= 2_147_483_648:
            break
    return data 

# data = evaluate()
# print(data)

# Python 3.9.11
data_39 = [(8192, 0.03114175796508789), (16384, 0.10937786102294922), (32768, 0.4219634532928467), (65536, 1.476517915725708), (131072, 5.906257390975952), (262144, 23.46863102912903), (524288, 92.45297813415527)]
# Python 3.10.8
data_310 = [(207152, 0.03133702278137207), (4194304, 0.07811236381530762), (8388608, 0.1250016689300537), (16777216, 0.2343587875366211), (33554432, 0.4745769500732422), (67108864, 0.8748316764831543), (134217728, 1.7251598834991455), (268435456, 3.4169936180114746), (536870912, 8.46215271949768), (1073741824, 14.292867660522461), (2147483648, 28.836583375930786)]
# Python 3.11.0
data_311 = [(4194304, 0.06251001358032227), (8388608, 0.1250600814819336), (16777216, 0.20304346084594727), (33554432, 0.380260705947876), (67108864, 0.7895593643188477), (134217728, 1.5625066757202148), (268435456, 3.105327606201172), (536870912, 6.286048412322998), (1073741824, 14.334026575088501), (2147483648, 25.718786239624023)]

linear = [(n, 1.20e-8  * n) for n, t in data_311]
quadratic = [(n, 3.36e-10 * n ** 2) for n, t in data_39]

plt.plot(*zip(*data_39), '.-', color='C0', label='Python 3.9')
plt.plot(*zip(*data_310), '.-', color='C2', label='Python 3.10')
plt.plot(*zip(*data_311), '.-', color='C1', label='Python 3.11')

plt.plot(*zip(*quadratic), ':', color='C0', label='$y = 3.36\cdot 10^{-10} \cdot n^2$')
plt.plot(*zip(*linear), ':', color='C1', label='$y = 1.20\cdot 10^{-8} \cdot n$')

plt.title("(2 * n * 'A' + 'B' + n * 'A').find(n * 'A' + 'B' + n * 'A')")
plt.loglog()
plt.xlabel('$n$')
plt.ylabel('running time (seconds)')
plt.legend(frameon=False)
plt.tight_layout()
plt.show()

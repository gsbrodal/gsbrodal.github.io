S = 'A'

rules = {'A': 'AB', 'B': 'A'}

for i in range(8):
    S = "".join(rules.get(c, c) for c in S)
    print(S)
    

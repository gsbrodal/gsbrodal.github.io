import json

FILE = 'json-data.json'

data = ((None, True), (42.7, (42,)), [3,2,4], (5,6,7),
        {'b':'banana', 'a':'apple', 'c': 'coconut'})

with open(FILE, 'w') as outfile:
    json.dump(data, outfile, indent=4, sort_keys=True)
    
with open(FILE) as infile:
    indata = json.load(infile)

print(indata)

text = 'this is a string - a list of characters'
pattern = 'is'

idx = text.find(pattern)
while idx >= 0:
    print(idx, end=" ")
    idx = text.find(pattern, idx + 1)

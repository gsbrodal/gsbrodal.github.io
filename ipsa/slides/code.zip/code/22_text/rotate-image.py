from PIL import Image

img = Image.open("Python-Logo.png")

img_out = img.rotate(45, expand=True)

img_out.save("Python-rotated.png")

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

wb = Workbook() # create workbook
ws = wb.active  # active worksheet

ws['A1'] = 42
ws['B3'] = 7
ws['C2'] = ws['A1'].value + ws['B3'].value
ws['D3'] = '=A1+B3+C2'

ws.title = 'My test sheet'

ws['A1'].fill = PatternFill('solid', fgColor='ffff00')
ws['C2'].font = Font(bold=True)

wb.save('openpyxl-example.xlsx')

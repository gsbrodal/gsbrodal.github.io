import csv

FILE = 'csv-data.csv'

data = [[1, 2, 3],
        ['a', '"b"'],
        [1.0, ['x',"y"], 'd']]

with open(FILE, 'w', newline="") as outfile:
    csv_out = csv.writer(outfile)
    for row in data:
        csv_out.writerow(row)

with open(FILE, 'r', newline="") as infile:
    for row in csv.reader(infile):
        print(row)
        

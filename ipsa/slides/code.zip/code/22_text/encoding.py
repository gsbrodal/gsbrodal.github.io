for filename in ["river-utf8.txt", "river-windows1252.txt"]:
    print(filename)
    f = open(filename, "rb")
    line = f.readline()
    print(line)
    print(list(line))
    f = open(filename, "r", encoding="utf-8")
    line = f.readline()
    print(line)

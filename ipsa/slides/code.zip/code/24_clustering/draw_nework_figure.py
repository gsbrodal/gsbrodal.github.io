import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(-5, 5, 101)

plt.plot(x, 1 / (1 + np.e ** -x), lw=3, label=r'Sigmoid$= \frac{1}{1 + e^{-x}}$')
plt.plot(x, np.tanh(x), lw=3, label=r'tanh($x$)')
plt.plot(x, np.maximum(0, x), lw=3, label=r'ReLU$= \max(0, x)$')

plt.legend(frameon=False, fontsize='14')

plt.ylim(-1.2, 1.5)
plt.yticks([-1, 1])
plt.xticks([-5, -1, 1, 5])

ax = plt.gca()

ax.spines['bottom'].set_position('zero')
ax.spines['left'].set_position('zero')
ax.spines['top'].set_color('none')
ax.spines['right'].set_color('none')

plt.show()

layers = [
    (100, np.linspace(000, 1100, 20)),
    (200, np.linspace(300, 800, 16)),
    (300, np.linspace(300, 800, 16)),
    (400, np.linspace(400, 700, 10))
]

for (x0, ys0), (x1, ys1) in zip(layers, layers[1:]):
    for y0 in ys0:
        for y1 in ys1:
            plt.plot([x0, x1], [y0, y1], 'k-', alpha=0.5, linewidth=0.5)

for x, ys in layers:
    for y in ys:
        plt.plot(x, y, 'r.')

plt.show()


import matplotlib.pyplot as plt
import numpy as np
from tensorflow import keras

(train_images, train_labels), (test_images, test_labels) = keras.datasets.mnist.load_data()

print(f'{type(test_images) = }')
print(f'{test_images.shape = }')
print(f'{test_labels.shape = }')
print(f'{test_labels[:3] = }')

for i, image in zip(range(3), test_images): 
	plt.subplot(1, 3, i + 1)
	plt.imshow(image)
plt.show()

W, b = map(np.array, eval(open('mnist_linear.weights').read()))  # read W and b from file
print(f'{W.shape=} {W.dtype=} {b.shape=} {b.dtype=}')
print([np.argmax(image.reshape(28 * 28) @ W + b) for image in test_images[:3]])

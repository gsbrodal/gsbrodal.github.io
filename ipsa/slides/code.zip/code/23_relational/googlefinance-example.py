# 1 May 2020 : googlefinance failed to provide data

from googlefinance.client import get_price_data  # pip install googlefinance.client
param = {
    'q': "AAPL", # Stock symbol (ex: "AAPL", "MSFT", "FB")
    'i': "86400", # Interval size in seconds ("86400" = 1 day intervals)
    'x': "NASD", # Stock exchange symbol on which stock is traded (ex: "NASD")
    'p': "1Y" # Period (Ex: "1Y" = 1 year)
}
df = get_price_data(param) # get price data (return pandas dataframe)
import matplotlib.pyplot as plt
plt.plot(df['Close'])
plt.show()

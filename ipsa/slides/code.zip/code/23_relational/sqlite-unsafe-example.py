import sqlite3

connection = sqlite3.connect('users.sqlite')

c = connection.cursor()

c.execute('CREATE TABLE users (name)')

while True:
    user = input("New user: ")
# Insecure way
    c.executescript('INSERT INTO users VALUES ("%s")' % user)
    print('INSERT INTO users VALUES ("%s")' % user)
# Secure way
#    c.execute('INSERT INTO users VALUES (?)', (user,))
    connection.commit()
    print(list(c.execute('SELECT * FROM users')))

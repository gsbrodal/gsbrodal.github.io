""" Very slow computation of PI using the Gregory/Leibniz series """

apx, d = 1.0, 3
while True:
    print("Pi approximation: ", 4.0*apx, " d =", d)
    apx = apx - 1.0 / d + 1.0 / (d + 2.0)
    d += 4.0

s1 = 'abc' "def"  # two string literals
print(s1)
s2 = '"' "'" '"'  # avoid escaping quotes
print(s2)
s3 = 'this is a really, really, really, \
really, really, long string'
print(s3)
s4 = ('this is a really, really, '
      'really, really, really, '
      'long string')
print(s4)
very_very_long_variable_name = (
    'this is a really, really, '  # line 1
    'really, really, really, '    # line 2
    "long string"                 # line 3
)
print(very_very_long_variable_name)

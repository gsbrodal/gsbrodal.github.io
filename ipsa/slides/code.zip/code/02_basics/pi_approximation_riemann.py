apx = 0.0
k = 0.0
while True:
    k = k + 1.0
    apx = apx + 1.0/(k*k)

    if apx > 1.644934057834500:
        print(k, apx)
    

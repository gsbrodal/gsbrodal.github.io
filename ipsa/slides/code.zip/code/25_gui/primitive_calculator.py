accumulator = 0

while True:
    print('Accumulator:', accumulator)
    print('Select:')
    print('  1: clear')
    print('  2: add')
    print('  3: subtract')
    print('  4: multiply')
    print('  5: quit')

    choice = int(input('Choice: '))

    match choice:
        case 1: accumulator = 0
        case 2: accumulator += int(input('add: '))
        case 3: accumulator -= int(input('subtract: '))
        case 4: accumulator *= int(input('multiply by: '))
        case 5: break

import tkinter

root = tkinter.Tk()

def do_quit():
    root.destroy()

root.title("Tkinter Welcome GUI")

label = tkinter.Label(
    root,
    text="Welcome to Tkinter",
    background="yellow",
    anchor=tkinter.SE,  # or .N .E .W .NW. .NE .SE .SW
    font=("Helvetica", "24", "bold italic"),
    padx=10,
    pady=10
)

label.pack(
    side=tkinter.LEFT,  # or .RIGHT .TOP .BOTTOM
    fill=tkinter.BOTH,  # or .X .Y
    expand=True
)

close_button = tkinter.Button(root, text="Close",
                              command=do_quit)
close_button.pack(side=tkinter.LEFT)

tkinter.mainloop() 

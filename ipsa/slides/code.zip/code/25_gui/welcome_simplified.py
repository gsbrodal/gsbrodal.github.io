import tkinter

root = tkinter.Tk()

def do_quit():
    root.destroy()

root.title("Tkinter Welcome GUI")

label = tkinter.Label(root, text="Welcome to Tkinter")

label.pack(side=tkinter.LEFT)

close_button = tkinter.Button(root, text="Close", command=do_quit)
close_button.pack(side=tkinter.RIGHT)

tkinter.mainloop() 

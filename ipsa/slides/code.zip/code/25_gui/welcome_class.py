import tkinter

class Welcome:
    def do_quit(self):
        self.root.destroy()

    def __init__(self, window_title):
        self.root = tkinter.Tk()
        self.root.title(window_title)

        self.label = tkinter.Label(self.root, text='Welcome')
        self.label.pack(side=tkinter.LEFT)

        self.close_button = tkinter.Button(self.root, text='Close', command=self.do_quit)
        self.close_button.pack(side=tkinter.RIGHT)

Welcome('My Window')

tkinter.mainloop() 

import tkinter
from tkinter import messagebox

class Calculator:
    def __init__(self, root):
        self.root = root

        self.display = tkinter.Entry(self.root, font=('Helvetica', 16), justify=tkinter.RIGHT)
        self.display.insert(0, '0')
        self.display.grid(row=0, column=0, columnspan=5)

        self.button(1, 0, '7')
        self.button(1, 1, '8')
        self.button(1, 2, '9')
        self.button(1, 3, '*')
        self.button(1, 4, 'C', command=self.clearText)

        self.button(2, 0, '4')
        self.button(2, 1, '5')
        self.button(2, 2, '6')
        self.button(2, 3, '/')
        self.button(2, 4, '%')

        self.button(3, 0, '1')
        self.button(3, 1, '2')
        self.button(3, 2, '3')
        self.button(3, 3, '-')
        self.button(3, 4, '=', rowspan=2, command=self.calculateExpression)

        self.button(4, 0, '0', columnspan=2)
        self.button(4, 2, '.')
        self.button(4, 3, '+')

    def button(self, row, column, text, command=None, columnspan=1, rowspan=1):
        if command == None:
            command = lambda: self.appendToDisplay(text)
        B = tkinter.Button(self.root, font=('Helvetica', 11),
                           text=text,command=command)
        B.grid(row=row, column=column,
               rowspan=rowspan, columnspan=columnspan,
               sticky='NWSE'  #'NWNESWSE'
               )

    def clearText(self):
        self.replaceText('0')

    def replaceText(self, text):
        self.display.delete(0, tkinter.END)
        self.display.insert(0, text)

    def appendToDisplay(self, text):
        if self.display.get() == '0':
            self.replaceText(text)
        else:
            self.display.insert(tkinter.END, text)

    def calculateExpression(self):
        expression = self.display.get().replace('%', '/ 100')
        
        try:
            result = eval(expression)  # DON'T DO THIS !!!
            self.replaceText(result)
        except:
            tkinter.messagebox.showwarning('Message', 'Invalid expression')

root = tkinter.Tk()
root.title('Calculator')
root.resizable(0, 0)  # disallow resizing and maximizing the window 

Calculator(root)

tkinter.mainloop()

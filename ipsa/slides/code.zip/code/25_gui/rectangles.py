import tkinter

class Rectangles:
    Colors = ['black', 'red', 'blue', 'green', 'yellow']

    def create_menu(self):
        menubar = tkinter.Menu(self.root)
        menubar.add_command(label='Quit! (Ctrl-q)', command=self.do_quit)

        editmenu = tkinter.Menu(menubar, tearoff=0)
        editmenu.add_command(label='Clear', command=self.clear_all)
        editmenu.add_command(label='Delete last (Ctrl-z)', command=self.delete_last_rectangle)

        colormenu = tkinter.Menu(menubar, tearoff=0)  # tearoff=1 allows submenu to become new window
        for color in self.Colors:
            colormenu.add_command(label=color,
                                  foreground=color,
#                                  command=lambda : self.set_color(color)) # fails, always sets to last color...
                                  command=self.get_color_handler(color))

        menubar.add_cascade(label='Edit', menu=editmenu) 
        menubar.add_cascade(label='Color', menu=colormenu) 
        self.root.config(menu=menubar)  # Show menubar

    def create_key_bindings(self):
        self.root.bind('<Control-q>', self.do_quit)
        self.root.bind('<Control-z>', self.delete_last_rectangle)

    def do_quit(self, event=None):
        self.root.destroy()

    def set_color(self, color):
        self.current_color = color

    def get_color_handler(self, color):
        return lambda : self.set_color(color)

    def clear_all(self):
        self.canvas.delete('all')
        
    def delete_last_rectangle(self, event=None):
        if self.corner is None and self.rectangles:
            rectangle = self.rectangles.pop()
            self.canvas.delete(rectangle)

    def create_canvas(self):
        self.canvas = tkinter.Canvas(self.root, width=300, height=200, background='white')
        self.canvas.pack()  # show canvas
        self.canvas.bind('<Button-1>', self.create_rectangle_start)
        self.canvas.bind('<B1-Motion>', self.create_rectangle_mouse_move)
        self.canvas.bind('<ButtonRelease-1>', self.create_rectangle_end)
 
    def create_rectangle_start(self, event):
        radius = 3
        x, y = event.x, event.y
            
        self.top_pos = self.bottom_pos = (x, y)
        self.rectangle = self.canvas.create_rectangle(*self.top_pos, *self.bottom_pos,
                                                      fill=self.current_color,
                                                      width=1, outline='grey', dash=(30, 50))
        self.corner = self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill='white')

    def create_rectangle_mouse_move(self, event):
        #print(event)
        if self.corner:
            x, y = event.x, event.y
            x_, y_ = self.bottom_pos
            self.bottom_pos = (x, y)
            self.canvas.coords(self.rectangle, *self.top_pos, *self.bottom_pos)
            self.canvas.move(self.corner, x - x_, y - y_)
 
    def create_rectangle_end(self, event):
        #if self.corner:
            self.canvas.delete(self.corner)
            self.corner = None
            if self.bottom_pos != self.top_pos:
                self.rectangles.append(self.rectangle)
                self.canvas.itemconfig(self.rectangle, width=0)
            else:  # empty rectangle, skip
                self.canvas.delete(self.rectangle)
            self.rectangle = None
            
    def __init__(self):
        self.current_color = Rectangles.Colors[0]
        self.rectangles = []
        self.corner = None  # Not drawing rectangle

        self.root = tkinter.Tk()
        self.root.title('Draw Rectangles')  # Title of window 
        self.root.resizable(False, False)  # Disallow resizing window

        self.create_menu()
        self.create_key_bindings()
        self.create_canvas()


Rectangles()

tkinter.mainloop()

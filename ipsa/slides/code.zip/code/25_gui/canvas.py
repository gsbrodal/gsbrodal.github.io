import tkinter

root = tkinter.Tk()
canvas = tkinter.Canvas(root, width=100, height=100, background='red')
canvas.pack()
canvas.create_line(0, 0, 100, 100)
canvas.create_oval(20, 20, 80, 80, fill="blue")

close = tkinter.Button(root, text="Close", command=root.destroy)
close.pack()

tkinter.mainloop()

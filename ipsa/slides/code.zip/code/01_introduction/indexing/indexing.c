#include <stdio.h>

int main() {
  int x = 1;
  int A[2] = { 2, 3};  // A[0] = 2, A[1] = 3

  printf("x = %d, A={%d, %d}\n", x, A[0], A[1]);

  A[3] = 42;  // index A[3] out of bound, writes somewhere in memory
  
  printf("x = %d, A={%d, %d}\n", x, A[0], A[1]);

  return 0;
}

/* OUTPUT 

$ gcc indexing.c
$ ./a.exe

x = 1, A={2, 3}
x = 42, A={2, 3}


*/

a = [20, 21, 22]

a[5] = 42

# OUTPUT
# Traceback (most recent call last):
#   File "C:/Users/au121/Desktop/ipsa18/indexing.py", line 3, in <module>
#   a[5] = 42
# IndexError: list assignment index out of range

class IndexingTest{  
    public static void main(String args[]){  
	int a[] = {20, 21, 22};
      
	a[5] = 42;
    }
}  

/* Output - RunTime exception

>javac indexing.java
C:\Users\au121\Desktop\ipsa18>java IndexingTest
Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 5
        at IndexingTest.main(indexing.java:5)

*/

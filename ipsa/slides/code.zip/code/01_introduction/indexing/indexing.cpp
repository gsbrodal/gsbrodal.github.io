#include <iostream>

int main() {
  int x = 1;
  int A[2] = { 2, 3};  // A[0] = 2, A[1] = 3

  std::cout << "x = " << x << ", A={" << A[0] << ", " << A[1] << "}" << std::endl;

  A[3] = 42;  // index A[3] out of bound, writes somewhere in memory
  
  std::cout << "x = " << x << ", A={" << A[0] << ", " << A[1] << "}" << std::endl;

  return 0;
}

/* OUTPUT 

$ g++ indexing.cpp
$ ./a.exe

x = 1, A={2, 3}
x = 42, A={2, 3}

*/

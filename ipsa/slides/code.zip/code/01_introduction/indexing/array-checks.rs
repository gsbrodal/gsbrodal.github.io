fn main() {
    let mut a = [3, 4];
    a[2] = 7;  // Compile error: this operation will panic at runtime
    for i in 2..3 { a[i] = 7 } // Run-time panic: index out of bounds: the len is 3 but the index is 3
    let b = &mut a;
    a[1] = 6;  // Compile error: cannot use `a` because it was mutably borrowed
    (*b)[0] = 5;
    for i in  0..2 { println!("a[{}] = {}", i, a[i]); }
}

#include <iostream>
#include <vector>

int main() {
  std::vector<int> A = { 2, 3};  // A[0] = 2, A[1] = 3
  std::vector<int> B = { 4, 5};  // B[0] = 4, B[1] = 5

  std::cout << "A={" << A[0] << ", " << A[1] << "}, ";
  std::cout << "B={" << B[0] << ", " << B[1] << "}" << std::endl;

  A[9]=42;
  
  std::cout << "A={" << A[0] << ", " << A[1] << "}, ";
  std::cout << "B={" << B[0] << ", " << B[1] << "}" << std::endl;

  return 0;
}

/* OUTPUT 

$ g++ -std=c++11 indexing-vector.cpp
$ ./a.exe
A={2, 3}, B={4, 5}
A={2, 3}, B={4, 42}

*/

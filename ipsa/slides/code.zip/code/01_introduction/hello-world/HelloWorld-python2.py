print "Hello world"

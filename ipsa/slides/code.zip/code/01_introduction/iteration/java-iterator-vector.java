import java.util.Vector;
import java.util.Iterator;

class IteratorTest{
   public static void main(String[] args){
       Vector<Integer> a = new Vector<Integer>();

       a.add(7);
       a.add(42);

       // "C" for-loop & get method
       for (int i=0; i<a.size(); i++)
	   System.out.println(a.get(i));         

       // iterator
       for (Iterator it = a.iterator(); it.hasNext(); )
	   System.out.println(it.next());
       
       // for-each loop
       for (Integer e : a)
	   System.out.println(e);         
   }
}  

/* Output

>javac java-iterator-vector.java
>java IteratorTest
7
42
7
42
7
42

*/

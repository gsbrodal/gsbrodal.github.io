#include <iostream>
#include <vector>

int main() {
  // Vector is part of STL (Standard Template Library)
  std::vector<int> A = {20, 23, 26};

  // "C" indexing - since C++98
  for (int i=0; i<A.size(); i++)   
    std::cout << A[i] << std::endl;

  // iterator - since C++98 
  for (std::vector<int>::iterator it = A.begin(); it != A.end(); ++it)  
    std::cout << *it << std:: endl;

  // "auto" iterator - since C++11
  for (auto it = A.begin(); it != A.end(); ++it)  
    std::cout << *it << std:: endl;

  // Range-based for-loop - since C++11
  for (auto e : A)
    std::cout << e << std:: endl;
}

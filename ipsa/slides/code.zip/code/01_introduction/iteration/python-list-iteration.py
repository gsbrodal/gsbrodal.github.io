A = [20, 23, 26]

for e in A:
    print(e)

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf("Usage: %s <number>\n", argv[0]);
    exit(0);
  }

  int n = atoi(argv[1]);  
  int sum;
  for (int repeat=0; repeat<10; repeat++)
    {
      sum = 0;
      for (int i=1; i<=n; i++)
	sum += i;
    }
  
  printf("Sum 1+2+3+...+%d = %d\n", n, sum);
}

import sys
import time

start = time.time()

if len(sys.argv) != 2:
  print("Usage: " + sys.argv[0] + " <number>\n");
  exit(0)

n = int(sys.argv[1])
sum = 0
for i in range(1, n+1):
    sum += i

print("1+2+3+...+%d = %d" % (n, sum))

end = time.time()
print("Running time:",end-start)

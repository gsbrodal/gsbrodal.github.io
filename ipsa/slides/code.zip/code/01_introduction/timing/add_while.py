import sys
import time

start = time.time()

if len(sys.argv) != 2:
  print("Usage: " + sys.argv[0] + " <number>\n");
  exit(0)

n = int(sys.argv[1])
sum = 0
i = 1
while i <= n:
    sum += i
    i += 1

print("1+2+3+...+%d = %d" % (n, sum))

end = time.time()
print("Running time:",end-start)

from numba import jit, int32, int64

import sys
import time

@jit(int64(int64), nopython=True) # Numba optimization
def code(n):
  x = 0
  for i in range(1, n+1):
      x = i - x   # x = x + i  is optimized away on compile time
  return x

for n in [10**7, 10**8, 10**9]:
  repeat = max(1, 10**10 // n)
  start = time.time()

  for _ in range(repeat):
    sum = code(n)

  print("(-1)^%d * (1-2+3-4+5-...+%d) = %d" % (n, n, sum))
  end = time.time()
  print("Total running time:", end-start, "Average:", (end-start)/repeat)

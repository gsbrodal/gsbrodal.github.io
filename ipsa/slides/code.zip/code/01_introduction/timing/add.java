class Add{  
    public static void main(String args[]){  
	if (args.length != 1) {
	    System.out.println("Usage: java Add <number>\n");
	    System.exit(0);
	}
	
	int n = Integer.parseInt(args[0]);  
	int sum = 0;
	for (int repeat=0; repeat<100; repeat++)
	    {
		sum = 0;
		for (int i=1; i<=n; i++)
		    sum += i;
	    }
	
	System.out.println("Sum 1+2+3+...+" + args[0] + " = " + sum);
    }
}  

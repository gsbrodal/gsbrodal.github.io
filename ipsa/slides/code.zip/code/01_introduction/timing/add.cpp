#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char *argv[]) {
  if (argc != 2) {
    cout << "Usage: " << argv[0] << " <number>" << endl;
    exit(0);
  }

  int n = atoi(argv[1]);  
  int sum = 0;
  for (int repeat=0; repeat<100; repeat++)
    {
      sum = 0;
      for (int i=1; i<=n; i++)
	sum += i;
    }

  cout << "Sum 1+2+3+...+" << n << " = " << sum << endl;
}

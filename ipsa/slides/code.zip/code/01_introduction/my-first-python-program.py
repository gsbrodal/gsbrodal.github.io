x = 3
y = 4
print(x *y)

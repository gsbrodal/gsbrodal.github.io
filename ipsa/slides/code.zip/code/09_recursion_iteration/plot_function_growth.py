import matplotlib.pyplot as plt
import numpy as np

N = 10000
n = np.arange(1, N)

plt.plot(n, n**3, label='$n^3$')
plt.plot(n, n**2, label='$n^2$')
plt.plot(n, n*np.sqrt(n), label=r'$n \sqrt{n}$')
plt.plot(n, n*np.log2(n), label=r'$n \cdot \log_2 n$')
plt.plot(n, n, label='$n$')

plt.xlim(0, N)
plt.ylim(0, 20*N)
plt.legend(frameon=False)
plt.show()

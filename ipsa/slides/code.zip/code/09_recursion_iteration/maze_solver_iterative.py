def explore(i, j):
    global solution

    Q = [(i, j)] # cells to visit

    while Q:
        i, j = Q.pop()
        if (0 <= i < n and 0 <= j < m and
            maze[i][j] != "#" and not visited[i][j]):
            
            visited[i][j] = True

            if maze[i][j] == 'B':
                solution = True

            Q.append((i-1, j))
            Q.append((i+1, j))
            Q.append((i, j-1))
            Q.append((i, j+1))

def find(symbol):
    for i in range(n):
        j = maze[i].find(symbol)
        if j >= 0:
            return (i, j)

n, m = [int(x) for x in input().split()]
maze = [input() for i in range(n)]

solution = False
visited = [m*[False] for i in range(n)]

explore(*find('A'))

if solution:
    print("path from A to B exists")
else:
    print("no path")

def selection_sort(L):
    unsorted = L[:]
    result = []

    while unsorted:
        e = min(unsorted)
        unsorted.remove(e)
        result.append(e)
        #print(f'{e=}, {unsorted=}, {result=}')

    return result

L = [5, 3, 2, 7, 1, 4, 6]

print(selection_sort(L))

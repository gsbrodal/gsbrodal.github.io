import random


def quicksort(L):
    if len(L) <= 1:
        return L[:]
    idx = random.randrange(len(L))
    pivot = L[idx]

    small = [e for e in L if e < pivot]
    equal = [e for e in L if e == pivot]
    large = [e for e in L if e > pivot]

    return quicksort(small) + equal + quicksort(large)


print(quicksort([7, 4, 5, 10, 20, 1, 3, 12]))


def quicksort(L, indent=0):
    print('   ' * indent, f'quicksort({L})')
    if len(L) <= 1:
        result = L[:]
    else:
        idx = random.randrange(len(L))
        pivot = L[idx]

        small = [e for e in L if e < pivot]
        equal = [e for e in L if e == pivot]
        large = [e for e in L if e > pivot]

        result = quicksort(small, indent + 1) + equal + quicksort(large, indent + 1)
    print('   ' * indent, 'return', result)
    return result


print(quicksort([7, 4, 5, 10, 20, 1, 3, 12]))

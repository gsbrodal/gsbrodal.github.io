import random

def quicksort(L):
    # print(f'quicksort({L})')
    if len(L) <= 1:
        return L[:]

    idx = random.randint(0,len(L)-1)
    pivot = L[idx]
    # print(f'pivot = {pivot}')
    other = L[:idx] + L[idx+1:]

    small = [e for e in other if e < pivot]
    large = [e for e in other if e >= pivot]

    return quicksort(small) + [pivot] + quicksort(large)

print(quicksort([7, 4, 5, 10, 20, 1, 3, 12]))

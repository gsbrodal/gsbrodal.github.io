def gcd(x, y):
    return x if y == 0 else gcd(y, x % y)

if __name__ == "__main__":
    print( "GCD(24,36) =", gcd(24,36) )

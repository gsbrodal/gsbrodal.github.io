def gcd(x, y):
    if x == y:
        return x
    elif x > y:
        return gcd(x - y, x)
    else:
        return gcd(x, y - x)

if __name__ == "__main__":
    print( "GCD(24,36) =", gcd(24,36) )

def gcd(x, y):
    while x != y:
        if y > x:
            x, y = y, x
        x = x -y        
    return x

if __name__ == "__main__":
    print( "GCD(24,36) =", gcd(24,36) )

"""
A maze solver.
"""

def find(symbol):
    """Find cell (i, j) containing 'symbol'"""
    for i, row in enumerate(maze):
        j = row.find(symbol)
        if j >= 0:
            return (i, j)
    return None

def print_maze():
    print("\n".join(maze))

def update_maze(i, j, symbol):
    maze[i] = maze[i][:j] + symbol + maze[i][j+1:]

def explore(p, symbol):
    """Visit cell p = (i, j) recursively in maze.
    Insert symbol if cell is free""" 

    global solution

    i, j = p
    if (0 <= i < n and 0 <= j < m and
        maze[i][j] != "#" and not visited[i][j]):
        visited[i][j] = True

        if maze[i][j] == '.':
            update_maze(i, j, 'X')
            print_maze()
            input("press enter\n")
            update_maze(i, j, symbol)
        elif maze[i][j] == 'B':
            print("Solution = True")
            solution = True

        explore((i-1, j), 'v')
        explore((i+1, j), '^')
        explore((i, j-1), '>')
        explore((i, j+1), '<')

n, m = [int(x) for x in input().split()]
maze = [input() for i in range(n)]

solution = False
visited = [m*[False] for i in range(n)]

explore(find('A'), 'A')

if solution:
    print("it is possible to reach B from A")
else:
    print("no path")

print_maze()                

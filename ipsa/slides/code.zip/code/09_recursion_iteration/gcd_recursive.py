def gcd(x, y):
    if y == 0:
        return x
    else:
        # after first call 0 <= y < x
        print(f'gcd({x}, {y}) reduction={(y + x % y) / (x + y):.4f}')
        return gcd(y, x % y)


if __name__ == "__main__":
    print(f'{gcd(24, 36) = }')

    # gcd on Fibonacci numbers implies worst-case number of recursions

    print()
    fib = [1,1]
    for _ in range(100):
        fib.append(sum(fib[-2:]))
    print('Fibonacci numbers:', *fib)
    print(f'{gcd(fib[-2], fib[-1]) = }')

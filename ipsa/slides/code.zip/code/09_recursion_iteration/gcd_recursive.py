def gcd(x, y):
    if y == 0:
        return x
    else:
        return gcd(y, x % y)

if __name__ == "__main__":
    print( "GCD(24,36) =", gcd(24,36) )

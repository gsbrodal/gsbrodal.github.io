def explore(i, j):
    global solution

    print(f'explore({i}, {j})')
    if (0 <= i < n and 0 <= j < m and
        maze[i][j] != "#" and not visited[i][j]):
        
        visited[i][j] = True

        if maze[i][j] == 'B':
            solution = True

        explore(i-1, j)
        explore(i+1, j)
        explore(i, j-1)
        explore(i, j+1)

def find(symbol):
    for i in range(n):
        j = maze[i].find(symbol)
        if j >= 0:
            return (i, j)

n, m = [int(x) for x in input().split()]
maze = [input() for i in range(n)]

solution = False
visited = [m*[False] for i in range(n)]

explore(*find('A'))

if solution:
    print("path from A to B exists")
else:
    print("no path")

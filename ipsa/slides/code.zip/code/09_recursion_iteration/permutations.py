def permutations(L):
    if len(L) == 0:
        return [L[:]]
    else:
        P = permutations(L[1:])
        #print(f'{L=}, {P=}')
        return [p[:i] + L[:1] + p[i:] for p in P for i in range(len(L))]
 
print(permutations([1, 2, 3]))
print(permutations((1, 2, 3)))
print(permutations('abc'))

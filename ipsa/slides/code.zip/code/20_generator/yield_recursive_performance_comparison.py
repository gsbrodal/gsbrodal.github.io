from time import time
import matplotlib.pyplot as plt


def balanced(n):
    def recurse(a, b):
        if a == b:
            return a
        m = (a + b) // 2
        return (recurse(a, m), recurse(m + 1, b))

    return recurse(1, n)


def path(n):
    def recurse(a, b):
        if a == b:
            return a
        return (recurse(a, a), recurse(a + 1, b))

    return recurse(1, n)


def traverse_yield(tree):
    if not isinstance(tree, tuple):
        yield tree
    else:
        for child in tree:
            for value in traverse_yield(child):
                yield value


def traverse_yield_from(tree):
    if not isinstance(tree, tuple):
        yield tree
    else:
        for child in tree:
            yield from traverse_yield_from(child)


def traverse_flatten(tree):
    if not isinstance(tree, tuple):
        return [tree]
    else:
        ## A comprehension increases the recursion depth by a factor 2,
        ## causing RecursionError: maximum recursion depth exceeded
        #return [value for child in tree for value in traverse_flatten(child)]
        answer = []
        for child in tree:
            for value in traverse_flatten(child):
                answer.append(value)
        return answer


def traverse_collect(tree):
    flat = []

    def recurse(tree):
        if not isinstance(tree, tuple):
            flat.append(tree)
        else:
            for child in tree:
                recurse(child)

    recurse(tree)
    return flat


ns = range(100, 1001, 100)
for generator in (path, balanced):
  for traverse in (traverse_yield_from, traverse_yield, traverse_flatten, traverse_collect):
    label = generator.__name__ + ', ' + traverse.__name__
    times = []
    for n in ns:
        print(label, 'n =', n)
        tree = generator(n)
        # Warm up cache
        L = sum(traverse(tree))
        # Time traversal
        start = time()
        for _ in range(50):
            L = sum(traverse(tree))
        end = time()
        duration = end - start
        times.append(duration / n)
        assert L == sum(range(n + 1))
    plt.plot(ns, times, '.-', label=label)
plt.xlabel('Tree size $n$')
plt.ylabel('Traversal time / $n$')
plt.legend(title='Tree generator, traversal generator')
plt.title('Time for recursive traversal using generator with "yield from"')
plt.show()

def two():
    yield 1
    yield 2

class vector2D:
    def __init__(self, x_value, y_value):
        self.x = x_value
        self.y = y_value
    def __iter__(self):
        yield self.x
        yield self.y
    def __iter__(self):
        yield from (self.x, self.y)

v = vector2D(5, 7)

print(list(v))
print(tuple(v))
print(set(v))

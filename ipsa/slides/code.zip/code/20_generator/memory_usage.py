from memory_profiler import profile
import gc

@profile
def use_memory():
    s = 0
    x = list(range(20_000_000))
    s += sum(x)
    x = []
#    gc.collect()
    y = list(range(10_000_000))
    s += sum(x)

use_memory()

use_memory()

def my_range(start, end, step):
    x = start
    while x < end:
        yield x
        x += step
        
r = my_range(1.5, 2.0, 0.1)
        

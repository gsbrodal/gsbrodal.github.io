class squares_leq:
    def __init__(self, n):
        self.n = n
        self.current = 1
        
    def __iter__(self):
        return squares_leq(self.n)

    def __next__(self):
        answer = self.current ** 2
        if answer > self.n:
            raise StopIteration
        self.current += 1
        return answer

for x in squares_leq(100):
    print(x)

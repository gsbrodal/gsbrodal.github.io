def my_generator(n):
    yield 'Start'
    for i in range(n):
        yield chr(ord('A')+i)
    yield 'Done'

print(list(my_generator(3)))

class infinite_range:
    def __init__(self, start=0, step=1):
        self.start = start
        self.step = step

    def __iter__(self):
        return infinite_range_iterator(self)

class infinite_range_iterator:
    def __init__(self, inf_range):
        self.range = inf_range
        self.current = self.range.start

    def __next__(self):
        value = self.current
        self.current += self.range.step
        return value

    def __iter__(self):
        return self

r = infinite_range(42, -3)
it = iter(r)

print("First five")
for idx, value in zip(it, range(5)):
    print(idx, value)

print("Next five")
for idx, value in zip(range(5), it):
    print(idx, value)
        
#print(sum(r))  # don't do this 

import random

def random_integers(n):
    seen = set()  # integers generated so far
    while len(seen) < n:
        value = random.randint(1, n)
        if value in seen:
            continue  # skip dublicates
        seen.add(value)
        yield value


r = random_integers(10)
for x in r:
    print(x)

input('Press <enter> to continue')

r = random_integers(1_000_000_000)

input('Press <enter> to continue')

print(sum(next(r) for _ in range(10_000_000)))

input('Press <enter> to continue')

r.close()

input('Press <enter> to continue')

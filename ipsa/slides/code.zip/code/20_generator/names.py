class Names:
    def __init__(self, *arg):
        self.people = arg
        
    def __iter__(self):
        return Names_iterator(self)

class Names_iterator:
    def __init__(self, names):
        self.idx = 0
        self.names = names

    def __next__(self):
        if self.idx >= len(self.names.people):
            raise StopIteration
        self.idx += 1
        return self.names.people[self.idx-1]

duckburg = Names('Donald', 'Goofy', 'Mickey', 'Minnie')

for name in duckburg:
    print(name)

def even(x):
    if x % 2 == 0:
        return True
    else:
        return False

print( (even(7), even(6)) )

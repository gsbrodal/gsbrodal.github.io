n = 101
not_primes = {m for f in range(2, n) for m in range(2*f, n, f)}
primes = set(range(2, n)) - not_primes
print(list(primes))

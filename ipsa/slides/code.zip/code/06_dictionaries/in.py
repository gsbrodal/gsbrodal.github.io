from random import shuffle, choices
from time import time
import matplotlib.pyplot as plt

time_L = []
time_S = []
time_D = []

ns = [1, *range(100, 2001, 100)]

for n in ns:
    print(f'{n = }')
    L = list(range(n))
    shuffle(L)
    S = set(L)
    D = {value: 42 for value in L}

    queries = choices(L, k=1_000_000)
    for X, times in [(L, time_L), (S, time_S), (D, time_D)]:
        count = 0
        start = time()
        for q in queries:
            if q in X:
                count +=1    
        end = time()
        times.append((end - start) / len(queries))

plt.plot(ns, time_L, '.-', label='list')
plt.plot(ns, time_S, '.-', label='set')
plt.plot(ns, time_D, '.-', label='dict')
plt.xlabel('Size of list/set/dict (n)')
plt.ylabel("Average query time for 'in' (seconds)")
plt.legend()
plt.show()


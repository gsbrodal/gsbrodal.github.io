def binomial(n, k):  # Ugly, nested indentations and redundant else
    if k == 0:
        return 1
    else:
        if k == n:
            return 1
        else:
            return binomial(n - 1, k) + binomial(n - 1, k - 1)

def binomial(n, k):  # Treat each special case first and return
    if k == 0:
        return 1
    if k == n:
        return 1    
    return binomial(n - 1, k) + binomial(n - 1, k - 1)

def binomial(n, k):   # Several cases simultaneously – is test obvious?
    if k == 0 or k == n:
        return 1
    return binomial(n - 1, k) + binomial(n - 1, k - 1)

def binomial(n, k):  # 1-liner, but is this the easiest to read?
    return binomial(n - 1, k) + binomial(n - 1, k - 1) if 0 < k < n else 1

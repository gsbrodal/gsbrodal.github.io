import matplotlib.pyplot as plt

def z_curve(depth, x0=0, y0=0, x1=1, y1=1):
    x, y = (x0 + x1) / 2, (y0 + y1) / 2
    if depth == 0:
        return [(x, y)]
    return [
        *z_curve(depth - 1, x0, y0, x, y),
        *z_curve(depth - 1, x, y0, x1, y),
        *z_curve(depth - 1, x0, y, x, y1),
        *z_curve(depth - 1, x, y, x1, y1)
    ]

for depth in range(4):
    X, Y = zip(*z_curve(depth))
    plt.subplot(2, 2, 1 + depth, aspect='equal')    
    plt.title(f'depth {depth}')
    plt.axis('off')
    plt.axis([0, 1, 0, 1])
    plt.plot(
        [0,1,1,0,0], [0,0,1,1,0], 'k:',
        [0.5, 0.5], [0,1], 'k:',
        [0,1], [0.5, 0.5], 'k:',
        X, Y, 'k-',
        X, Y, 'r.',
    )
plt.show()

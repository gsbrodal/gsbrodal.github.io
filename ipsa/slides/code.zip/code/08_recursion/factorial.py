def factorial(n):
    """ recursive computation of n! = n*(n-1)*...*3*2*1 """
    if n <= 1:
        return 1
    return n * factorial(n-1)


def factorial2(n):
    """ recursive computation of n! = n*(n-1)*...*3*2*1 """
    return n * factorial2(n-1) if n > 1 else 1

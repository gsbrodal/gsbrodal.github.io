def factorial(n):
    """ recursive computation of n! = n*(n-1)*...*3*2*1 """
    if n <= 1:
        return 1
    return n * factorial(n-1)

def bin_factorial(n, k):
    """definition using factorial (long integers)"""
    return factorial(n) // factorial(k) // factorial(n-k)

def bin_recursive(n, k):
    """"Computes the Binomial coefficient recursively (slow)"""
    if k==0 or k==n:
        return 1
    return bin_recursive(n-1, k) + bin_recursive(n-1, k-1)

def bin_pascal(n, k):
    """ Computing binomial coefficients using Pascal's triangle """
    l = [1]
    for i in range(n):
        l = [1] + [l[j] + l[j+1] for j in range(i)] + [1]
    return l[k]

print( bin_factorial(8, 3) )

print( bin_recursive(8, 3) )

print( bin_pascal(8, 3) )

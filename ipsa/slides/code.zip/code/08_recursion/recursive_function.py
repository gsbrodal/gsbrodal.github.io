def recursive_function(x):
      if x > 0:
          print("start", x)
          # input("press return to continue")
          recursive_function(x - 1)
          print("end", x)
      else:
          print("done")
recursive_function(5)

def binomial(n, k, indent=0):
    print('   ' * indent + f'binomial({n}, {k})')
    if k == 0 or k == n:
        result = 1
    else:
        result = binomial(n - 1, k, indent=indent + 1) + binomial(n - 1, k - 1, indent=indent + 1)
    print('   ' * indent + f'return {result}')
    return result

print(binomial(4, 2))

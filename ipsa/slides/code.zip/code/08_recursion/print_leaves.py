def print_leaves(tree):
    # print('> Begin: print_leaves', tree)
    if isinstance(tree, str):
        print("Leaf:", tree)
    else:
        for child in tree:
            print_leaves(child)
    # print('< End: print_leaves', tree)

print_leaves(('a',('b','c')))

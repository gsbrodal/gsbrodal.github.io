import matplotlib.pyplot as plt
from math import sqrt

def koch(p, q, depth=3):
    if depth == 0:
        return [p, q]

    (px, py), (qx, qy) = p, q    
    dx, dy = qx - px, qy - py
    
    h = 1 / sqrt(12)

    p1 = px + dx / 3, py + dy / 3
    p2 = px + dx / 2 - h * dy, py + dy / 2 + h * dx
    p3 = px + dx * 2 / 3, py + dy * 2 / 3
    
    return (koch(p,  p1, depth - 1)[:-1]
          + koch(p1, p2, depth - 1)[:-1]
          + koch(p2, p3, depth - 1)[:-1]
          + koch(p3, q,  depth - 1))

points = koch((0, 1), (3, 0), depth=5)

X, Y = zip(*points)

plt.subplot(aspect='equal')
plt.plot(X, Y, 'r-')
plt.plot(X, Y, 'k.')
plt.show()


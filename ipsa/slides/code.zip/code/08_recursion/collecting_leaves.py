def print_leaves(tree):
    if isinstance(tree, str):
        print("Leaf:", tree)
    else:
        for child in tree:
            print_leaves(child)

def collect_leaves_slow(tree):
    leaves = set()
    if isinstance(tree, str):
        leaves.add(tree)
    else:
        for child in tree:
            leaves |= collect_leaves_slow(child)
    return leaves

def collect_leaves_wrong(tree, leaves = set()):
    if isinstance(tree, str):
        leaves.add(tree)
    else:
        for child in tree:
            collect_leaves_wrong(child, leaves)
    return leaves

def collect_leaves_right(tree, leaves = None):
    if leaves == None:
        leaves = set()
    if isinstance(tree, str):
        leaves.add(tree)
    else:
        for child in tree:
            collect_leaves_right(child, leaves)
    return leaves

def collect_leaves(tree):
    leaves = set()

    def traverse(tree):
        if isinstance(tree, str):
            leaves.add(tree)
        else:
            for child in tree:
                traverse(child)

    traverse(tree)
    return leaves


tree1 = (('a','b'),'c')
tree2 = (('d','e'),'f')

print("tree1 leaves")
print_leaves(tree1)

print("tree2 leaves")
print_leaves(tree2)


print("collect_leaves_slow")
print(collect_leaves_slow(tree1))
print(collect_leaves_slow(tree2))

print("collect_leaves_wrong")
print(collect_leaves_wrong(tree1))
print(collect_leaves_wrong(tree2))

print("collect_leaves_right")
print(collect_leaves_right(tree1))
print(collect_leaves_right(tree2))

print("collect_leaves")
print(collect_leaves(tree1))
print(collect_leaves(tree2))

def run_twice(f):
    def wrapper():
        f()
        f()
        
    return wrapper

@run_twice
def hello_world():
    print("Hello world")

hello_world()

def plus_one(x):
    return x + 1

def square(x):
    return x ** 2

def cube(x):
    return x ** 3

square_original = square
cube_original = cube

square = lambda x: plus_one(square_original(x))

cube = lambda x: plus_one(cube_original(x))

print(square(5))
print(cube(5))

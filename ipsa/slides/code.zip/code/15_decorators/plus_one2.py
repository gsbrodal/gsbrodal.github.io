def plus_one(x):
    return x + 1

def square(x):
    return plus_one(x ** 2)

def cube(x):
    return plus_one(x ** 3)

print(square(5))

print(cube(5))

def run_twice(f):
    def wrapper(*args):
        f(*args)
        f(*args)
        
    return wrapper

@run_twice
def hello_world():
    print("Hello world")

@run_twice
def hello(txt):
    print("Hello", txt)

hello_world()
hello("Mars")

def plus_one_decorator(f):
    def plus_one(x):
        return f(x) + 1

    return plus_one

@plus_one_decorator
@plus_one_decorator
def square(x):
    return x ** 2

@plus_one_decorator
@plus_one_decorator
@plus_one_decorator
def cube(x):
    return x ** 3

print(square(5))
print(cube(5))

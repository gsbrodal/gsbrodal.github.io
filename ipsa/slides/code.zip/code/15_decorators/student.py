import functools

@functools.total_ordering
class Student():
    def __init__(self,name, student_id):
        self.name = name
        self.id = student_id

    def __eq__(self, other):
        return (self.name == other.name
                and self.id == other.id)

    def __lt__(self, other):
        my_name = ', '.join(reversed(self.name.split()))
        other_name = ', '.join(reversed(other.name.split()))
        return (my_name < other_name
                or (my_name == other_name and self.id < other.id))

    def __str__(self):
        return "%s (%s)" % (self.name, self.id)

donald = Student('Donald Duck', 7)
gladstone = Student('Gladstone Gander', 7)
grandma = Student('Grandma Duck', 7)

for x in sorted([gladstone, grandma, donald]):
	print(x)

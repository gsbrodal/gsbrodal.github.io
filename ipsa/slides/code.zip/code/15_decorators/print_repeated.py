def enforce_types(*decorator_args):
    def decorator(f):
        def wrapper(*args):
            assert len(args) == len(decorator_args), \
                   f'got {len(args)} arguments, expected {len(decorator_args)}'
            assert all([isinstance(x, t) for x, t in zip(args,decorator_args)]), \
                   'unexpected types'
            
            return f(*args)

        return wrapper

    return decorator

@enforce_types(str, int)
def print_repeated(txt, n):
    print(txt * n)

print_repeated('Hello ', 3)
print_repeated('Hello ', 'world')

def enforce_integer(f):
    def wrapper(*args):
        assert all([isinstance(x, int) for x in args]), \
               'all arguments most be int'

        return f(*args)

    return wrapper

@enforce_integer
def integer_sum(*args):
    return sum(args)

integer_sum(1, 2, 3, 4)
integer_sum(1, 2, 3.2, 4)

def plus_one_decorator(f):
    def plus_one(x):
        return f(x) + 1

    plus_one.__name__ = f.__name__  # let help(...) print correct name
    plus_one.__doc__ = f.__doc__  # and the correct doc string
    
    return plus_one


@plus_one_decorator
def square(x):
    '''Return x squared.'''
    
    return x ** 2


@plus_one_decorator
def cube(x):
    '''Return x cubed.'''
    
    return x ** 3


print(square(5))
print(cube(5))

def add_lessequal(cls):
    '''Class decorator to add __le__ given __eq__ and __lt__.'''

    cls.__le__ = lambda self, other : self == other or self < other

    return cls  # the original class cls with attribute __le__ added


def add_lessequal(cls):
    '''Class decorator to add __le__ given __eq__ and __lt__.'''

    class sub_cls(cls):
        def __le__(self, other):
            return self == other or self < other

    # sub_cls.__name__ = cls.__name__  # fix subclass to have save name
    return sub_cls  # new subclass of class cls


@add_lessequal  # Vector = add_lessequal(Vector)
class Vector:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def _length_squared(self):
        return self.x ** 2 + self.y ** 2
    
    def __eq__(self, other):
        # Required, otherwise Vector(1, 2) == Vector(1, 2) is False
        return self._length_squared() == other._length_squared()

    def __lt__(self, other):
        return self._length_squared() < other._length_squared()

#    def __le__(self, other):
#        return self._length_squared() <= other._length_squared()

#    def __le__(self, other):
#       return self == other or self < other

    def __repr__(self):
        return f'Vector({self.x}, {self.y})'


for u, v in [
    (Vector(3, 4), Vector(2, 5)),
#    (object(), object())
]:
    print(f'{u = }, {v = }')
    for exp in [
        'u.__eq__(v)',
        'u.__ne__(v)',
        'u.__lt__(v)',
        'u.__gt__(v)',
        'u.__le__(v)',
        'u.__ge__(v)',
        'u == v',
        'u != v',
        'u < v',
        'u > v',
        'u <= v',
        'u >= v'
    ]:
        try:
            print(exp, ':', eval(exp))
        except Exception as e:
            print(exp, 'EXCEPTION:', type(e), e)

def plus_one(x):
    return x + 1

def square(x):
    return x ** 2

def cube(x):
    return x ** 3

print(plus_one(square(5)))

print(plus_one(cube(5)))

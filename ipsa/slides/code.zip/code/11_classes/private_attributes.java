class My_Class {
    private int x, y;
    public void set_xy(int a, int b) {
	x = a;
	y = b;
    }
    int get_sum() {
	return x + y;
    };
};

class private_attributes {
    public static void main(String args[]){  
        My_Class obj = new My_Class();
	obj.set_xy(3, 5);
	System.out.println("Sum = " + obj.get_sum());
	System.out.println("x = " + obj.x);
    }
}

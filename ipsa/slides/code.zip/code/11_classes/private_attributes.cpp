#include <iostream>

using namespace std;

class My_Class {
private:
  int x, y;
public:
  void set_xy(int a, int b) {
    x = a;
    y = b
  }
  int get_sum() {
    return x + y;
  };
};

main() {
  My_Class obj;
  obj.set_xy(3, 5);
  cout << "Sum = " << obj.get_sum() << endl;
  cout << "x = " << obj.x << endl;
}

class Student:
    def __init__(self):
        self.name = ''
        self.id = ''

    def set_name(self, name):
        self.name = name
    
    def set_id(self, student_id):
        self.id = student_id
        
    def get_name(self):
        return self.name
    
    def get_id(self):
        return self.id

student_DD = Student()
student_MM = Student()
student_SM = Student()

student_DD.set_name('Donald Duck')
student_DD.set_id('107')

student_MM.set_name('Mickey Mouse')
student_MM.set_id('243')

student_SM.set_name('Scrooge McDuck')
student_SM.set_id('777')

students = [student_DD, student_MM, student_SM]

for student in students:
    print(student.get_name(),
          "has id",
          student.get_id())


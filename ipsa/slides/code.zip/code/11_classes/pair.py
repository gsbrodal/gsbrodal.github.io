class Pair:
    def __init__(self, a, b):
        self.a = a
        self.b = b
        self.the_sum = self.a + self. b

    def set_a(self, a):
        self.a = a
        self.the_sum = self.a + self.b

    def set_b(self, b):
        self.b = b
        self.the_sum = self.a + self.b

    def sum(self):
        return self.the_sum

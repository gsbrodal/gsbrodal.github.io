class Student:
    next_id = 1

    def __init__(self, name=None):
        self.name = name
        self.id = str(self.next_id)
        self.next_id += 1

    def get_name(self):
        return self.name
    
    def get_id(self):
        return self.id

students = [Student('Scrooge McDuck'),
            Student('Donald Duck'),
            Student('Mickey Mouse')]

for student in students:
    print(student.get_name(),
          "has student id",
          student.get_id())

#include <iostream>
using namespace std;

class My_Class {
public:
  static int x;
  void inc() { x += 1; };
};

int My_Class::x = 1;

int main(){
  My_Class obj1;
  My_Class obj2;
  obj1.inc();
  obj2.inc();
  cout << obj1.x << endl;
  cout << obj2.x << endl;
}

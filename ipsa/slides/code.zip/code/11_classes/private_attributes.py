class My_Class:
    def set_xy(self, x, y):
        self._x = x
        self._y = y

    def get_sum(self):
        return self._x + self._y

obj = My_Class()
obj.set_xy(3, 5)

print("Sum =", obj.get_sum())
print("_x =", obj._x)

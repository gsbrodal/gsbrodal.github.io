class My_Class:
    x = 1  # class attribute

    def inc(self):
        My_Class.x = self.x + 1  # My_Class.x == self.x

obj1 = My_Class()
obj2 = My_Class()
obj1.inc()
obj2.inc()

print(obj1.x, obj2.x)

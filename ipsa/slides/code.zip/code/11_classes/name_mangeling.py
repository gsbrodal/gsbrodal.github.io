class MySecretBox:
    def __init__(self, secret):
        self.__secret = secret

x = MySecretBox(42)
print(x._MySecretBox__secret)
print(x.__secret)

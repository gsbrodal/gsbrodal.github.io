class My_Class {
    public static int x=1;
    public void inc() {	x += 1; };
}

class static_attributes {
    public static void main(String args[]){  
        My_Class obj1 = new My_Class();
        My_Class obj2 = new My_Class();
	obj1.inc();
	obj2.inc();
	System.out.println(obj1.x);
	System.out.println(obj2.x);
    }
}

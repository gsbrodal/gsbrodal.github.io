class Student:
    def __init__(self, name=None, student_id=None):
        self.name = name
        self.id = student_id

    def set_name(self, name):
        self.name = name
    
    def set_id(self, student_id):
        self.id = student_id
        
    def get_name(self):
        return self.name
    
    def get_id(self):
        return self.id

    def __lt__(self, other):
        return self.id < other.id

    def __str__(self):
        return f"Student('{self.name}', '{self.id}')"

student_SM = Student('Scrooge McDuck', '777')
student_DD = Student('Donald Duck', '107')
student_MM = Student('Mickey Mouse', '243')

students = [student_MM, student_DD, student_SM]

for student in sorted(students):
    print(student.get_name(),
          "has student id",
          student.get_id())

for student in students:
    print(student)

if x < 0:
    print("negative")
elif x == 0:
    print("zero")
elif x == 1:
    print("one")
else: 
    print(">=2")

def f(x):
    if x < 0:
        print("negative")
    elif x%2 == 0:
        if x == 0:
            print("zero")
        elif x == 2:
            print("even prime number")
        else: 
            print("even composite number")
    else:
        if x == 1:
            print("one")
        else: 
            print("some odd number")

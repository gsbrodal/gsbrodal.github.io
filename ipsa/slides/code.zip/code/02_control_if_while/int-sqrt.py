x = 20

low = 0
high = x + 1
while True:  # low <= sqrt(x) < high
    if low + 1 == high:
        break
    mid = (high + low) // 2
    print('x =', x, 'low =', low, 'high =', high, 'mid =', mid)
    if mid * mid <= x:
        low = mid
        continue
    high = mid 
print('x =', x, 'low =', low, 'high =', high)
print(low)  # low = floor(sqrt(x))

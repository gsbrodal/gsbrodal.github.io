from bisect import bisect_left, bisect_right

L = [3, 4, 6, 7, 7, 7, 10, 11, 13, 16, 17]

print(bisect_left(L, 7))
print(bisect_right(L, 7))
print(bisect_left(L, 14))
print(bisect_right(L, 14))

from random import randint

while True:
    x = randint(1, 10)
    y = randint(1, 10)
    if abs(x - y) >= 2: break
    print('too close', x, y)
print(x, y)

if x == 0:
    print("zero")

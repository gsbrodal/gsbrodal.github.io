# Newton iteration on function to compute 1 / n
#    f(x)  =  n - 1 / x
#   f'(x)  =  1 / x^2
#      x  :=  x - f(x) / f'(x) = (2 - n * x) * x

#n = 0.75  # n in [0.5, 1.0]
n = 0.6  # does compute slightly different number

x = 1.0
last = 0.0
while last < x:
    print(x)
    last = x
    x = (2 - n * x) * x

print('Apx of 1.0 /', n, '=', x)
print('Python 1.0 /', n, '=', 1.0 / n)

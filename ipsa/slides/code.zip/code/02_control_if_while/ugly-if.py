if x < 0:
    print('negative')
else:
    if x == 0:
        print('zero')
    else:
        if x == 1:
            print('one')
        else: 
            print('>= 2')

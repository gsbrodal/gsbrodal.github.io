name = input("Name: ")
age = int(input("Age: "))
print(name, "is", age, "years old")

def odd(x):
    return x % 2 == 1
def sum_of_three_primes(n):
    assert odd(n) and n > 5
    primes = (set(range(2, n + 1)) -
              set(x for f in range(2, n + 1)
                    for x in range(2 * f, n + 1, f)))
    for x in primes:
        for y in primes:
            for z in primes:
                if n == x + y + z:
                    print(n, 'is the sum of three primes', x, y, z)
                    return
    print(n, 'is not the sum of three primes')
for n in range(7, 1001, 2):
    sum_of_three_primes(n)

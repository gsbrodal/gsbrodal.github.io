def f(x: int, units: str) -> str:
    return str(x) + " " + units

def g(x, units: str) -> str:
    return str(x) + " " + units

print(f(3, "cm"))
print(f("one", "meter"))
print(g(3, "cm"))
print(g("one", "meter"))

print(f.__annotations__)

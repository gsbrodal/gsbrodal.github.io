def f(depth):
    print("enter depth = %s" % depth)
    if depth>= 100:
        print("Nu er det nok")
        raise SystemExit
    f(depth + 1)
    print("exit depth = %s" % depth)

f(0)

def f(depth):
    f(depth + 1)  # infinite recursion

f(0)

def add(x, y):
#def add(x: int | float, y: int | float):
    return x + y

print(add(42, 'abc'))
#print(add(2, 5.0))
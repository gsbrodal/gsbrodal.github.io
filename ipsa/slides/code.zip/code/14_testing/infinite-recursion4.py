def f(depth):
    assert depth <= 100
    f(depth + 1)

f(0)

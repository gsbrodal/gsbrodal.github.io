class A:
    pass

class B(A):
    pass

class C:
    pass

a : A
b : B
c : C
a = A()
a = B()  # valid, B subclass of A
a = C()  # error
b = A()  # error
b = B()
b = C()  # error
c = A()  # error
c = B()  # error
c = C()

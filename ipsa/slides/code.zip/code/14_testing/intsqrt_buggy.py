def int_sqrt(x):
    """Beregn kvadratroden for heltal"""
    
    assert isinstance(x, int)
    assert x >= 0
    low = 0
    high = x + 1
    while low < high - 1:
        assert low**2 <= x < high**2
        mid = (low + high) // 2
        #print("low mid high = %s %s %s" % (low, mid, high))
        if mid ** 2 <= x:
            low = mid
        else:
            high = mid
    assert isinstance(low, int)
    return low

assert int_sqrt(0) == 0
assert int_sqrt(1) == 1
assert int_sqrt(2) == 1
assert int_sqrt(3) == 1
assert int_sqrt(4) == 2
assert int_sqrt(300) == 17

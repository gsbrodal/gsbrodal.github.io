def f(depth):
    assert depth <= 100, 'runaway recursion???'
    f(depth + 1)

f(0)

import random

def int_sqrt(x):
    low = 0
    high = x + 1
    while low + 1 < high:
        assert low ** 2 <= x < high ** 2
        mid = (high + low) // 2
        if mid ** 2 <= x:
            low = mid
        else:
            high = mid
    return low


def test_int_sqrt(x):
    print('.', end='', flush=True)  # Show progress
    assert x >= 0  # Verify input
    answer = int_sqrt(x)
    # Verify output
    assert answer ** 2 <= x < (answer + 1) ** 2


# Test small inputs
for x in range(0, 100):
    test_int_sqrt(x)

# Test increasing sized inputs
for d in range(3, 30):
    for _ in range(100):  # Repeat for each size
        test_int_sqrt(random.randint(1, 10 ** d))

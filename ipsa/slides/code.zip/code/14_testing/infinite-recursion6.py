def f(depth):
    if not depth <= 100:
        raise AssertionError("runaway recursion???")
    f(depth + 1)

f(0)

# deprecated: from typing import Mapping, Set, List, Tuple, Union, Optional

S : set = {}  	# error {} dictionary
S2 : set[int] = {1, 2, "abc"}	# error "abc" is not int
D : dict[int, int] = {1: 42, 'a': 1}	# error 'a' is not int
T : tuple[int, str] = (42, 7)	# error 7 is not str
L : list[int | str] = [42, 'a', None]	# list can only contain int and str
L2 : list[str | None] = ['abc', None, 42]	# list can only contain str og None

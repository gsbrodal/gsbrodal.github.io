from typing import override, final

class A():
    @final
    def f(self):
        print('f')
        self.g()
    #def g(self):
    #    raise NotImplementedError

class B(A):
    @override
    def g(self):
        print('g')

B().f()
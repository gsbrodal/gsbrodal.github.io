import sys

def f(depth):
    if depth > 100:
        print('runaway recursion???')
        sys.exit()
    f(depth + 1)

f(0)

x : int  # type hint
x = 42
x = "abc"

y : int = 42  # type hint
y = "abc"

z = 42
z = "abc"  # type change from int to str

print(x, y, z)

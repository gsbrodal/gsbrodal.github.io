from typing import overload

class MyClass:
    @overload 
    def print(self, value: int) -> None: ...

    @overload 
    def print(self, value: str) -> None: ...

    def print(self, value):
        if isinstance(value, int):
            print('An integer', value)
        elif isinstance(value, str):
            print('A string', value)

C = MyClass()
C.print(42)
C.print('abc')
print('start')
print(42 + 'abc')  # error - cannot add int and str
print('end')

from typing import Mapping, Set, List, Tuple, Union, Optional

S : Set = {}  	# error {} dictionary
S2 : Set[int] = {1, 2, "abc"}	# error "abc" is not int
D : Mapping[int, int] = {1: 42, 'a': 1}	# error 'a' is not int
T : Tuple[int, str] = (42, 7)	# error 7 is not str
L : List[Union[int, str]] = [42, 'a', None]	# list can only contain int and str
L2 : List[Optional[str]] = ['abc', None, 42]	# list can only contain str og None


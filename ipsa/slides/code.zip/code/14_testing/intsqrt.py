def int_sqrt(x):
    '''Compute the integer square root of an integer x.

    Requires x >= 0 is an integer.
    Returns the integer floor(sqrt(x)).'''
    
    assert isinstance(x, int)  
    assert 0 <= x
    
    low, high = 0, x + 1
    while low < high - 1:
        assert low ** 2 <= x < high ** 2
        mid = (low + high) // 2
        if mid ** 2 <= x:
            low = mid
        else:
            high = mid
    result = low

    assert isinstance(result, int)
    assert result ** 2 <= x < (result + 1) ** 2, f''

    return result

# Test correctness of int_sqrt(x)
assert int_sqrt(0) == 0
assert int_sqrt(1) == 1
assert int_sqrt(2) == 1
assert int_sqrt(3) == 1
assert int_sqrt(4) == 2
assert int_sqrt(5) == 2
assert int_sqrt(200) == 14


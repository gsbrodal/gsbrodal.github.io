import numpy as np
from scipy.optimize import linprog

c = np.array([3, 2])

A_ub = np.array([[2, 1],
                 [-5, -6]])  # multiplie by -1 to get <=
b_ub = np.array([10, -4])

A_eq = np.array([[-3, 7]])
b_eq = np.array([8])

res = linprog(-c,  # maximize = minize the negated
              A_ub=A_ub,
              b_ub=b_ub,
              A_eq=A_eq,
              b_eq=b_eq)
print(res)

import matplotlib.pyplot as plt

image_height = 200
image_width = 100
(x_min, y_min), (x_max, y_max) = (-1, -10), (10, 13)

x = np.linspace(x_min, x_max, image_width).reshape(1, image_width)
y = np.linspace(y_min, y_max, image_height).reshape(image_height, 1)
z = 3 * x + 2 * y

plt.imshow(z,
           origin='lower',
           extent=(x_min, x_max, y_min, y_max),
           cmap='plasma')
clb = plt.colorbar()
clb.ax.set_title('$3x_1+2x_2$')

plt.fill([-1, 8, -1], [1.5, -6, 12], facecolor='white', alpha=0.2)

x = np.linspace(x_min, x_max, 2)
plt.plot(x, 10 - 2 * x, 'b-', label='$2x_1+x_2 \leq 10$')
plt.plot(x, (-4 + 5 * x) / - 6, '-', c='darkgreen', label='$5x_1 + 6x_2 \geq 4$')
plt.plot(x, (8 + 3 * x) / 7, 'y-', label='$-3x_1+7x_2 = 8$')
plt.plot(res.x[0], res.x[1], 'o', c='darkred', label='(%.2f,%.2f)' % (res.x[0], res.x[1]))

plt.xlabel('$x_1$')
plt.ylabel('$x_2$', rotation=0)
plt.gca().set_aspect('equal')
plt.legend()
plt.show()

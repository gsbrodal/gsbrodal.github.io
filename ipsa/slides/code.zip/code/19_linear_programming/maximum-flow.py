import numpy as np
from scipy.optimize import linprog

edges = 9

#                          0  1  2  3  4  5  6  7  8
conservation = np.array([[ 0,-1, 0, 0, 1, 1, 0, 0, 0],  # B
                         [-1, 0, 1, 1, 0, 0, 0, 0, 0],  # C
                         [ 0, 0, 0,-1, 0,-1,-1, 0, 1],  # D
                         [ 0, 0,-1, 0,-1, 0, 1, 1, 0]]) # E

#                 0  1  2  3  4  5  6  7  8
sinks = np.array([0, 0, 0, 0, 0, 0, 0, 1, 1])

#                    0  1  2  3  4  5  6  7  8
capacity = np.array([4, 3, 1, 1, 3, 1, 3, 1, 5])
                 
res = linprog(-sinks, 
              A_eq=conservation, 
              b_eq=np.zeros(conservation.shape[0]),
              A_ub=np.eye(capacity.size), 
              b_ub=capacity)

print(res)

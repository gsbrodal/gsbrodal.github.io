from time import time
from matplotlib import pyplot as plt

ns = range(10_000, 1_000_000, 10_000)
time_string = []
time_list = []
for n in ns:
    print(n)
    start = time()
    s = ''
    for _ in range(n):
        s += 'abcdefgh'
    end = time()
    time_string.append(end - start)

    start = time()
    substrings = []
    for _ in range(n):
        substrings.append('abcdefgh');
    s = ''.join(substrings);
    end = time()
    time_list.append(end - start)

plt.plot(ns, time_string, label='string +=')
plt.plot(ns, time_list, label="''.join(list)")
plt.xlabel('n')
plt.ylabel('time')
plt.legend()
plt.show()

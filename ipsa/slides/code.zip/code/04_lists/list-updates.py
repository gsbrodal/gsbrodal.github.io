from time import time
from matplotlib import pyplot as plt

ns = range(0, 1_000_001, 10_000)
time_pos = []
L = list(range(1_000_000))  # L = [0, 1, ..., 999_999]
for i in ns:
    print(i)
    start = time()
    for _ in range(1000):
        L[i:i] = [42]  # insert new element before L[i]
        del L[i]  # remove L[i] from L
    end = time()
    time_pos.append(end - start)

plt.plot(ns, time_pos)
plt.xlabel('position')
plt.ylabel('time')
plt.show()

L = [7, 3, 6, 4, 12, 'a', 8, 13]
x = 4

if x in L:
    print(x, "at position", L.index(x), "in", L)
else:
    print(x, "not in", L)

L = [7, 3, 6, 4, 12, 'a', 8, 13]
x = 4

i = 0
while i < len(L):
    if L[i] == x:
        print(x, "at position", i, "in", L)
        break
    i = i + 1

if i >= len(L):
    print(x, "not in", L)

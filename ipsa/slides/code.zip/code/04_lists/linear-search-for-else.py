L = [7, 3, 6, 4, 12, 'a', 8, 13]
x = 4

for i in range(len(L)):
    if L[i] == x:
        print(x, "at position", i, "in", L)
        break
else:
    print(x, "not in", L)

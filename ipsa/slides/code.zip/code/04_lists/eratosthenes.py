from time import time

n = 1000_000
prime = [True] * (n + 1)

start = time()

for i in range(2,n):
    #if i * i > n:
    #    break
    #if not prime[i]:
    #    continue
    #for j in range(i * i, n + 1, i):
    for j in range(2 * i, n + 1, i):
        prime[j] = False

end = time()
print(end - start, 'seconds')

for i in range(2, min(100, n) + 1):
    if prime[i]:
        print(i, end=' ')

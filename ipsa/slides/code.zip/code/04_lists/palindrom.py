s = "abracadrabratrallalla"

for i in range(len(s)):
    for j in range(i+2,len(s)+1):
        t = s[i:j]
#        print(i, j, t)
#       print(f'{i=} {j=} {t=}')
        if t == t[::-1]:
            print(t)

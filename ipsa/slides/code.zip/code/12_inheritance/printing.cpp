#include <iostream>

using namespace std;

class MyClass {
public:
  void print(int x) {
    cout << "An integer " << x << endl;
  };
  
  void print(string s) {
    cout << "A string " << s << endl;
  };
};

main() {
  MyClass C;

  C.print(42);
  C.print("abc");
}

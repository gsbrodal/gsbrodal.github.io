class X:
    def set_x(self, x):
        self.x = x

    def get_x(self):
        return self.x

obj = X()

obj.set_x(42)

print("obj.get_x() =", obj.get_x())
print("obj.x =", obj.x)
print("X.get_x(obj) =", X.get_x(obj))

class X:
    def set_x(self, x):
        self.x = x

    def get_x(self):
        return self.x

obj = X()

obj.set_x(42)

print(f'{obj.get_x() = }')
print(f'{obj.x = }')
print(f'{X.get_x(obj) = }')

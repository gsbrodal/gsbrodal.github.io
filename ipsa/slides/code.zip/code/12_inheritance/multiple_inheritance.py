class Alice:
    def say_hello(self):
        print("Alice says hello")

    def say_good_night(self):
        print("Alice says good night")

class Bob:
    def say_hello(self):
        print("Bob says hello")

    def say_good_morning(self):
        print("Bob says good morning")

class X(Alice, Bob):  # Multiple inheritance
    def say(self):
        self.say_good_morning()
        self.say_hello()       # C3 resolution
        Alice.say_hello(self)  # from Alice
        Bob.say_hello(self)    # from Bob
        super(Alice, self).say_hello()
        self.say_good_night()

X().say()

class Alice:  # Multiple inheritance
    def say_hello(self):
        print("Alice says hello")

class Bob:
    def say_hello(self):
        print("Bob says hello")

    def say_good_morning(self):
        self.say_hello()
        print("Bob says good morning")

class X(Bob, Alice):  # Multiple inheritance
    pass

X().say_good_morning()
        

class A:
    def say(self):
        print("A says hello")

class B(A):
    def say(self):
        A.say(self)  #super().say()
        print("B says hello")
    pass

B().say()

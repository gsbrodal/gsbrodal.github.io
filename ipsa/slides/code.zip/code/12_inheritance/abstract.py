class A:
    """ Derived classes must implement the method g """
    
    def f(self):
        print('f')
        self.g()

    #def g(self):
    #    pass

    #def g(self):
    #    raise NotImplementedError()

class B(A):
    def g(self):
        print('g')

b = B()
b.f()

a = A()
a.f()

class Person:
    def __init__(self):
        self.name = None
        self.address = None

    def set_name(self, name):
        self.name = name

    def get_name(self):
        return self.name

    def set_address(self, address):
        self.address = address
        
    def get_address(self):
        return self.address

class Student(Person):
    def __init__(self):
        self.id = None
        self.grades = {}
        Person.__init__(self)
#        super().__init__()
        
    def set_id(self, student_id):
        self.id = student_id

    def get_id(self):
        return self.id

    def set_grade(self, course, grade):
        self.grades[course] = grade

    def get_grades(self):
        return self.grades

class Employee(Person):
    def __init__(self):
        self.id = None
        self.employer = None
        Person.__init__(self)

    def set_employer(self, employer):
        self.employer = employer

    def get_employer(self):
        return self.employter

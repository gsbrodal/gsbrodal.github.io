import heapq
from random import random

H = []  # a heap is just a list

for _ in range(10):
    x = random()
    heapq.heappush(H, x)

while True:
    x = heapq.heappop(H)
    print(H)
    print(x)
    heapq.heappush(H, x + random())

    

print("Loading mypackage.a")

def f():
    print("mypackage.a.f")

print("Loading mypackage.mysubpackage.b")

def g():
    print("mypackage.mysubpackage.b.g")

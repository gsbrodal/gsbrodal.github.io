print('loading mypackage.mysubpackage')
import mypackage.mysubpackage.b

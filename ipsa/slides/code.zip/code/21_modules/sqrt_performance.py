from time import time

import math

start = time()
x = sum(math.sqrt(x) for x in range(10000000))
end = time()
print("math.sqrt", end - start)

from math import sqrt 

start = time()
x = sum(sqrt(x) for x in range(10000000))
end = time()
print("from math import sqrt", end - start)

def test(sqrt=math.sqrt):  # abuse of keyword argument
    start = time()
    x = sum(sqrt(x) for x in range(10000000))
    end = time()
    print("bind sqrt to keyword argument", end - start)
    
test()

def test():  
    sqrt=math.sqrt  # local variable
    start = time()
    x = sum(sqrt(x) for x in range(10000000))
    end = time()
    print("bind sqrt to local variable", end - start)
    
test()

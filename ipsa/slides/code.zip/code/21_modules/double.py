'''Module double.'''

def f(x):
    '''
    Some doc test code:
    
    >>> f(21)
    42
    >>> f(7)
    14
    '''
    return 2 * x

print(f'{__name__ = }')

if __name__ == '__main__': 
	import doctest 
	doctest.testmod(verbose=True) 

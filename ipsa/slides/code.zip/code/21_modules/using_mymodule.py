import mymodule

mymodule.the_name()
mymodule.print_something(5)

from mymodule import print_something

print_something(5)

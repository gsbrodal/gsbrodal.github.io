'''This is a 'print something' module.'''

from random import randint

print('Running my module')

def print_something(n):
    '''Function to print something...'''

    W = ['Eat', 'Sleep', 'Rave', 'Repeat']
    words = (W[randint(0, len(W) - 1)] for _ in range(n))
    print(' '.join(words))

def the_name():
    print('__name__ = "' + __name__ + '"')

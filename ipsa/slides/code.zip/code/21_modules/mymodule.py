'''This is a 'print something' module.'''

from random import choice

print('Running my module')

def print_something(n):
    '''Function to print something...'''

    W = ['Eat', 'Sleep', 'Rave', 'Repeat']
    print(' '.join(choice(W) for _ in range(n)))

def the_name():
    print(f'__name__ = "{__name__}"')

__all__ = ['f']

def f():
    print('this is f')

def g():
    print('this is g')

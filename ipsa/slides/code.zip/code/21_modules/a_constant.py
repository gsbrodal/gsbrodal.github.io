the_constant = 42

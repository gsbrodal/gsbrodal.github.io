import double

print(__name__)
print(double.f(5))

import double

print(f'{__name__ = }')
print(double.f(5))

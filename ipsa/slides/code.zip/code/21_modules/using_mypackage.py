import mypackage.a

mypackage.a.f()

''' 
    Program to measure the running time of integer division (//) for
    large integers. The measured running times are plotted using
    matplotlib.pyplot.
'''

from time import time

bits, compute_time = [], []

for i in range(42):
    x = 3 ** i // 2 ** i
    start = time()

    result = 3 ** x // 3 ** x     # the computation we time

    end = time()
    t = end - start
    print('i =', i, 'x =', x, 'Result =', result, 'time(sec) =', t)
    bits.append(x)
    compute_time.append(t)

import matplotlib.pyplot as plt

plt.title('Computing 3**x // 3**x')
plt.xlabel('x')
plt.ylabel('computation time (seconds)')

plt.plot(bits, compute_time, 'g:')
plt.plot(bits, compute_time, 'ro')

plt.show()
